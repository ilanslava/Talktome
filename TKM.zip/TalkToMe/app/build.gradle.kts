plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// O APK passa a se chamar TalkToMe-debug.apk (e não "app-debug.apk", que todo projeto usa).
base {
    archivesName.set("TalkToMe")
}

android {
    namespace = "com.leitorzap"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.talktome"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // As bibliotecas de idioma (ML Kit) trazem código nativo para cada arquitetura de CPU.
        // Quase todo celular moderno é arm64; manter só ela reduz bastante o tamanho do APK.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Chave de debug fixa dentro do projeto: todo build (Android Studio ou GitHub Actions)
    // sai com a MESMA assinatura, então dá pra atualizar o app por cima sem desinstalar.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:language-id:17.0.4")
    implementation("com.google.mlkit:translate:17.0.2")
}
