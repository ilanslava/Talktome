plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.talktome"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.talktome"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }

    signingConfigs {
        create("talktome") {
            storeFile = file("talktome.keystore")
            storePassword = "talktome123"
            keyAlias = "talktome"
            keyPassword = "talktome123"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("talktome") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("talktome")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
