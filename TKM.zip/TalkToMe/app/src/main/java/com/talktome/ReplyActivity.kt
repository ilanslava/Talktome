package com.talktome

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

/** Tela de resposta: digitar ou ditar (Record) e enviar pela notificação do WhatsApp. */
class ReplyActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_KEY = "key"
        const val EXTRA_VOICE = "voice"
    }

    private lateinit var input: EditText
    private var key = ""

    private val dictation =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    val cur = input.text.toString().trim()
                    input.setText(if (cur.isEmpty()) t else "$cur $t")
                    input.setSelection(input.text.length)
                }
            }
        }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, bg: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = ContextCompat.getDrawable(this@ReplyActivity, bg)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = intent.getStringExtra(EXTRA_KEY).orEmpty()
        val conv = MessageStore.conv(key)
        if (conv == null) {
            Toast.makeText(this, getString(R.string.toast_chat_gone), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val cText = Color.parseColor("#EEF0FF")
        val cMuted = Color.parseColor("#A5A9D6")
        val cDark = Color.parseColor("#0B0E2A")

        val last = conv.msgs.lastOrNull()
        val quote = tv(
            if (last == null) "" else if (conv.isGroup && last.sender.isNotBlank())
                "${last.sender}: ${last.text}" else last.text,
            13.5f, cMuted
        ).apply {
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_row)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        input = EditText(this).apply {
            hint = getString(R.string.reply_hint)
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 16f
            minLines = 2
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_input)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        // respostas rápidas: tocar preenche a caixa (você ainda confere antes de enviar)
        val quick = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
            addView(LinearLayout(this@ReplyActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                for (id in intArrayOf(R.string.qr_1, R.string.qr_2, R.string.qr_3, R.string.qr_4)) {
                    val phrase = getString(id)
                    addView(TextView(this@ReplyActivity).apply {
                        text = phrase
                        textSize = 13f
                        setTextColor(cText)
                        setPadding(px(14), px(8), px(14), px(8))
                        background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_chip_indigo)
                        setOnClickListener {
                            val cur = input.text.toString().trim()
                            input.setText(if (cur.isEmpty()) phrase else "$cur $phrase")
                            input.setSelection(input.text.length)
                        }
                    }, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { marginEnd = px(8) })
                }
            })
        }

        fun lp() = LinearLayout.LayoutParams(0, px(48), 1f).apply {
            marginStart = px(3)
            marginEnd = px(3)
        }
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(12) }
            addView(btn(getString(R.string.chip_record), R.drawable.bg_chip_indigo, cText) { startDictation() }, lp())
            addView(btn(getString(R.string.send), R.drawable.bg_chip_accent, cDark) { send() }, lp())
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(8) }
            addView(btn(getString(R.string.chip_open_chat), R.drawable.bg_chip_indigo, cText) { openChat() }, lp())
            addView(btn(getString(R.string.cancel), R.drawable.bg_chip_indigo, cText) { finish() }, lp())
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_panel)
            setPadding(px(16), px(16), px(16), px(16))
            isClickable = true // não fecha ao tocar dentro do cartão
            addView(LinearLayout(this@ReplyActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(this@ReplyActivity).apply {
                    setImageResource(R.drawable.app_icon)
                    layoutParams = LinearLayout.LayoutParams(px(30), px(30)).apply { marginEnd = px(10) }
                })
                addView(tv(getString(R.string.reply_title, conv.title, conv.appName), 17f, cText, bold = true))
            })
            addView(quote)
            addView(input)
            addView(quick)
            addView(row1)
            addView(row2)
        }

        val root = FrameLayout(this).apply {
            setOnClickListener { finish() }
            addView(
                card,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply {
                    setMargins(px(12), px(12), px(12), px(12))
                }
            )
        }
        setContentView(root)

        // só na primeira criação: girar a tela não pode reabrir o ditado
        if (intent.getBooleanExtra(EXTRA_VOICE, false)) {
            if (savedInstanceState == null) window.decorView.post { startDictation() }
        } else {
            input.requestFocus()
            window.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
    }

    private fun startDictation() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speak_prompt))
        try {
            dictation.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, getString(R.string.toast_no_recognizer), Toast.LENGTH_LONG).show()
        }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) {
            Toast.makeText(this, getString(R.string.toast_write_first), Toast.LENGTH_SHORT).show()
            return
        }
        if (MessageStore.isDemo(key)) {
            Toast.makeText(this, getString(R.string.toast_demo_send, t), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (MessageStore.sendReply(this, key, t)) {
            Toast.makeText(this, getString(R.string.toast_sent), Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(
                this, getString(R.string.toast_cant_send),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openChat() {
        if (MessageStore.openChat(this, key)) finish()
        else Toast.makeText(this, getString(R.string.toast_cant_open), Toast.LENGTH_LONG).show()
    }
}
