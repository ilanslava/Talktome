package com.talktome

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

/** Tela de resposta: digitar ou ditar (Record) e enviar pela notificação do WhatsApp. */
class ReplyActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_KEY = "key"
        const val EXTRA_VOICE = "voice"
    }

    private lateinit var input: EditText
    private var key = ""

    private val colText = Color.parseColor("#EEF0FF")
    private val colDark = Color.parseColor("#0B0E2A")

    // nota de voz: grava aqui e entrega o áudio ao app da conversa
    private var voiceBtn: TextView? = null
    private var recorder: MediaRecorder? = null
    private var outFile: File? = null
    private var voiceStart = 0L
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val s = ((System.currentTimeMillis() - voiceStart) / 1000).toInt()
            val t = String.format(Locale.US, "%d:%02d", s / 60, s % 60)
            voiceBtn?.text = getString(R.string.chip_voice_stop, t)
            ui.postDelayed(this, 500)
        }
    }
    private val micPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startVoice()
            else Toast.makeText(this, getString(R.string.toast_mic_denied), Toast.LENGTH_LONG).show()
        }

    private val dictation =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    val cur = input.text.toString().trim()
                    input.setText(if (cur.isEmpty()) t else "$cur $t")
                    input.setSelection(input.text.length)
                }
            }
        }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, bg: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = ContextCompat.getDrawable(this@ReplyActivity, bg)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = intent.getStringExtra(EXTRA_KEY).orEmpty()
        val conv = MessageStore.conv(key)
        if (conv == null) {
            Toast.makeText(this, getString(R.string.toast_chat_gone), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val cText = Color.parseColor("#EEF0FF")
        val cMuted = Color.parseColor("#A5A9D6")
        val cDark = Color.parseColor("#0B0E2A")

        val last = conv.msgs.lastOrNull()
        val quote = tv(
            if (last == null) "" else if (conv.isGroup && last.sender.isNotBlank())
                "${last.sender}: ${last.text}" else last.text,
            13.5f, cMuted
        ).apply {
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_row)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        input = EditText(this).apply {
            hint = getString(R.string.reply_hint)
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 16f
            minLines = 2
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_input)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        // respostas rápidas: tocar preenche a caixa (você ainda confere antes de enviar)
        val quick = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
            addView(LinearLayout(this@ReplyActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                for (id in intArrayOf(R.string.qr_1, R.string.qr_2, R.string.qr_3, R.string.qr_4)) {
                    val phrase = getString(id)
                    addView(TextView(this@ReplyActivity).apply {
                        text = phrase
                        textSize = 13f
                        setTextColor(cText)
                        setPadding(px(14), px(8), px(14), px(8))
                        background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_chip_indigo)
                        setOnClickListener {
                            val cur = input.text.toString().trim()
                            input.setText(if (cur.isEmpty()) phrase else "$cur $phrase")
                            input.setSelection(input.text.length)
                        }
                    }, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { marginEnd = px(8) })
                }
            })
        }

        fun lp() = LinearLayout.LayoutParams(0, px(48), 1f).apply {
            marginStart = px(3)
            marginEnd = px(3)
        }
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(12) }
            addView(btn(getString(R.string.chip_dictate), R.drawable.bg_chip_indigo, cText) { startDictation() }, lp())
            addView(
                btn(getString(if (conv.isEmail) R.string.send_email else R.string.send), R.drawable.bg_chip_accent, cDark) { send() },
                lp()
            )
        }
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(8) }
            val b = btn(getString(R.string.chip_voice), R.drawable.bg_chip_accent, cDark) { toggleVoice() }
            voiceBtn = b
            addView(b, lp())
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(8) }
            addView(btn(getString(R.string.chip_open_chat), R.drawable.bg_chip_indigo, cText) { openChat() }, lp())
            addView(btn(getString(R.string.cancel), R.drawable.bg_chip_indigo, cText) { finish() }, lp())
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_panel)
            setPadding(px(16), px(16), px(16), px(16))
            isClickable = true // não fecha ao tocar dentro do cartão
            addView(LinearLayout(this@ReplyActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(this@ReplyActivity).apply {
                    setImageResource(R.drawable.app_icon)
                    layoutParams = LinearLayout.LayoutParams(px(30), px(30)).apply { marginEnd = px(10) }
                })
                addView(tv(getString(R.string.reply_title, conv.title, conv.appName), 17f, cText, bold = true))
            })
            addView(quote)
            addView(input)
            addView(quick)
            if (!conv.isEmail) addView(row3) // nota de voz: não faz sentido em e-mail
            addView(row1)
            addView(row2)
        }

        val root = FrameLayout(this).apply {
            setOnClickListener { finish() }
            addView(
                card,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply {
                    setMargins(px(12), px(12), px(12), px(12))
                }
            )
        }
        setContentView(root)

        // só na primeira criação: girar a tela não pode reabrir o ditado
        if (intent.getBooleanExtra(EXTRA_VOICE, false)) {
            if (savedInstanceState == null) window.decorView.post {
                if (conv.isEmail) startDictation() else startVoice()
            }
        } else {
            input.requestFocus()
            window.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
    }

    private fun startDictation() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speak_prompt))
        try {
            dictation.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, getString(R.string.toast_no_recognizer), Toast.LENGTH_LONG).show()
        }
    }

    override fun onStop() {
        super.onStop()
        if (recorder != null) stopVoice(false) // saiu da tela gravando: descarta
    }

    override fun onDestroy() {
        if (recorder != null) stopVoice(false)
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun toggleVoice() {
        if (recorder == null) startVoice() else stopVoice(true)
    }

    @Suppress("DEPRECATION")
    private fun startVoice() {
        if (MessageStore.isDemo(key)) {
            Toast.makeText(this, getString(R.string.toast_demo_voice), Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        Speaker.get(this).stop() // a voz do app não pode entrar na gravação
        val opus = Build.VERSION.SDK_INT >= 29
        val dir = File(cacheDir, "voice").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() } // limpa áudios antigos
        val f = File(dir, "voice_" + System.currentTimeMillis() + if (opus) ".ogg" else ".m4a")
        var r: MediaRecorder? = null
        try {
            r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            if (opus) {
                // mesmo formato das notas de voz do WhatsApp: Ogg/Opus
                r.setOutputFormat(MediaRecorder.OutputFormat.OGG)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
                r.setAudioSamplingRate(16000)
                r.setAudioEncodingBitRate(24000)
            } else {
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioSamplingRate(44100)
                r.setAudioEncodingBitRate(64000)
            }
            r.setAudioChannels(1)
            r.setMaxDuration(5 * 60 * 1000)
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                    ui.post { stopVoice(true) }
                }
            }
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            try { r?.release() } catch (e2: Exception) { /* ignora */ }
            f.delete()
            Toast.makeText(this, getString(R.string.toast_voice_fail), Toast.LENGTH_LONG).show()
            return
        }
        recorder = r
        outFile = f
        voiceStart = System.currentTimeMillis()
        voiceBtn?.apply {
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_chip_indigo)
            setTextColor(colText)
        }
        ui.post(tick)
    }

    private fun resetVoiceBtn() {
        voiceBtn?.apply {
            text = getString(R.string.chip_voice)
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_chip_accent)
            setTextColor(colDark)
        }
    }

    private fun stopVoice(send: Boolean) {
        val r = recorder ?: return
        recorder = null
        ui.removeCallbacks(tick)
        var ok = true
        try {
            r.stop()
        } catch (e: RuntimeException) {
            ok = false // parou cedo demais, sem áudio
        }
        r.release()
        resetVoiceBtn()
        val f = outFile
        outFile = null
        if (!send) {
            f?.delete()
            return
        }
        if (!ok || f == null || f.length() == 0L) {
            f?.delete()
            Toast.makeText(this, getString(R.string.toast_voice_fail), Toast.LENGTH_LONG).show()
            return
        }
        val conv = MessageStore.conv(key)
        val mime = if (f.extension == "ogg") "audio/ogg" else "audio/mp4"
        if (conv != null && VoiceShare.share(this, conv, f, mime)) {
            MessageStore.markAllHeard(key)
            if (conv.pkg.startsWith("com.whatsapp") && conv.waJid == null) {
                // sem o id do chat o WhatsApp abre a lista de contatos; mostra o que a notificação trouxe
                Toast.makeText(
                    this, getString(R.string.toast_wa_no_chat, conv.shortcut?.take(28) ?: "-"), Toast.LENGTH_LONG
                ).show()
            }
            finish()
        } else {
            Toast.makeText(
                this, getString(R.string.toast_no_target, conv?.appName ?: ""), Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) {
            Toast.makeText(this, getString(R.string.toast_write_first), Toast.LENGTH_SHORT).show()
            return
        }
        if (MessageStore.isDemo(key)) {
            Toast.makeText(this, getString(R.string.toast_demo_send, t), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val conv = MessageStore.conv(key)
        if (conv?.isEmail == true) {
            when (MessageStore.draftEmail(this, key, t)) {
                MessageStore.EMAIL_COPIED -> {
                    Toast.makeText(this, getString(R.string.toast_email_copied, conv.appName), Toast.LENGTH_LONG).show()
                    finish()
                }
                MessageStore.EMAIL_DRAFT -> {
                    Toast.makeText(this, getString(R.string.toast_email_draft, conv.appName), Toast.LENGTH_LONG).show()
                    finish()
                }
                else -> Toast.makeText(this, getString(R.string.toast_cant_send), Toast.LENGTH_LONG).show()
            }
            return
        }
        if (MessageStore.sendReply(this, key, t)) {
            Toast.makeText(this, getString(R.string.toast_sent), Toast.LENGTH_SHORT).show()
            finish()
        } else if (MessageStore.draftText(this, key, t)) {
            Toast.makeText(this, getString(R.string.toast_fallback_draft), Toast.LENGTH_LONG).show()
            finish()
        } else {
            Toast.makeText(
                this, getString(R.string.toast_cant_send),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openChat() {
        if (MessageStore.openChat(this, key)) finish()
        else Toast.makeText(this, getString(R.string.toast_cant_open), Toast.LENGTH_LONG).show()
    }
}
