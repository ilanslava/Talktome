package com.talktome

import android.animation.ValueAnimator
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Date
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Bolha flutuante + painel com as mensagens novas.
 * Toque na bolha abre o painel; toque numa mensagem lê em voz alta;
 * depois dá pra responder por voz (Record) ou texto (Type).
 */
class OverlayController(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val dm: DisplayMetrics get() = ctx.resources.displayMetrics
    private fun px(v: Int) = (v * dm.density).toInt()

    private val cText = Color.parseColor("#EEF0FF")
    private val cMuted = Color.parseColor("#A5A9D6")
    private val cAccent = Color.parseColor("#A5B4FC")
    private val cDark = Color.parseColor("#0B0E2A")

    private var started = false
    private val speaker: Speaker get() = Speaker.get(ctx)
    private var speaking = false
    private var lastDownAt = 0L

    // bolha
    private lateinit var bubble: BubbleView
    private var sizeAnim: ValueAnimator? = null
    private var ballTarget = -1f
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var bubbleAttached = false
    private var bubbleSize = 0
    private var lastW = 0
    private var lastH = 0

    // painel
    private lateinit var panel: LinearLayout
    private lateinit var subtitle: TextView
    private lateinit var stopChip: TextView
    private lateinit var list: LinearLayout
    private lateinit var scroll: MaxHeightScrollView
    private lateinit var actions: LinearLayout
    private var panelAttached = false
    private var closedOutsideAt = 0L

    // mensagem selecionada
    private var selKey: String? = null
    private var selSig: String? = null

    private val storeListener: () -> Unit = { refresh() }

    private val speakListener = object : Speaker.Listener {
        override fun onSpeaking(speaking: Boolean) {
            this@OverlayController.speaking = speaking
            updateSpeakingUi()
        }

        override fun onFail() {
            if (!MainActivity.visible) toast(ctx.getString(R.string.toast_no_tts))
        }
    }

    /** Modo mãos livres: lê cada mensagem nova assim que chega (entra na fila). */
    private val newListener: (MessageStore.Conv, List<MessageStore.Msg>) -> Unit = { c, msgs ->
        // não lê em voz alta no "Não perturbe"; as mensagens ficam como novas na bolha
        if (Prefs.autoRead(ctx) && !dndActive()) {
            val voiced = withVoice(msgs)
            val spoke = voiced.isEmpty() || speaker.speak(
                "${c.title}, ${c.appName}.\n" + voiced.joinToString("\n") { lineFor(c, it) }, flush = false
            )
            if (spoke) MessageStore.markHeardMany(c.key, msgs)
        }
    }

    private fun dndActive(): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return false
        // 2 = só prioritárias, 3 = nenhuma interrupção, 4 = só alarmes
        return nm.currentInterruptionFilter in 2..4
    }

    // ------------------------------------------------------------ ciclo de vida

    fun start() {
        if (started) return
        started = true
        speaker.addListener(speakListener)
        buildBubble()
        buildPanel()
        MessageStore.addListener(storeListener)
        MessageStore.addNewListener(newListener)
        refresh()
    }

    fun stop() {
        if (!started) return
        started = false
        MessageStore.removeListener(storeListener)
        MessageStore.removeNewListener(newListener)
        main.removeCallbacksAndMessages(null)
        detachPanel()
        detachBubble()
        speaker.removeListener(speakListener)
        speaker.stop()
    }

    /** Mostra/esconde a bolha e atualiza o painel conforme as mensagens e permissões. */
    fun refresh() {
        if (!started) return
        if (!Settings.canDrawOverlays(ctx)) return
        val unheard = MessageStore.unheardCount()
        val show = Prefs.alwaysShow(ctx) || unheard > 0 || panelAttached
        updateBubble(unheard)
        if (show) attachBubble() else detachBubble()
        if (panelAttached) rebuildPanel()
    }

    // ------------------------------------------------------------ bolha

    private fun buildBubble() {
        bubble = BubbleView(ctx).apply {
            ball = ballPxFor(0)
            contentDescription = ctx.getString(R.string.bubble_cd)
            setOnClickListener { togglePanel() } // também é o que o TalkBack aciona
        }
        ballTarget = bubble.ball
        bubbleSize = bubble.windowSize()

        // a posição salva é de uma borda; o tamanho da janela muda com o número de mensagens
        val savedX = Prefs.btnX(ctx)
        val startX = when {
            savedX < 0 -> dm.widthPixels - bubbleSize - px(8)
            savedX + bubbleSize / 2 >= dm.widthPixels / 2 -> max(0, dm.widthPixels - bubbleSize)
            else -> 0
        }
        val startY = Prefs.btnY(ctx).takeIf { it >= 0 } ?: (dm.heightPixels * 0.55).toInt()
        bubbleParams = WindowManager.LayoutParams(
            bubbleSize, bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
        }

        lastW = dm.widthPixels
        lastH = dm.heightPixels
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var ox = 0
            var oy = 0
            var downX = 0f
            var downY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lastDownAt = SystemClock.uptimeMillis()
                        ox = bubbleParams.x
                        oy = bubbleParams.y
                        downX = e.rawX
                        downY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && hypot(dx, dy) > slop) moved = true
                        if (moved) {
                            bubbleParams.x = (ox + dx).toInt()
                                .coerceIn(0, max(0, dm.widthPixels - bubbleSize))
                            bubbleParams.y = (oy + dy).toInt()
                                .coerceIn(0, max(0, dm.heightPixels - bubbleSize))
                            runCatching { wm.updateViewLayout(bubble, bubbleParams) }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) snapToEdge() else v.performClick()
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        if (moved) snapToEdge()
                    }
                }
                return true
            }
        })
    }

    /** Tela girou (ou dobrou): mantém a bolha no mesmo lado e dentro da tela. */
    fun onConfigChanged() {
        if (!started) return
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (w == lastW && h == lastH) return
        val onRight = lastW > 0 && bubbleParams.x + bubbleSize / 2 >= lastW / 2
        val yFrac = if (lastH > 0) bubbleParams.y.toFloat() / lastH else 0.55f
        bubbleParams.x = if (onRight) max(0, w - bubbleSize) else 0
        bubbleParams.y = (yFrac * h).toInt().coerceIn(0, max(0, h - bubbleSize))
        lastW = w
        lastH = h
        Prefs.setBtnPos(ctx, bubbleParams.x, bubbleParams.y)
        if (bubbleAttached) runCatching { wm.updateViewLayout(bubble, bubbleParams) }
        if (panelAttached) closePanel() // a largura do painel muda com a tela
    }

    /** Ao soltar a bolha, ela gruda na borda mais próxima (fica fora do caminho). */
    private fun snapToEdge() {
        val target = if (bubbleParams.x + bubbleSize / 2 < dm.widthPixels / 2) 0
        else max(0, dm.widthPixels - bubbleSize)
        Prefs.setBtnPos(ctx, target, bubbleParams.y)
        ValueAnimator.ofInt(bubbleParams.x, target).apply {
            duration = 180
            addUpdateListener {
                bubbleParams.x = it.animatedValue as Int
                runCatching { wm.updateViewLayout(bubble, bubbleParams) }
            }
            start()
        }
    }

    private fun attachBubble() {
        if (bubbleAttached) return
        bubbleParams.x = bubbleParams.x.coerceIn(0, max(0, dm.widthPixels - bubbleSize))
        bubbleParams.y = bubbleParams.y.coerceIn(0, max(0, dm.heightPixels - bubbleSize))
        runCatching {
            wm.addView(bubble, bubbleParams)
            bubbleAttached = true
        }
    }

    private fun detachBubble() {
        if (!bubbleAttached) return
        sizeAnim?.cancel()
        runCatching { wm.removeView(bubble) }
        bubbleAttached = false
    }

    /** Diâmetro da bolinha: discreta; com 5+ mensagens novas cresce, e mais um pouco a cada nova. */
    private fun ballPxFor(n: Int): Float {
        val dp = when {
            n <= 0 -> 36f
            n < 5 -> 40f
            else -> min(72f, 48f + 3f * (n - 5))
        }
        return dp * dm.density
    }

    private fun updateBubble(n: Int) {
        bubble.count = n
        val target = ballPxFor(n)
        if (target == ballTarget) return
        ballTarget = target
        sizeAnim?.cancel()
        if (!bubbleAttached) { // ainda fora da tela: ajusta direto, sem animar
            bubble.ball = target
            resizeBubbleWindow()
            return
        }
        sizeAnim = ValueAnimator.ofFloat(bubble.ball, target).apply {
            duration = 320
            interpolator = if (target > bubble.ball) OvershootInterpolator(2.2f) else DecelerateInterpolator()
            addUpdateListener {
                bubble.ball = it.animatedValue as Float
                resizeBubbleWindow()
            }
            start()
        }
    }

    /** Ajusta a janela ao tamanho da bolinha mantendo o centro (ou a borda da tela, se estiver grudada). */
    private fun resizeBubbleWindow() {
        val newS = bubble.windowSize()
        if (newS == bubbleSize) return
        val old = bubbleSize
        val w = dm.widthPixels
        val h = dm.heightPixels
        val atRight = bubbleParams.x + old >= w - 2
        val atLeft = bubbleParams.x <= 2
        val nx = when {
            atRight -> w - newS
            atLeft -> 0
            else -> bubbleParams.x + (old - newS) / 2
        }
        val ny = bubbleParams.y + (old - newS) / 2
        bubbleSize = newS
        bubbleParams.width = newS
        bubbleParams.height = newS
        bubbleParams.x = nx.coerceIn(0, max(0, w - newS))
        bubbleParams.y = ny.coerceIn(0, max(0, h - newS))
        if (bubbleAttached) runCatching { wm.updateViewLayout(bubble, bubbleParams) }
    }

    private fun updateSpeakingUi() {
        if (!started || !::bubble.isInitialized) return
        bubble.speaking = speaking
        stopChip.visibility = if (speaking) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------ painel

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun chip(t: String, bg: Int, color: Int, size: Float = 13f, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(px(12), px(8), px(12), px(8))
            background = ContextCompat.getDrawable(ctx, bg)
            setOnClickListener { onClick() }
        }

    private fun chipLp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { marginStart = px(6) }

    private fun buildPanel() {
        subtitle = tv("", 12.5f, cMuted)
        val titleCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(ctx.getString(R.string.app_name), 17f, cText, bold = true))
            addView(subtitle)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        stopChip = chip(ctx.getString(R.string.chip_stop), R.drawable.bg_chip_indigo, cText) { speaker.stop() }
            .apply { visibility = View.GONE }
        val allChip = chip(ctx.getString(R.string.chip_read_all), R.drawable.bg_chip_accent, cDark) { readAll() }
        val closeChip = chip("✕", R.drawable.bg_chip_indigo, cText) { closePanel() }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(ctx).apply {
                setImageResource(R.drawable.app_icon)
                layoutParams = LinearLayout.LayoutParams(px(34), px(34)).apply { marginEnd = px(10) }
            })
            addView(titleCol)
            addView(stopChip, chipLp())
            addView(allChip, chipLp())
            addView(closeChip, chipLp())
        }

        list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll = MaxHeightScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(8) }
        }

        fun actionLp() = LinearLayout.LayoutParams(0, px(44), 1f).apply {
            marginStart = px(3)
            marginEnd = px(3)
        }
        actions = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(12) }
            addView(chip(ctx.getString(R.string.chip_record), R.drawable.bg_chip_accent, cDark, 14f) { launchReply(true) }, actionLp())
            addView(chip(ctx.getString(R.string.chip_type), R.drawable.bg_chip_indigo, cText, 14f) { launchReply(false) }, actionLp())
            addView(chip(ctx.getString(R.string.chip_open_chat), R.drawable.bg_chip_indigo, cText, 14f) { openSelectedChat() }, actionLp())
        }

        panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_panel)
            setPadding(px(16), px(14), px(16), px(16))
            elevation = px(12).toFloat()
            addView(header)
            addView(scroll)
            addView(actions)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    closedOutsideAt = SystemClock.uptimeMillis()
                    main.post { closePanel() }
                    true
                } else false
            }
        }
    }

    private fun panelParams() = WindowManager.LayoutParams(
        min(dm.widthPixels - px(24), px(520)),
        ViewGroup.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = px(48)
    }

    private fun togglePanel() {
        if (panelAttached) closePanel()
        // tocar na bolha com o painel aberto gera ACTION_OUTSIDE junto com o toque: só fecha
        else if (closedOutsideAt < lastDownAt - 250) openPanel()
    }

    private fun openPanel() {
        if (panelAttached) return
        scroll.maxH = (dm.heightPixels * 0.5).toInt() // recalcula (a tela pode ter girado)
        rebuildPanel()
        runCatching {
            wm.addView(panel, panelParams())
            panelAttached = true
        }
    }

    private fun closePanel() {
        detachPanel()
        refresh()
    }

    private fun detachPanel() {
        if (!panelAttached) return
        runCatching { wm.removeView(panel) }
        panelAttached = false
    }

    private fun rebuildPanel() {
        val convs = MessageStore.conversations()
        val unheard = MessageStore.unheardCount()
        subtitle.text = if (convs.isEmpty()) ctx.getString(R.string.sub_none)
        else ctx.resources.getQuantityString(R.plurals.sub_chats, convs.size, unheard, convs.size)

        list.removeAllViews()
        if (convs.isEmpty()) {
            list.addView(tv(ctx.getString(R.string.nothing_new), 14f, cMuted).apply {
                setPadding(0, px(14), 0, px(6))
            })
        }
        for (c in convs) {
            list.addView(convHeader(c))
            for (m in c.msgs) list.addView(row(c, m))
        }
        actions.visibility = if (selKey?.let { MessageStore.conv(it) } != null) View.VISIBLE else View.GONE
    }

    private fun convHeader(c: MessageStore.Conv): View {
        val n = c.msgs.size
        val title = tv("${c.title}  ·  ${c.appName}  ·  $n", 13f, cAccent, bold = true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(14) }
            addView(title)
            addView(chip(ctx.getString(R.string.chip_chat), R.drawable.bg_chip_indigo, cText, 12f) { readChat(c) }, chipLp())
        }
    }

    private fun row(c: MessageStore.Conv, m: MessageStore.Msg): View {
        val selected = c.key == selKey && m.sig == selSig
        val time = DateFormat.getTimeFormat(ctx).format(Date(m.time))
        val head = if (c.isGroup && m.sender.isNotBlank()) "${m.sender} · $time" else time

        val dot = View(ctx).apply {
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_dot)
            visibility = if (m.heard) View.INVISIBLE else View.VISIBLE
            layoutParams = LinearLayout.LayoutParams(px(8), px(8)).apply { marginEnd = px(10) }
        }
        val body = tv(m.text, 15f, if (m.heard) cMuted else cText).apply {
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(tv(head, 11.5f, cMuted))
            addView(body)
        }
        val play = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_play)
            layoutParams = LinearLayout.LayoutParams(px(28), px(28)).apply { marginStart = px(8) }
        }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ContextCompat.getDrawable(
                ctx, if (selected) R.drawable.bg_row_selected else R.drawable.bg_row
            )
            setPadding(px(12), px(10), px(10), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(6) }
            addView(dot)
            addView(col)
            addView(play)
            setOnClickListener { onMessageTap(c, m) }
        }
    }

    // ------------------------------------------------------------ ações

    /** Só as mensagens com algo pra falar: emoji não é lido, então mensagem só de emoji fica de fora. */
    private fun withVoice(msgs: List<MessageStore.Msg>) =
        msgs.filter { cleanForSpeech(it.text, "link").isNotBlank() }

    private fun lineFor(c: MessageStore.Conv, m: MessageStore.Msg) =
        if (c.isGroup && m.sender.isNotBlank()) "${m.sender}: ${m.text}" else m.text

    private fun onMessageTap(c: MessageStore.Conv, m: MessageStore.Msg) {
        selKey = c.key
        selSig = m.sig
        val ok = cleanForSpeech(m.text, "link").isBlank() || speaker.speak(lineFor(c, m))
        if (ok) MessageStore.markHeard(c.key, m) // atualiza o painel
        else refresh()
    }

    private fun readChat(c: MessageStore.Conv) {
        val fresh = c.msgs.filter { !it.heard }
        val toRead = if (fresh.isNotEmpty()) fresh else c.msgs
        if (toRead.isEmpty()) return
        val voiced = withVoice(toRead)
        val ok = voiced.isEmpty() || speaker.speak(voiced.joinToString("\n") { lineFor(c, it) })
        if (ok) MessageStore.markAllHeard(c.key)
    }

    private fun readAll() {
        val parts = ArrayList<String>()
        var anyNew = false
        for (c in MessageStore.conversations().reversed()) { // mais antigas primeiro
            val fresh = c.msgs.filter { !it.heard }
            if (fresh.isEmpty()) continue
            anyNew = true
            val v = withVoice(fresh)
            if (v.isNotEmpty()) parts.add("${c.title}, ${c.appName}.\n" + v.joinToString("\n") { lineFor(c, it) })
        }
        if (!anyNew) {
            toast(ctx.getString(R.string.toast_nothing_new))
            return
        }
        if (parts.isEmpty() || speaker.speak(parts.joinToString("\n"))) MessageStore.markAllHeard()
    }

    private fun launchReply(voice: Boolean) {
        val key = selKey ?: return
        speaker.stop()
        val i = Intent(ctx, ReplyActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(ReplyActivity.EXTRA_KEY, key)
            .putExtra(ReplyActivity.EXTRA_VOICE, voice)
        try {
            // primeiro abre a tela (o painel ainda é uma janela visível, o que o Android 14/15
            // exige pra liberar a abertura em segundo plano); só depois fecha o painel
            ctx.startActivity(i)
            closePanel()
        } catch (e: Exception) {
            toast(ctx.getString(R.string.toast_no_reply_screen))
        }
    }

    private fun openSelectedChat() {
        val key = selKey ?: return
        if (MessageStore.openChat(ctx, key)) closePanel()
        else toast(ctx.getString(R.string.toast_cant_open))
    }

    private fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
}

internal class MaxHeightScrollView(ctx: Context) : ScrollView(ctx) {
    var maxH: Int = Int.MAX_VALUE

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}
