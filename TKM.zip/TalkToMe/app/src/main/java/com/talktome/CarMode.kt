package com.talktome

import android.content.Context

/** Estado do modo carro: ligado na mão, ou sozinho (modo carro do Android / Android Auto / Bluetooth do carro). */
object CarMode {
    @Volatile var uiCar = false
    @Volatile var btCar = false

    fun isOn(ctx: Context): Boolean =
        Prefs.carManual(ctx) || (Prefs.carAuto(ctx) && (uiCar || btCar))
}
