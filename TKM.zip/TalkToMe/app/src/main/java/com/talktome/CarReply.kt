package com.talktome

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import java.text.Normalizer

/**
 * Modo carro: depois de ler uma mensagem, pergunta "Responder?" e conduz a resposta só por voz:
 * sim → fale a mensagem → confirma o que ouviu → sim → envia (pela resposta da notificação).
 * Usa o reconhecimento de voz do celular só para entender o "sim" e o texto.
 */
class CarReply(
    private val ctx: Context,
    private val speaker: () -> Speaker,
    private val onChanged: () -> Unit
) {
    private enum class St { IDLE, ASK, WAIT_YES, ASK_TEXT, WAIT_TEXT, CONFIRM, WAIT_CONFIRM }

    private var st = St.IDLE
    private var conv: MessageStore.Conv? = null
    private var draft = ""
    private var rec: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    val busy: Boolean get() = st != St.IDLE

    fun start(c: MessageStore.Conv) {
        if (st != St.IDLE) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return
        conv = c
        st = St.ASK
        onChanged()
        say(ctx.getString(R.string.car_ask, c.title))
    }

    /** O OverlayController avisa quando uma fala termina: aí é a vez de escutar. */
    fun onSpeechEnded() {
        when (st) {
            St.ASK -> {
                st = St.WAIT_YES
                listen()
            }
            St.ASK_TEXT -> {
                st = St.WAIT_TEXT
                listen()
            }
            St.CONFIRM -> {
                st = St.WAIT_CONFIRM
                listen()
            }
            else -> {}
        }
    }

    fun cancel() {
        destroyRec()
        if (st != St.IDLE) {
            st = St.IDLE
            conv = null
            draft = ""
            onChanged()
        }
    }

    private fun say(text: String) {
        if (!speaker().speak(text)) finish(null)
    }

    private fun listen() {
        destroyRec()
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) {
                    handle("")
                }
                override fun onResults(results: Bundle?) {
                    val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    handle(t)
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            r.startListening(i)
        } catch (e: Exception) {
            finish(null)
        }
    }

    private fun handle(text: String) {
        main.post {
            destroyRec()
            when (st) {
                St.WAIT_YES ->
                    if (isYes(text)) {
                        st = St.ASK_TEXT
                        say(ctx.getString(R.string.car_go))
                    } else finish(null)
                St.WAIT_TEXT ->
                    if (text.isBlank()) finish(null)
                    else {
                        draft = text
                        st = St.CONFIRM
                        say(ctx.getString(R.string.car_confirm, text))
                    }
                St.WAIT_CONFIRM ->
                    if (isYes(text)) send() else finish(R.string.car_cancelled)
                else -> {}
            }
        }
    }

    private fun send() {
        val c = conv
        val ok = c != null && MessageStore.sendReply(ctx, c.key, draft)
        finish(if (ok) R.string.car_sent else R.string.car_fail)
    }

    private fun finish(finalMsg: Int?) {
        destroyRec()
        st = St.IDLE
        conv = null
        draft = ""
        if (finalMsg != null) speaker().speak(ctx.getString(finalMsg))
        onChanged()
    }

    private fun destroyRec() {
        try {
            rec?.destroy()
        } catch (e: Exception) {
            // ignora
        }
        rec = null
    }

    private fun tokens(t: String): List<String> =
        Normalizer.normalize(t.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .split(Regex("[^a-z]+"))
            .filter { it.isNotEmpty() }

    private fun isYes(t: String): Boolean {
        val w = tokens(t)
        return w.any { it in YES } && w.none { it in NO }
    }

    private companion object {
        val YES = setOf(
            "yes", "yeah", "yep", "sure", "ok", "okay", "send", "reply",
            "sim", "claro", "pode", "manda", "mande", "enviar", "envia", "responder", "responde", "quero"
        )
        val NO = setOf("no", "not", "nope", "cancel", "cancelar", "nao", "pare", "para", "stop", "deixa", "negativo")
    }
}
