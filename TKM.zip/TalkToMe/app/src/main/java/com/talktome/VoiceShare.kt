package com.talktome

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/** Entrega um áudio gravado ao app da conversa (WhatsApp, Messenger...) pelo compartilhar do Android. */
object VoiceShare {

    fun share(act: Activity, conv: MessageStore.Conv, f: File, mime: String): Boolean {
        val uri = try {
            FileProvider.getUriForFile(act, act.packageName + ".files", f)
        } catch (e: Exception) {
            return false
        }
        val base = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        base.clipData = ClipData.newRawUri("voice", uri)

        // direto no app da conversa; no WhatsApp, o jid abre a conversa certa (não documentado)
        val direct = Intent(base).setPackage(conv.pkg)
        val jid = conv.shortcut
        if (conv.pkg.startsWith("com.whatsapp") && jid != null && jid.contains("@")) {
            direct.putExtra("jid", jid)
        }
        return try {
            act.startActivity(direct)
            true
        } catch (e: Exception) {
            try {
                act.startActivity(Intent.createChooser(base, conv.appName))
                true
            } catch (e2: Exception) {
                false
            }
        }
    }
}
