package com.talktome

import android.content.Context

/** Nome amigável do app (Instagram, Telegram...) a partir do pacote. */
fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}

private val CODE_WORDS = Regex(
    "(?i)(code|c[oó]digo|otp|verification|verifica[cç][aã]o|senha|password|token|\\bpin\\b|2fa)"
)
private val CODE_DIGITS = Regex("\\b\\d{4,8}\\b|\\b\\d{3}[- ]\\d{3}\\b")

/** Mensagem com código de verificação/login (SMS de banco, 2FA...). */
fun looksLikeCode(text: String): Boolean =
    CODE_WORDS.containsMatchIn(text) && CODE_DIGITS.containsMatchIn(text)

private val URL_RE = Regex("(https?://|www\\.)\\S+")

// emoji, símbolos/pictogramas, bandeiras, teclas (1️⃣), modificadores de tom de pele e afins
private val EMOJI_RE = Regex(
    "[\\u2600-\\u27BF\\u2B00-\\u2BFF\\u2300-\\u23FF\\u25A0-\\u25FF\\u203C\\u2049\\u2122\\u2139" +
        "\\u3030\\u303D\\u3297\\u3299\\u00A9\\u00AE\\uFE0F\\u200D\\u20E3" +
        "\\x{1F000}-\\x{1FBFF}\\x{E0020}-\\x{E007F}]"
)

// carinhas de texto: :) :D ;P :/ :3 <3 (só quando isoladas, pra não mexer em "10:30" ou "a:b")
private val EMOTICON_RE = Regex("(?<!\\w)[:;=][-^']?[)(DPp/\\\\|*3]+(?!\\w)|(?<!\\w)<3+(?!\\w)")
private val SPACES_RE = Regex("[ \\t]{2,}")

/**
 * Prepara o texto pra voz: emoji e carinhas somem (não são lidos) e links viram "link".
 * Mensagem só de emoji vira texto vazio: não há nada pra falar.
 */
fun cleanForSpeech(text: String, linkWord: String): String =
    text.replace(URL_RE, " $linkWord ")
        .replace(EMOJI_RE, "")
        .replace(EMOTICON_RE, "")
        .replace(SPACES_RE, " ")
        .lines()
        .joinToString("\n") { it.trim() }
        .trim()

// ---------------------------------------------------------------- idioma da mensagem

private val STOPWORDS: Map<String, Set<String>> = mapOf(
    "pt" to ("de que o os as um uma uns umas para pra com nao nos voce voces vc tudo bem oi ola obrigado " +
        "obrigada muito mais mas por como esta estou eu ele ela isso esse essa aqui ja vai vou vamos hoje " +
        "amanha onde quando quem sim talvez bom boa dia noite tarde meu minha seu sua tem foi sao em do da " +
        "dos das ao nem tambem agora depois ainda so la ate quero posso preciso pode").split(" ").toSet(),
    "en" to ("the and you are is to of in it that for with this have not but what your my we they be was " +
        "will can do on at just hi hello thanks thank please yes how when where who good morning night " +
        "today tomorrow im ill dont cant its i am he she there here now then later want need okay").split(" ").toSet(),
    "es" to ("el la los las un una que de y en es por con para como pero mas muy yo tu usted estoy esta " +
        "estas bien hola gracias si ya hoy manana donde cuando quien bueno buena dia noche tarde quiero " +
        "puedo tengo hay esto eso aqui alli nos tambien ahora despues").split(" ").toSet(),
    "fr" to ("le la les un une des est et que pas pour avec je tu il elle nous vous ils sont suis bonjour " +
        "salut merci oui non ca va bien tres mais dans sur ce cette aujourd demain ou quand qui bonsoir " +
        "aussi maintenant").split(" ").toSet(),
    "de" to ("der die das und ist nicht ich du er sie wir ihr ein eine mit fur auf zu von ja nein danke " +
        "bitte gut heute morgen wo wann wer hallo guten tag nacht auch jetzt").split(" ").toSet(),
    "it" to ("il lo la i gli le un una che di e non per con io tu lui lei noi voi sono ciao grazie si " +
        "come bene molto ma oggi domani dove quando chi buongiorno buonasera anche adesso").split(" ").toSet()
)

private val DIACRITICS_RE = Regex("\\p{M}+")
private val WORD_RE = Regex("[a-z]+")

private fun fold(s: String): String =
    java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(DIACRITICS_RE, "")

/**
 * Idioma provável de uma mensagem ("pt", "en", "es", "fr", "de", "it") ou null se não der pra ter
 * certeza (mensagem curta demais, ambígua...). Funciona offline, só com listas de palavras comuns.
 */
fun detectLanguage(text: String): String? {
    val words = WORD_RE.findAll(fold(text)).map { it.value }.toList()
    if (words.isEmpty()) return null
    val score = HashMap<String, Int>()
    for ((lang, set) in STOPWORDS) score[lang] = words.count { it in set }
    val low = text.lowercase()
    fun bump(lang: String, n: Int) { score[lang] = (score[lang] ?: 0) + n }
    if (low.any { it == 'ã' || it == 'õ' }) bump("pt", 2)
    if ('ç' in low) { bump("pt", 1); bump("fr", 1) }
    if (low.any { it == 'ñ' || it == '¿' || it == '¡' }) bump("es", 2)
    if ('ß' in low) bump("de", 2)
    if (low.any { it == 'ä' || it == 'ö' || it == 'ü' }) bump("de", 1)
    if (low.any { it in "èùâêîôûœ" }) bump("fr", 1)
    val sorted = score.entries.sortedByDescending { it.value }
    val top = sorted[0]
    val second = if (sorted.size > 1) sorted[1].value else 0
    if (top.value >= 2 && top.value > second) return top.key
    if (top.value >= 1 && words.size <= 3 && second == 0) return top.key
    return null
}

/** Quebra o texto em pedaços de até [max] caracteres, de preferência no fim de linha ou frase. */
fun chunkText(text: String, max: Int): List<String> {
    val out = ArrayList<String>()
    var rest = text
    while (rest.length > max) {
        var cut = rest.lastIndexOf('\n', max)
        if (cut < max / 2) {
            val s = maxOf(rest.lastIndexOf(". ", max), rest.lastIndexOf("? ", max), rest.lastIndexOf("! ", max))
            cut = if (s >= max / 2) s + 1 else -1
        }
        if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
        if (cut < max / 2) cut = max
        val piece = rest.substring(0, cut).trim()
        if (piece.isNotEmpty()) out.add(piece)
        rest = rest.substring(cut).trim()
    }
    if (rest.isNotBlank()) out.add(rest)
    return out
}
