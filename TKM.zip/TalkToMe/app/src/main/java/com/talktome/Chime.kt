package com.talktome

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Toque curto e suave de mensagem nova, gerado no código (não precisa de arquivo de áudio). */
object Chime {
    const val DURATION_MS = 420
    private const val RATE = 44100
    private const val MIN_GAP_MS = 1200L

    private val main = Handler(Looper.getMainLooper())
    private var lastAt = 0L

    private val pcm: ShortArray by lazy { render() }

    private fun render(): ShortArray {
        val n = RATE * DURATION_MS / 1000
        val buf = DoubleArray(n)
        // duas notas agudas (dó e sol); a segunda entra um pouco depois e as duas se apagam devagar
        fun note(startMs: Int, freq: Double, gain: Double) {
            val s0 = RATE * startMs / 1000
            for (i in s0 until n) {
                val t = (i - s0).toDouble() / RATE
                val attack = if (t < 0.008) t / 0.008 else 1.0
                val env = attack * exp(-t * 9.0)
                buf[i] += (sin(2 * PI * freq * t) + 0.25 * sin(4 * PI * freq * t)) * env * gain
            }
        }
        note(0, 1046.5, 1.0)
        note(110, 1568.0, 0.85)
        val fade = RATE / 50 // 20 ms no fim, pra não estalar
        return ShortArray(n) { i ->
            val f = if (i >= n - fade) (n - i).toDouble() / fade else 1.0
            (buf[i] * f * 32767.0 * 0.30).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    /** Toca uma vez. Fica quieto no modo silencioso/vibrar, durante chamadas e se tocou há instantes. */
    fun play(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION) return
            val now = SystemClock.uptimeMillis()
            if (now - lastAt < MIN_GAP_MS) return
            lastAt = now

            val data = pcm
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(data, 0, data.size)
            track.setVolume(0.7f)
            track.play()
            main.postDelayed({ runCatching { track.release() } }, DURATION_MS + 300L)
        } catch (e: Exception) {
            // sem som, tudo bem
        }
    }
}
