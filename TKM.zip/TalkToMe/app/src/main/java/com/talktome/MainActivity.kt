package com.talktome

import android.content.ComponentName
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        /** true enquanto a tela inicial está aberta (a bolha não repete avisos nesse caso). */
        @Volatile
        var visible = false

        /** Estático para sobreviver a girar a tela enquanto as configurações de voz estão abertas. */
        @Volatile
        var voiceSettingsOpened = false
    }

    private lateinit var status: TextView
    private lateinit var appsBox: LinearLayout

    private val failListener = object : Speaker.Listener {
        override fun onFail() = toast(getString(R.string.toast_no_voice))
    }

    private val cText = Color.parseColor("#EEF0FF")
    private val cMuted = Color.parseColor("#A5A9D6")
    private val cAccent = Color.parseColor("#A5B4FC")
    private val cIndigo = Color.parseColor("#4F46E5")
    private val cDark = Color.parseColor("#0B0E2A")

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, color: Int = cText, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.15f)
        }

    private fun card(vararg views: View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_card)
            setPadding(px(18), px(16), px(18), px(18))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(16) }
            views.forEach { addView(it) }
        }

    private fun section(t: String) = label(t.uppercase(), 12f, cAccent, bold = true).apply {
        letterSpacing = 0.12f
        setPadding(0, 0, 0, px(8))
    }

    private fun hint(t: String, top: Int = 6) =
        label(t, 12.5f, cMuted).apply { setPadding(0, px(top), 0, 0) }

    private fun bigButton(t: String, bg: Int, textColor: Int, onClick: () -> Unit) =
        Button(this).apply {
            text = t
            transformationMethod = null
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
            background = ContextCompat.getDrawable(this@MainActivity, bg)
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(52)
            ).apply { topMargin = px(10) }
            setOnClickListener { onClick() }
        }

    private fun toggle(t: String, checked: Boolean, top: Int, onChange: (Boolean) -> Unit) =
        Switch(this).apply {
            text = t
            setTextColor(cText)
            textSize = 14.5f
            isChecked = checked
            thumbTintList = ColorStateList.valueOf(cAccent)
            trackTintList = ColorStateList.valueOf(cIndigo)
            setPadding(0, px(top), 0, 0)
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }

    private lateinit var carBtHint: TextView

    private fun carBtText(): String {
        val n = Prefs.carBtName(this)
        return if (n.isNullOrBlank()) getString(R.string.car_bt_none_chosen) else getString(R.string.car_bt_chosen, n)
    }

    private fun askAudio() {
        val p = VoiceNote.permission()
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(p), 9)
        } else {
            toast(getString(R.string.voice_allowed))
        }
    }

    private fun askMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
        }
    }

    @Suppress("MissingPermission")
    private fun pickCarBluetooth() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 7) // depois de permitir, abre a lista
            return
        }
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager)?.adapter
        val devices = try {
            adapter?.bondedDevices?.toList().orEmpty()
        } catch (e: SecurityException) {
            emptyList()
        }
        if (devices.isEmpty()) {
            toast(getString(R.string.car_bt_empty))
            return
        }
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle(R.string.car_pick_bt)
            .setItems(names) { _, i ->
                Prefs.setCarBt(this, devices[i].address, names[i])
                carBtHint.text = carBtText()
            }
            .setNeutralButton(R.string.car_bt_clear) { _, _ ->
                Prefs.setCarBt(this, null, null)
                carBtHint.text = carBtText()
            }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) pickCarBluetooth()
    }

    private fun styleSeek(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(cAccent)
        s.thumbTintList = ColorStateList.valueOf(cAccent)
        s.progressBackgroundTintList = ColorStateList.valueOf(cIndigo)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun notifAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun overlayOk() = Settings.canDrawOverlays(this)

    private fun openSettings(intent: Intent, fallback: Intent = Intent(Settings.ACTION_SETTINGS)) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try { startActivity(fallback) } catch (e2: Exception) { /* sem tela de ajustes */ }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(36), px(20), px(32))
        }

        // cabeçalho com o ícone do app
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(label(getString(R.string.app_name), 30f, cText, bold = true))
        }
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.app_icon)
                contentDescription = getString(R.string.app_name)
                layoutParams = LinearLayout.LayoutParams(px(76), px(76)).apply { marginEnd = px(16) }
            })
            addView(titleCol)
        })
        col.addView(label(getString(R.string.tagline), 15f, cMuted).apply {
            setPadding(0, px(12), 0, 0)
        })

        status = label("", 14f, cAccent, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(px(18), px(8), px(18), px(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(18) }
        }
        col.addView(status)

        col.addView(card(
            section(getString(R.string.section_setup)),
            bigButton(getString(R.string.step1), R.drawable.bg_btn_primary, cDark) {
                openSettings(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            },
            hint(getString(R.string.step1_hint), 8),
            bigButton(getString(R.string.step2), R.drawable.bg_btn_primary, cDark) {
                openSettings(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            },
            bigButton(getString(R.string.step3), R.drawable.bg_btn_secondary, cText) {
                voiceSettingsOpened = true
                openSettings(Intent("com.android.settings.TTS_SETTINGS"))
            },
            bigButton(getString(R.string.step4), R.drawable.bg_btn_secondary, cText) {
                openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            hint(getString(R.string.step4_hint), 8),
            bigButton(getString(R.string.test_voice), R.drawable.bg_btn_secondary, cText) {
                Speaker.get(this).speak(getString(R.string.test_voice_text))
            },
            bigButton(getString(R.string.demo_show), R.drawable.bg_btn_secondary, cText) {
                val l = TalkListener.instance
                when {
                    l == null -> toast(getString(R.string.toast_need_notif))
                    !overlayOk() -> toast(getString(R.string.toast_need_overlay))
                    else -> {
                        MessageStore.addDemo(this)
                        l.refreshOverlay()
                    }
                }
            },
            bigButton(getString(R.string.demo_clear), R.drawable.bg_btn_secondary, cText) {
                MessageStore.removeDemo()
                TalkListener.instance?.refreshOverlay()
            }
        ))

        val rateLabel = label("", 14.5f)
        fun updateRate(r: Float) { rateLabel.text = getString(R.string.voice_speed, r) }
        updateRate(Prefs.rate(this))
        val rateSeek = SeekBar(this).apply {
            max = 150
            progress = Math.round((Prefs.rate(this@MainActivity) - 0.5f) * 100)
            styleSeek(this)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 100f
                    Prefs.setRate(this@MainActivity, r)
                    updateRate(r)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(card(
            section(getString(R.string.section_settings)),
            rateLabel,
            rateSeek,
            toggle(getString(R.string.opt_auto), Prefs.autoRead(this), 18) {
                Prefs.setAutoRead(this, it)
            },
            hint(getString(R.string.opt_auto_hint)),
            toggle(getString(R.string.opt_sound), Prefs.sound(this), 18) {
                Prefs.setSound(this, it)
                if (it) Chime.play(this) // mostra como é o toque
            },
            hint(getString(R.string.opt_sound_hint)),
            toggle(getString(R.string.opt_lang), Prefs.matchLanguage(this), 18) {
                Prefs.setMatchLanguage(this, it)
            },
            hint(getString(R.string.opt_lang_hint)),
            toggle(getString(R.string.opt_codes), Prefs.skipCodes(this), 18) {
                Prefs.setSkipCodes(this, it)
                TalkListener.instance?.reload()
            },
            hint(getString(R.string.opt_codes_hint)),
            toggle(getString(R.string.opt_always), Prefs.alwaysShow(this), 18) {
                Prefs.setAlwaysShow(this, it)
                TalkListener.instance?.refreshOverlay(showAgain = it)
            },
            hint(getString(R.string.opt_always_hint))
        ))

        if (intent?.getBooleanExtra("ask_audio", false) == true) window.decorView.post { askAudio() }
        col.addView(card(
            section(getString(R.string.section_voice)),
            hint(getString(R.string.voice_play_hint)),
            bigButton(getString(R.string.voice_allow), R.drawable.bg_btn_secondary, cText) { askAudio() }
        ))

        carBtHint = hint(carBtText())
        col.addView(card(
            section(getString(R.string.section_car)),
            toggle(getString(R.string.opt_car), Prefs.carManual(this), 0) {
                Prefs.setCarManual(this, it)
                if (it) askMic()
                TalkListener.instance?.carChanged()
            },
            hint(getString(R.string.opt_car_hint)),
            toggle(getString(R.string.opt_car_auto), Prefs.carAuto(this), 18) {
                Prefs.setCarAuto(this, it)
                TalkListener.instance?.carChanged()
            },
            hint(getString(R.string.opt_car_auto_hint)),
            bigButton(getString(R.string.car_pick_bt), R.drawable.bg_btn_secondary, cText) { pickCarBluetooth() },
            carBtHint
        ))

        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(card(
            section(getString(R.string.section_apps)),
            label(getString(R.string.apps_hint), 12.5f, cMuted),
            appsBox
        ))

        col.addView(card(
            section(getString(R.string.section_how)),
            label(getString(R.string.how_text), 14f, cMuted)
        ))

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    override fun onResume() {
        super.onResume()
        visible = true
        Speaker.get(this).addListener(failListener)
        if (voiceSettingsOpened) { // voltou das configurações de voz: recria o motor com a voz nova
            voiceSettingsOpened = false
            Speaker.get(this).reinit()
        }
        val missing = ArrayList<String>()
        if (!notifAccess()) missing.add(getString(R.string.missing_notif))
        if (!overlayOk()) missing.add(getString(R.string.missing_overlay))
        val ready = missing.isEmpty()
        status.text = if (ready) getString(R.string.status_ready)
        else getString(R.string.status_missing, missing.joinToString(", "))
        status.setTextColor(if (ready) cAccent else Color.parseColor("#C7D2FE"))
        status.background = ContextCompat.getDrawable(
            this, if (ready) R.drawable.bg_status_on else R.drawable.bg_status_off
        )
        refreshApps()
        // acesso concedido mas o serviço não está rodando (alguns celulares o encerram): pede religação
        if (notifAccess() && TalkListener.instance == null) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, TalkListener::class.java))
            } catch (e: Exception) {
                // sem efeito; o sistema religa sozinho depois
            }
        }
        // se a permissão de sobreposição acabou de ser dada, mostra a bolha
        TalkListener.instance?.refreshOverlay()
    }

    override fun onPause() {
        visible = false
        Speaker.get(this).removeListener(failListener)
        super.onPause()
    }

    private fun refreshApps() {
        appsBox.removeAllViews()
        val seen = Prefs.seenApps(this).sortedBy { appLabel(this, it).lowercase() }
        if (seen.isEmpty()) {
            appsBox.addView(
                label(getString(R.string.apps_none), 13.5f, cMuted)
                    .apply { setPadding(0, px(12), 0, 0) }
            )
            return
        }
        val disabled = Prefs.disabledApps(this)
        for (pkg in seen) {
            appsBox.addView(Switch(this).apply {
                text = appLabel(this@MainActivity, pkg)
                setTextColor(cText)
                textSize = 15f
                isChecked = pkg !in disabled
                thumbTintList = ColorStateList.valueOf(cAccent)
                trackTintList = ColorStateList.valueOf(cIndigo)
                setPadding(0, px(12), 0, 0)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setAppEnabled(this@MainActivity, pkg, on)
                    TalkListener.instance?.reload()
                }
            })
        }
    }
}
