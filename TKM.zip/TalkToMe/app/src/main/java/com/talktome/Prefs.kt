package com.talktome

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("leitor", Context.MODE_PRIVATE)

    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.0f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()

    /** true = bolha sempre na tela; false = só quando há mensagens novas. */
    fun alwaysShow(c: Context): Boolean = sp(c).getBoolean("always", false)
    fun setAlwaysShow(c: Context, v: Boolean) = sp(c).edit().putBoolean("always", v).apply()

    /** Lê cada mensagem nova em voz alta assim que chega (modo mãos livres). */
    fun autoRead(c: Context): Boolean = sp(c).getBoolean("auto", false)
    fun setAutoRead(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    /** Toque curto quando chega mensagem nova. */
    fun sound(c: Context): Boolean = sp(c).getBoolean("sound", true)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()

    /** Fala cada mensagem com a voz do idioma dela (inglês, espanhol...) quando dá pra detectar. */
    fun matchLanguage(c: Context): Boolean = sp(c).getBoolean("matchlang", true)
    fun setMatchLanguage(c: Context, v: Boolean) = sp(c).edit().putBoolean("matchlang", v).apply()

    /** Ignora mensagens com código de verificação (SMS de banco, 2FA). */
    fun skipCodes(c: Context): Boolean = sp(c).getBoolean("skipcodes", true)
    fun setSkipCodes(c: Context, v: Boolean) = sp(c).edit().putBoolean("skipcodes", v).apply()

    fun btnX(c: Context): Int = sp(c).getInt("bx", -1)
    fun btnY(c: Context): Int = sp(c).getInt("by", -1)
    fun setBtnPos(c: Context, x: Int, y: Int) =
        sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    /** Apps que já mandaram notificação de mensagem (aparecem na lista da tela inicial). */
    fun seenApps(c: Context): Set<String> = sp(c).getStringSet("seen", emptySet()) ?: emptySet()

    fun markSeen(c: Context, pkg: String) {
        val s = seenApps(c)
        if (pkg in s) return
        val copy = HashSet(s)
        copy.add(pkg)
        sp(c).edit().putStringSet("seen", copy).apply()
    }

    /** Apps que o usuário desligou. Todo app novo começa ligado. */
    fun disabledApps(c: Context): Set<String> = sp(c).getStringSet("disabled", emptySet()) ?: emptySet()

    fun setAppEnabled(c: Context, pkg: String, enabled: Boolean) {
        val copy = HashSet(disabledApps(c))
        if (enabled) copy.remove(pkg) else copy.add(pkg)
        sp(c).edit().putStringSet("disabled", copy).apply()
    }
}
