package com.talktome

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("leitor", Context.MODE_PRIVATE)

    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.0f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()

    /** true = bolha sempre na tela; false = só quando há mensagens novas. */
    fun alwaysShow(c: Context): Boolean = sp(c).getBoolean("always", false)
    fun setAlwaysShow(c: Context, v: Boolean) = sp(c).edit().putBoolean("always", v).apply()

    /** Lê cada mensagem nova em voz alta assim que chega (modo mãos livres). */
    fun autoRead(c: Context): Boolean = sp(c).getBoolean("auto", false)
    fun setAutoRead(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    /** Toque curto quando chega mensagem nova. */
    fun sound(c: Context): Boolean = sp(c).getBoolean("sound", true)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()

    /** Fala cada mensagem com a voz do idioma dela (inglês, espanhol...) quando dá pra detectar. */
    fun matchLanguage(c: Context): Boolean = sp(c).getBoolean("matchlang", true)
    fun setMatchLanguage(c: Context, v: Boolean) = sp(c).edit().putBoolean("matchlang", v).apply()

    /** Ignora mensagens com código de verificação (SMS de banco, 2FA). */
    fun skipCodes(c: Context): Boolean = sp(c).getBoolean("skipcodes", true)
    fun setSkipCodes(c: Context, v: Boolean) = sp(c).edit().putBoolean("skipcodes", v).apply()

    /** Modo carro ligado na mão. */
    fun carManual(c: Context): Boolean = sp(c).getBoolean("car", false)
    fun setCarManual(c: Context, v: Boolean) = sp(c).edit().putBoolean("car", v).apply()

    /** Liga sozinho com o modo carro do Android / Android Auto / Bluetooth do carro. */
    fun carAuto(c: Context): Boolean = sp(c).getBoolean("carauto", true)
    fun setCarAuto(c: Context, v: Boolean) = sp(c).edit().putBoolean("carauto", v).apply()

    fun carBtAddress(c: Context): String? = sp(c).getString("carbt", null)
    fun carBtName(c: Context): String? = sp(c).getString("carbtname", null)
    fun setCarBt(c: Context, address: String?, name: String?) =
        sp(c).edit().putString("carbt", address).putString("carbtname", name).apply()

    /** Conversas favoritas (lidas primeiro, com toque diferente) e silenciadas (sem som nem leitura). */
    fun favorites(c: Context): Set<String> = sp(c).getStringSet("fav", emptySet()) ?: emptySet()
    fun isFav(c: Context, key: String) = key in favorites(c)
    fun toggleFav(c: Context, key: String): Boolean = toggleSet(c, "fav", key)

    fun muted(c: Context): Set<String> = sp(c).getStringSet("muted", emptySet()) ?: emptySet()
    fun isMuted(c: Context, key: String) = key in muted(c)
    fun toggleMute(c: Context, key: String): Boolean = toggleSet(c, "muted", key)

    /** Liga/desliga [key] no conjunto; devolve true se ficou ligado. */
    private fun toggleSet(c: Context, name: String, key: String): Boolean {
        val s = HashSet(sp(c).getStringSet(name, emptySet()) ?: emptySet())
        val on = s.add(key)
        if (!on) s.remove(key)
        sp(c).edit().putStringSet(name, s).apply()
        return on
    }

    fun btnX(c: Context): Int = sp(c).getInt("bx", -1)
    fun btnY(c: Context): Int = sp(c).getInt("by", -1)
    fun setBtnPos(c: Context, x: Int, y: Int) =
        sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    /** Apps que já mandaram notificação de mensagem (aparecem na lista da tela inicial). */
    fun seenApps(c: Context): Set<String> = sp(c).getStringSet("seen", emptySet()) ?: emptySet()

    fun markSeen(c: Context, pkg: String) {
        val s = seenApps(c)
        if (pkg in s) return
        val copy = HashSet(s)
        copy.add(pkg)
        sp(c).edit().putStringSet("seen", copy).apply()
    }

    /** Apps que o usuário desligou. Todo app novo começa ligado. */
    fun disabledApps(c: Context): Set<String> = sp(c).getStringSet("disabled", emptySet()) ?: emptySet()

    fun setAppEnabled(c: Context, pkg: String, enabled: Boolean) {
        val copy = HashSet(disabledApps(c))
        if (enabled) copy.remove(pkg) else copy.add(pkg)
        sp(c).edit().putStringSet("disabled", copy).apply()
    }
}
