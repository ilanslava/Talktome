package com.talktome

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Usa o TextToSpeech padrão do sistema, ou seja, a voz que o usuário já configurou em
 * Configurações > Saída de texto para voz. Uma única instância compartilhada pelo app,
 * então a tela inicial e a bolha nunca falam uma por cima da outra.
 *
 * A fala é uma fila própria: um trecho por vez, cada um no idioma detectado da mensagem
 * (a troca de idioma só vale pro que for falado depois, por isso nada fica na fila do motor).
 */
class Speaker private constructor(context: Context) {

    interface Listener {
        fun onSpeaking(speaking: Boolean) {}
        fun onFail() {}
    }

    companion object {
        @Volatile private var inst: Speaker? = null

        fun get(ctx: Context): Speaker =
            inst ?: synchronized(this) {
                inst ?: Speaker(ctx.applicationContext).also { inst = it }
            }
    }

    private class Item(val text: String, val loc: Locale)

    private val ctx = context
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private var focusReq: AudioFocusRequest? = null

    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private val pending = ArrayList<Pair<String, Boolean>>()

    // fila de reprodução (só mexe nela na thread principal)
    private val queue = ArrayDeque<Item>()
    private var playing = false
    @Volatile private var curId = ""

    @Volatile var isSpeaking = false
        private set

    init { create() }

    fun addListener(l: Listener) { listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    private fun create() {
        ready = false
        failed = false
        tts = TextToSpeech(ctx) { status -> main.post { onInit(status) } }
    }

    private fun onInit(status: Int) {
        val t = tts
        if (status == TextToSpeech.SUCCESS && t != null) {
            t.setAudioAttributes(attrs)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { if (id == curId) emit(true) }
                override fun onDone(id: String?) { advance(id) }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { advance(id) }
                override fun onStop(id: String?, interrupted: Boolean) { advance(id) }
            })
            ready = true
            val queued = ArrayList(pending)
            pending.clear()
            queued.forEach { speak(it.first, it.second) }
        } else {
            failed = true
            if (pending.isNotEmpty()) {
                pending.clear()
                notifyFail()
            }
        }
    }

    /** Terminou (ou falhou) o trecho [id]: toca o próximo da fila. Ignora trechos já cancelados. */
    private fun advance(id: String?) {
        if (id == null || id != curId) return
        main.post { if (id == curId) playNext() }
    }

    private fun emit(speaking: Boolean) {
        main.post {
            isSpeaking = speaking
            listeners.forEach { it.onSpeaking(speaking) }
        }
    }

    private fun notifyFail() {
        main.post { listeners.forEach { it.onFail() } }
    }

    private fun playNext() {
        val t = tts
        val item = if (queue.isEmpty()) null else queue.removeFirst()
        if (t == null || item == null) {
            playing = false
            curId = ""
            abandonFocus()
            emit(false)
            return
        }
        playing = true
        if (t.isLanguageAvailable(item.loc) >= TextToSpeech.LANG_AVAILABLE) {
            t.setLanguage(item.loc)
        } else {
            t.setLanguage(Locale.getDefault()) // voz desse idioma não instalada: usa a padrão
        }
        t.setSpeechRate(Prefs.rate(ctx))
        val id = "u${System.nanoTime()}"
        curId = id
        if (t.speak(item.text, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.ERROR) {
            main.post { if (id == curId) playNext() } // o motor recusou: segue pro próximo
        }
    }

    /** false quando outro app segura o áudio de forma exclusiva (ex.: ligação em andamento). */
    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .build()
            .also { focusReq = it }
        return am.requestAudioFocus(req) != AudioManager.AUDIOFOCUS_REQUEST_FAILED
    }

    private fun abandonFocus() {
        focusReq?.let { am.abandonAudioFocusRequest(it) }
    }

    /** Quebra o texto em trechos de um idioma só, cada um com tamanho que o motor aceita. */
    private fun buildItems(clean: String): List<Item> {
        val def = Locale.getDefault()
        val detect = Prefs.matchLanguage(ctx)
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        val out = ArrayList<Item>()
        val buf = StringBuilder()
        var cur: Locale? = null

        fun flushBuf() {
            if (buf.isNotBlank()) chunkText(buf.toString(), max).forEach { out.add(Item(it, cur ?: def)) }
            buf.setLength(0)
        }

        for (line in clean.split('\n')) {
            val l = line.trim()
            if (l.isEmpty()) continue
            val lang = if (detect) detectLanguage(l) else null
            val loc = when {
                lang == null -> cur ?: def // sem certeza: continua no idioma anterior
                lang == def.language -> def
                else -> Locale(lang)
            }
            if (cur != null && loc != cur) flushBuf()
            cur = loc
            buf.append(l).append('\n')
        }
        flushBuf()
        return out
    }

    /**
     * [flush] = true: ação do usuário, corta o que estiver falando e fala mesmo se o áudio estiver
     * ocupado. false: leitura automática, entra no fim da fila e NÃO fala se o áudio estiver
     * ocupado (ligação, por exemplo).
     * Retorna false quando não falou (então a mensagem não deve ser marcada como ouvida).
     * Emoji não são lidos: texto só de emoji não tem nada pra falar e conta como falado.
     */
    fun speak(text: String, flush: Boolean = true): Boolean {
        val clean = cleanForSpeech(text, ctx.getString(R.string.speech_link))
        if (clean.isBlank()) return true
        if (failed) {
            // o usuário pode ter instalado uma voz desde a última falha: recria o motor e tenta de novo
            pending.add(clean to flush)
            tts?.shutdown()
            create()
            return false
        }
        val t = tts
        if (!ready || t == null) {
            pending.add(clean to flush)
            return true
        }
        val items = buildItems(clean)
        if (items.isEmpty()) return true
        if (!requestFocus() && !flush) return false
        if (flush) {
            queue.clear()
            curId = "" // o "stop" do trecho cortado não pode disparar o próximo da fila
            if (playing) t.stop()
        }
        queue.addAll(items)
        if (flush || !playing) playNext()
        return true
    }

    fun stop() {
        pending.clear()
        queue.clear()
        curId = ""
        playing = false
        tts?.stop()
        abandonFocus()
        emit(false)
    }

    /** Recria o motor (ex.: depois que o usuário trocou a voz nas configurações do sistema). */
    fun reinit() {
        queue.clear()
        curId = ""
        playing = false
        tts?.stop()
        tts?.shutdown()
        create()
    }
}
