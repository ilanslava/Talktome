package com.talktome

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat

/**
 * Áudios do WhatsApp: a notificação só traz "Mensagem de voz (0:07)", não o áudio. Aqui o app procura
 * o arquivo que o WhatsApp baixou (pasta "Voice Notes") para tocar dentro do painel.
 */
object VoiceNote {
    private val DUR = Regex("\\(\\d{1,2}:\\d{2}(?::\\d{2})?\\)")

    /** A mensagem é um áudio do WhatsApp? (texto tipo "🎤 Voice message (0:07)") */
    fun isVoice(pkg: String, text: String): Boolean {
        if (!pkg.startsWith("com.whatsapp") || !DUR.containsMatchIn(text)) return false
        val t = text.lowercase()
        return "🎤" in t || "🎙" in t || "🎵" in t || "voice" in t || "voz" in t || "audio" in t || "áudio" in t
    }

    fun permission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, permission()) == PackageManager.PERMISSION_GRANTED

    /** Abre as configurações do app já pedindo a permissão de áudio. */
    fun askPermission(ctx: Context) {
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .putExtra("ask_audio", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** O arquivo de áudio do WhatsApp mais antigo que chegou a partir (um pouco antes) do horário da mensagem. */
    fun find(ctx: Context, msgTime: Long): Uri? {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val since = msgTime / 1000 - 90
        val path = if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH else MediaStore.Audio.Media.DATA
        return try {
            ctx.contentResolver.query(
                uri,
                arrayOf(MediaStore.Audio.Media._ID),
                "($path LIKE ? OR $path LIKE ?) AND ${MediaStore.Audio.Media.DATE_ADDED} >= ?",
                arrayOf("%Voice Notes%", "%WhatsApp Audio%", since.toString()),
                "${MediaStore.Audio.Media.DATE_ADDED} ASC"
            )?.use { c -> if (c.moveToFirst()) ContentUris.withAppendedId(uri, c.getLong(0)) else null }
        } catch (e: Exception) {
            null
        }
    }
}
