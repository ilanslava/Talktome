package com.talktome

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Bolinha flutuante nas cores do app: mostra o número de mensagens novas,
 * "respira" soltando ondas suaves quando há mensagem (ou voz falando) e
 * o tamanho é controlado por fora ([ball]). A janela tem só uma folga
 * pequena em volta pras ondas, pra ocupar pouco espaço da tela.
 */
class BubbleView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val margin = 10f * d

    /** Diâmetro da bolinha em px. */
    var ball = 40f * d
        set(v) {
            field = v
            invalidate()
        }

    var count = 0
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    var speaking = false
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    /** Ícones dos apps com mensagem nova (o mais recente primeiro); aparecem em cima da bolinha. */
    var icons: List<Drawable> = emptyList()
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    /** Lado da janela (quadrada) que comporta a bolinha + a folga das ondas. */
    fun windowSize(): Int = (ball + 2f * margin).roundToInt()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = Color.argb(190, 199, 210, 254)
    }
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * d
        color = Color.parseColor("#A5B4FC")
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A5B4FC")
        alpha = 46
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0E2A") }
    private val clip = Path()
    private var shaderBall = -1f
    private var shaderW = -1
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var animSpeaking = false

    private fun syncAnim() {
        val want = isAttachedToWindow && (count > 0 || speaking)
        if (!want) {
            anim?.cancel()
            anim = null
            phase = 0f
            return
        }
        if (anim != null && animSpeaking == speaking) return
        anim?.cancel()
        animSpeaking = speaking
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            duration = if (speaking) 1500L else 2600L
            addUpdateListener {
                phase = it.animatedFraction
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnim()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    /** Mini ícones redondos no canto de cima da bolinha (no máximo 2, o mais recente por cima). */
    private fun drawIcons(c: Canvas, cx: Float, cy: Float, r: Float) {
        val sz = ball * 0.42f
        val gap = sz * 0.62f
        for (i in icons.indices.reversed()) {
            val ix = cx + r * 0.74f - i * gap
            val iy = cy - r * 0.74f
            c.drawCircle(ix, iy, sz / 2f + 1.6f * d, ring)
            clip.reset()
            clip.addCircle(ix, iy, sz / 2f, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            icons[i].setBounds(
                (ix - sz / 2f).toInt(), (iy - sz / 2f).toInt(),
                (ix + sz / 2f).toInt(), (iy + sz / 2f).toInt()
            )
            icons[i].draw(c)
            c.restore()
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val active = anim != null
        val t = phase
        val breathe = if (active) 0.5f + 0.5f * sin(2.0 * PI * t - PI / 2).toFloat() else 0f
        val r = ball / 2f * (1f + 0.04f * breathe)

        // ondas: dois anéis finos que se abrem e somem
        if (active) {
            for (k in 0..1) {
                val p = (t + k * 0.5f) % 1f
                val rr = ball / 2f + p * (margin - wave.strokeWidth)
                wave.alpha = ((1f - p) * (1f - p) * 120f).toInt()
                c.drawCircle(cx, cy, rr, wave)
            }
            c.drawCircle(cx, cy, r + 3f * d * breathe, glow)
        }

        // bolinha: degradê indigo → azul (texto branco com bom contraste)
        if (shaderBall != ball || shaderW != width) {
            val h = ball / 2f
            fill.shader = LinearGradient(
                cx - h, cy - h, cx + h, cy + h,
                Color.parseColor("#4F46E5"), Color.parseColor("#2563EB"),
                Shader.TileMode.CLAMP
            )
            shaderBall = ball
            shaderW = width
        }
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r - edge.strokeWidth / 2f, edge)

        when {
            speaking -> { // quadradinho de "parar"
                val s = ball * 0.17f
                c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, s * 0.25f, s * 0.25f, glyph)
            }
            count > 0 -> {
                val s = if (count > 99) "99+" else count.toString()
                txt.textSize = ball * when (s.length) {
                    1 -> 0.46f
                    2 -> 0.38f
                    else -> 0.30f
                }
                val fm = txt.fontMetrics
                c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, txt)
            }
            else -> { // sem mensagens: três barrinhas de áudio
                val bw = ball * 0.07f
                val gap = ball * 0.07f
                val hs = floatArrayOf(0.20f, 0.36f, 0.26f)
                for (i in 0..2) {
                    val x = cx + (i - 1) * (bw + gap)
                    val h = ball * hs[i] / 2f
                    c.drawRoundRect(x - bw / 2f, cy - h, x + bw / 2f, cy + h, bw / 2f, bw / 2f, glyph)
                }
            }
        }
        if (icons.isNotEmpty()) drawIcons(c, cx, cy, ball / 2f)
    }
}
