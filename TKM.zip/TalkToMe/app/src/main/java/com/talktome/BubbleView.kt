package com.talktome

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Orb flutuante: esfera escura com anel de aurora (indigo → azul → violeta) e uma boca estilizada
 * no centro, nas cores do app. Com mensagens novas o anel gira e saem ondas suaves; falando, a
 * boca abre e fecha. O número de mensagens fica numa plaquinha no canto de baixo e o ícone do app
 * no canto de cima. O tamanho vem de fora ([ball]); a janela só tem uma folga pequena pras ondas.
 */
class BubbleView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val margin = 10f * d

    /** Diâmetro da esfera em px. */
    var ball = 36f * d
        set(v) {
            field = v
            invalidate()
        }

    var count = 0
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    var speaking = false
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    /** Ícones dos apps com mensagem nova (o mais recente primeiro); aparecem em cima do orb. */
    var icons: List<Drawable> = emptyList()
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    /** Modo carro / Bluetooth do carro: brilho azul-céu pulsando + símbolo de carro no canto. */
    var car = false
        set(v) {
            if (field != v) {
                field = v
                syncAnim()
                invalidate()
            }
        }

    /** Lado da janela (quadrada) que comporta a esfera + a folga das ondas. */
    fun windowSize(): Int = (ball + 2f * margin).roundToInt()

    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        alpha = 16
    }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val aurora = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * d
    }
    private val wave = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * d
        color = Color.parseColor("#93C5FD")
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#818CF8")
        alpha = 40
    }
    private val upperLip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lowerLip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mouthInside = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#05061A") }
    private val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#EEF0FF") }
    private val badgeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0E2A") }
    private val badgeTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B0E2A")
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val iconRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0E2A") }
    private val carGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#38BDF8") }
    private val carRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * d
        color = Color.parseColor("#38BDF8")
    }
    private val carBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#38BDF8") }
    private val carFg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0E2A") }
    private val carCut = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#38BDF8") }

    // carrinho em "unidades" (caixa de ~24): corpo + teto + rodas; janelas e cubos são recortes
    private val carBody = Path().apply {
        addRoundRect(RectF(3f, 11f, 21f, 18.5f), 2f, 2f, Path.Direction.CW)
        moveTo(6f, 11f); lineTo(8.4f, 5.5f); lineTo(15.6f, 5.5f); lineTo(18f, 11f); close()
        addCircle(7.5f, 18.5f, 2.3f, Path.Direction.CW)
        addCircle(16.5f, 18.5f, 2.3f, Path.Direction.CW)
    }
    private val carWin = Path().apply {
        moveTo(8.8f, 7f); lineTo(11.4f, 7f); lineTo(11.4f, 10.2f); lineTo(7.5f, 10.2f); close()
        moveTo(12.6f, 7f); lineTo(15.2f, 7f); lineTo(16.5f, 10.2f); lineTo(12.6f, 10.2f); close()
        addCircle(7.5f, 18.5f, 0.9f, Path.Direction.CW)
        addCircle(16.5f, 18.5f, 0.9f, Path.Direction.CW)
    }
    private val clip = Path()
    private val rot = Matrix()
    private val gap = RectF()

    // boca em "unidades" (96 de largura, centrada); desenhada com escala conforme o tamanho do orb
    private val upper = Path().apply {
        moveTo(-48f, 2f)
        cubicTo(-36f, -10f, -22f, -25f, -8f, -21f)
        quadTo(0f, -15f, 8f, -21f)
        cubicTo(22f, -25f, 36f, -10f, 48f, 2f)
        cubicTo(32f, 6f, 16f, 6.5f, 0f, 6.5f)
        cubicTo(-16f, 6.5f, -32f, 6f, -48f, 2f)
        close()
    }
    private val lower = Path().apply {
        moveTo(-45f, 6.5f)
        cubicTo(-30f, 8f, -14f, 8.5f, 0f, 8.5f)
        cubicTo(14f, 8.5f, 30f, 8f, 45f, 6.5f)
        cubicTo(36f, 22f, 18f, 29f, 0f, 29f)
        cubicTo(-18f, 29f, -36f, 22f, -45f, 6.5f)
        close()
    }

    init {
        upperLip.shader = LinearGradient(
            -48f, 0f, 48f, 0f,
            Color.parseColor("#C084FC"), Color.parseColor("#818CF8"), Shader.TileMode.CLAMP
        )
        lowerLip.shader = LinearGradient(
            -45f, 0f, 45f, 0f,
            Color.parseColor("#A78BFA"), Color.parseColor("#60A5FA"), Shader.TileMode.CLAMP
        )
    }

    private var auroraShader: SweepGradient? = null
    private var shaderBall = -1f
    private var shaderW = -1
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var animSpeaking = false

    private fun syncAnim() {
        val want = isAttachedToWindow && (count > 0 || speaking || car)
        if (!want) {
            anim?.cancel()
            anim = null
            phase = 0f
            return
        }
        if (anim != null && animSpeaking == speaking) return
        anim?.cancel()
        animSpeaking = speaking
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            duration = if (speaking) 1800L else 3200L
            addUpdateListener {
                phase = it.animatedFraction
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnim()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    /** Mini ícones redondos no canto de cima do orb (no máximo 2, o mais recente por cima). */
    private fun drawIcons(c: Canvas, cx: Float, cy: Float, r: Float) {
        val sz = ball * 0.42f
        val step = sz * 0.62f
        for (i in icons.indices.reversed()) {
            val ix = cx + r * 0.74f - i * step
            val iy = cy - r * 0.74f
            c.drawCircle(ix, iy, sz / 2f + 1.6f * d, iconRing)
            clip.reset()
            clip.addCircle(ix, iy, sz / 2f, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            icons[i].setBounds(
                (ix - sz / 2f).toInt(), (iy - sz / 2f).toInt(),
                (ix + sz / 2f).toInt(), (iy + sz / 2f).toInt()
            )
            icons[i].draw(c)
            c.restore()
        }
    }

    /** Plaquinha azul-céu com um carrinho, no canto de cima à esquerda (modo carro). */
    private fun drawCar(c: Canvas, cx: Float, cy: Float, r: Float) {
        val br = ball * 0.23f
        val bx = cx - r * 0.66f
        val by = cy - r * 0.66f
        c.drawCircle(bx, by, br + 1.6f * d, iconRing)
        c.drawCircle(bx, by, br, carBg)
        val s = (br * 1.35f) / 18f
        c.save()
        c.translate(bx, by)
        c.scale(s, s)
        c.translate(-12f, -12.8f)
        c.drawPath(carBody, carFg)
        c.drawPath(carWin, carCut)
        c.restore()
    }

    /** Plaquinha clara com o número de mensagens, no canto de baixo. */
    private fun drawBadge(c: Canvas, cx: Float, cy: Float, r: Float) {
        val s = if (count > 99) "99+" else count.toString()
        val br = ball * 0.27f * (if (s.length >= 3) 1.2f else 1f)
        val bx = cx + r * 0.62f
        val by = cy + r * 0.62f
        c.drawCircle(bx, by, br + 1.6f * d, badgeRing)
        c.drawCircle(bx, by, br, badge)
        badgeTxt.textSize = br * when (s.length) {
            1 -> 1.25f
            2 -> 1.05f
            else -> 0.82f
        }
        val fm = badgeTxt.fontMetrics
        c.drawText(s, bx, by - (fm.ascent + fm.descent) / 2f, badgeTxt)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = ball / 2f
        val active = anim != null
        val moving = active && (count > 0 || speaking) // ondas e anel girando
        val t = phase
        val wave01 = if (active) 0.5f + 0.5f * sin(2.0 * PI * t - PI / 2).toFloat() else 0f
        val breathe = if (moving) wave01 else 0f
        val r = base * (1f + 0.04f * breathe)

        if (shaderBall != ball || shaderW != width) {
            body.shader = RadialGradient(
                cx - base * 0.25f, cy - base * 0.30f, base * 1.5f,
                intArrayOf(Color.parseColor("#2C318F"), Color.parseColor("#171B5C"), Color.parseColor("#0B0E2A")),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            auroraShader = SweepGradient(
                cx, cy,
                intArrayOf(
                    Color.parseColor("#C7D2FE"), Color.parseColor("#60A5FA"),
                    Color.parseColor("#C084FC"), Color.parseColor("#C7D2FE")
                ),
                null
            )
            aurora.shader = auroraShader
            shaderBall = ball
            shaderW = width
        }

        // brilho do modo carro: azul-céu pulsando por fora
        if (car) {
            carGlow.alpha = (45 + 55 * wave01).toInt()
            c.drawCircle(cx, cy, r + (3.5f + 2.5f * wave01) * d, carGlow)
            carRing.alpha = (150 + 100 * wave01).toInt()
            c.drawCircle(cx, cy, r + 1.6f * d, carRing)
        }

        // ondas suaves (só com mensagem nova ou falando)
        if (moving) {
            for (k in 0..1) {
                val p = (t + k * 0.5f) % 1f
                wave.alpha = ((1f - p) * (1f - p) * 120f).toInt()
                c.drawCircle(cx, cy, base + p * (margin - wave.strokeWidth), wave)
            }
            c.drawCircle(cx, cy, r + 3f * d * breathe, glow)
        }

        // sombra suave + esfera
        for (k in 3 downTo 1) c.drawCircle(cx, cy + 2.2f * d, r + k * 1.6f * d, shadow)
        c.drawCircle(cx, cy, r, body)

        // anel de aurora: gira quando ativo
        if (moving) {
            rot.setRotate(t * 360f, cx, cy)
            auroraShader?.setLocalMatrix(rot)
            aurora.alpha = 255
        } else {
            rot.reset()
            auroraShader?.setLocalMatrix(rot)
            aurora.alpha = 190
        }
        c.drawCircle(cx, cy, r - aurora.strokeWidth / 2f, aurora)

        // boca: abre e fecha quando está falando
        val open = if (speaking) 0.5f + 0.5f * sin(2.0 * PI * t * 4.0 - PI / 2).toFloat() else 0f
        val s = (r * 2f * 0.60f) / 96f
        c.save()
        c.translate(cx, cy - 3.5f * s)
        c.scale(s, s)
        if (open > 0.03f) {
            gap.set(-36f, 4.5f, 36f, 8.5f + open * 9f)
            c.drawOval(gap, mouthInside)
        }
        c.drawPath(upper, upperLip)
        c.save()
        c.translate(0f, open * 8f)
        c.drawPath(lower, lowerLip)
        c.restore()
        c.restore()

        if (count > 0) drawBadge(c, cx, cy, base)
        if (car) drawCar(c, cx, cy, base)
        if (icons.isNotEmpty()) drawIcons(c, cx, cy, base)
    }
}
