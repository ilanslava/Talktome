package com.talktome

import android.app.ActivityOptions
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Guarda as mensagens novas (vindas das notificações de qualquer app de mensagem)
 * e envia respostas. Uso só na thread principal.
 */
object MessageStore {

    /** [sig] identifica a mensagem de forma estável, mesmo se a notificação for repostada. */
    class Msg(val text: String, val time: Long, val sender: String, val sig: String, var heard: Boolean = false)

    class Conv(val key: String) {
        var pkg: String = ""
        var appName: String = ""
        var title: String = ""
        var isGroup: Boolean = false
        /** Id do atalho da conversa (no WhatsApp costuma ser o jid, ex.: 5511...@s.whatsapp.net). */
        var shortcut: String? = null
        var msgs: List<Msg> = emptyList()

        /** Mensagens por notificação (alguns apps postam uma notificação por mensagem). */
        val parts = LinkedHashMap<String, List<Msg>>()
        val replies = LinkedHashMap<String, Notification.Action>()
        val opens = LinkedHashMap<String, PendingIntent>()

        val replyAction: Notification.Action? get() = replies.values.lastOrNull()
        val openIntent: PendingIntent? get() = opens.values.lastOrNull()
        val lastTime: Long get() = msgs.maxOfOrNull { it.time } ?: 0L

        fun rebuild() {
            val all = parts.values.flatten().distinctBy { it.sig }.sortedBy { it.time }.takeLast(40)
            for (m in all) m.heard = MessageStore.isHeard(key, m.sig)
            msgs = all
        }
    }

    private val convs = LinkedHashMap<String, Conv>()
    private val byNotif = HashMap<String, String>() // chave da notificação -> chave da conversa
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val newListeners = CopyOnWriteArrayList<(Conv, List<Msg>) -> Unit>()

    // "ouvido" e "já visto" sobrevivem a reload()/remoção da notificação (limitados em tamanho)
    private val heard = LinkedHashSet<String>()
    private val known = LinkedHashSet<String>()

    /** Enquanto true, mensagens novas não disparam leitura automática (ex.: recarga inicial). */
    var silent = false

    private fun cap(s: LinkedHashSet<String>) {
        while (s.size > 2000) {
            val it = s.iterator()
            it.next()
            it.remove()
        }
    }

    fun isHeard(convKey: String, sig: String) = "$convKey|$sig" in heard

    private fun setHeard(convKey: String, sig: String) {
        heard.add("$convKey|$sig")
        cap(heard)
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun addNewListener(l: (Conv, List<Msg>) -> Unit) { newListeners.add(l) }
    fun removeNewListener(l: (Conv, List<Msg>) -> Unit) { newListeners.remove(l) }
    private fun changed() { listeners.forEach { it() } }

    /** Mais recentes primeiro. */
    fun conversations(): List<Conv> = convs.values.sortedByDescending { it.lastTime }
    fun conv(key: String): Conv? = convs[key]
    fun unheardCount(): Int = convs.values.sumOf { c -> c.msgs.count { !it.heard } }
    fun isDemo(key: String) = key.startsWith("demo:")

    fun upsert(
        notifKey: String, convKey: String, pkg: String, appName: String, title: String,
        isGroup: Boolean, newMsgs: List<Msg>, reply: Notification.Action?, open: PendingIntent?,
        shortcut: String? = null
    ) {
        val c = convs.getOrPut(convKey) { Conv(convKey) }
        c.pkg = pkg
        c.appName = appName
        c.title = title
        c.isGroup = isGroup
        if (!shortcut.isNullOrBlank()) c.shortcut = shortcut
        c.parts[notifKey] = newMsgs
        if (reply != null) c.replies[notifKey] = reply else c.replies.remove(notifKey)
        if (open != null) c.opens[notifKey] = open else c.opens.remove(notifKey)
        byNotif[notifKey] = convKey
        val fresh = newMsgs.filter { known.add("$convKey|${it.sig}") }
        cap(known)
        c.rebuild()
        changed()
        if (!silent && fresh.isNotEmpty() && !isDemo(convKey)) {
            val unheard = fresh.filter { !it.heard }
            if (unheard.isNotEmpty()) newListeners.forEach { it(c, unheard) }
        }
    }

    /** Uma notificação foi removida (lida no app, dispensada ou respondida). */
    fun removeNotif(notifKey: String) {
        val ck = byNotif.remove(notifKey) ?: return
        val c = convs[ck] ?: return
        c.parts.remove(notifKey)
        c.replies.remove(notifKey)
        c.opens.remove(notifKey)
        if (c.parts.isEmpty()) convs.remove(ck) else c.rebuild()
        changed()
    }

    fun clear() {
        if (convs.isNotEmpty() || byNotif.isNotEmpty()) {
            convs.clear()
            byNotif.clear()
            changed()
        }
    }

    fun removeDemo() {
        val keys = convs.keys.filter { isDemo(it) }
        keys.forEach { convs.remove(it) }
        byNotif.keys.removeAll { it.startsWith("demo:") }
        heard.removeAll { it.startsWith("demo:") }
        known.removeAll { it.startsWith("demo:") }
        changed()
    }

    fun markHeard(key: String, m: Msg) = markHeardMany(key, listOf(m))

    fun markHeardMany(key: String, list: List<Msg>) {
        for (m in list) setHeard(key, m.sig)
        convs[key]?.rebuild()
        changed()
    }

    fun markAllHeard(key: String? = null) {
        for (c in convs.values) {
            if (key == null || c.key == key) {
                c.msgs.forEach { setHeard(c.key, it.sig) }
                c.rebuild()
            }
        }
        changed()
    }

    /** Responde pela própria notificação do app (RemoteInput). false se não for possível. */
    fun sendReply(ctx: Context, key: String, text: String): Boolean {
        val conv = convs[key] ?: return false
        val action = conv.replyAction ?: return false
        val inputs = action.remoteInputs
        if (inputs == null || inputs.isEmpty()) return false
        val pi = action.actionIntent ?: return false
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try {
            pi.send(ctx, 0, intent)
            markAllHeard(key)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }

    fun openChat(ctx: Context, key: String): Boolean {
        val pi = convs[key]?.openIntent ?: return false
        return try {
            if (Build.VERSION.SDK_INT >= 34) {
                val opts = ActivityOptions.makeBasic().setPendingIntentBackgroundActivityStartMode(
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                ).toBundle()
                pi.send(ctx, 0, null, null, null, null, opts)
            } else {
                pi.send()
            }
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }

    /** Mensagens de exemplo (de apps diferentes) para testar o visual. */
    fun addDemo(ctx: Context) {
        val now = System.currentTimeMillis()
        fun m(id: Int, t: String, ago: Int, who: String) =
            Msg(t, now - ago * 60_000L, who, "demo:$id")
        upsert("demo:maria", "demo:maria", "demo", "WhatsApp", "Maria", false, listOf(
            m(1, ctx.getString(R.string.demo_1), 6, "Maria"),
            m(2, ctx.getString(R.string.demo_2), 5, "Maria"),
            m(3, ctx.getString(R.string.demo_3), 1, "Maria")
        ), null, null)
        upsert("demo:family", "demo:family", "demo", "Telegram", ctx.getString(R.string.demo_group), true, listOf(
            m(4, ctx.getString(R.string.demo_4), 20, "João"),
            m(5, ctx.getString(R.string.demo_5), 18, "Ana"),
            m(6, ctx.getString(R.string.demo_6), 17, "João")
        ), null, null)
        upsert("demo:insta", "demo:insta", "demo", "Instagram", "lia.design", false, listOf(
            m(7, ctx.getString(R.string.demo_7), 9, "lia.design")
        ), null, null)
    }
}
