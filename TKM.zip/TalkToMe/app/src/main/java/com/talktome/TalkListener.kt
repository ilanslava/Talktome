package com.talktome

import android.app.Notification
import android.content.ComponentName
import android.content.res.Configuration
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

/**
 * Lê as notificações de mensagem de QUALQUER app (WhatsApp, Telegram, Instagram,
 * Messenger, SMS, Signal, Discord...). Uma notificação conta como mensagem se usa o estilo
 * de mensagens, tem a categoria "message" ou tem ação de resposta rápida.
 */
class TalkListener : NotificationListenerService() {

    private var overlay: OverlayController? = null
    private val accountByGroup = HashMap<String, String>() // "pkg|grupo" -> conta do e-mail
    private val summaryKeys = HashMap<String, String>() // notificação-resumo de grupo -> pacote

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        overlay = OverlayController(this).also { it.start() }
        registerCar()
        reload()
    }

    override fun onListenerDisconnected() {
        unregisterCar()
        overlay?.stop()
        overlay = null
        instance = null
        requestRebind(ComponentName(this, TalkListener::class.java))
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        unregisterCar()
        overlay?.stop()
        overlay = null
        instance = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlay?.onConfigChanged()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) safeHandle(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) {
            MessageStore.removeNotif(sbn.key)
            summaryKeys.remove(sbn.key)
        }
    }

    // ---------------------------------------------------------------- modo carro

    private val carReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context, i: android.content.Intent) {
            when (i.action) {
                android.app.UiModeManager.ACTION_ENTER_CAR_MODE -> CarMode.uiCar = true
                android.app.UiModeManager.ACTION_EXIT_CAR_MODE -> CarMode.uiCar = false
                android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED,
                android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    val connected = i.action == android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED
                    @Suppress("DEPRECATION")
                    val dev = i.getParcelableExtra<android.bluetooth.BluetoothDevice>(
                        android.bluetooth.BluetoothDevice.EXTRA_DEVICE
                    )
                    if (isCarDevice(dev)) CarMode.btCar = connected
                }
            }
            overlay?.carModeChanged()
        }
    }

    private fun isCarDevice(dev: android.bluetooth.BluetoothDevice?): Boolean {
        if (dev == null) return false
        return try {
            dev.address == Prefs.carBtAddress(this) ||
                dev.bluetoothClass?.deviceClass == android.bluetooth.BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO
        } catch (e: SecurityException) {
            false // sem permissão de Bluetooth: só vale o modo carro do Android / ligar na mão
        }
    }

    private fun registerCar() {
        try {
            val ui = getSystemService(android.content.Context.UI_MODE_SERVICE) as? android.app.UiModeManager
            CarMode.uiCar = ui?.currentModeType == Configuration.UI_MODE_TYPE_CAR
            val f = android.content.IntentFilter().apply {
                addAction(android.app.UiModeManager.ACTION_ENTER_CAR_MODE)
                addAction(android.app.UiModeManager.ACTION_EXIT_CAR_MODE)
                addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
            }
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                registerReceiver(carReceiver, f, android.content.Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(carReceiver, f)
            }
        } catch (e: Exception) {
            // sem modo carro automático; o botão manual continua valendo
        }
    }

    private fun unregisterCar() {
        try {
            unregisterReceiver(carReceiver)
        } catch (e: Exception) {
            // já estava solto
        }
    }

    /** Tira da barra de status as notificações [keys] (e os resumos de grupo dos apps [pkgs]). */
    fun cancelTracked(keys: Collection<String>, pkgs: Set<String>) {
        try {
            for (k in keys) cancelNotification(k)
            for ((k, p) in summaryKeys.entries.toList()) if (p in pkgs) cancelNotification(k)
        } catch (e: Exception) {
            // listener desconectado: só o painel foi limpo
        }
    }

    /** Chamado pelas configurações quando o modo carro liga/desliga. */
    fun carChanged() {
        overlay?.carModeChanged()
    }

    /** [showAgain]: traz de volta a bolinha que foi ocultada. */
    fun refreshOverlay(showAgain: Boolean = false) {
        if (showAgain) overlay?.showAgain() else overlay?.refresh()
    }

    /** Relê todas as notificações ativas (ex.: depois de ligar/desligar um app). */
    fun reload() {
        MessageStore.silent = true // não lê em voz alta o que já estava na barra
        MessageStore.clear()
        try {
            activeNotifications?.forEach { safeHandle(it) }
        } catch (e: Exception) {
            // sem acesso ainda; as próximas notificações chegam em onNotificationPosted
        } finally {
            MessageStore.silent = false
        }
        overlay?.refresh()
    }

    /** Notificação de terceiros malformada nunca pode derrubar o serviço. */
    private fun safeHandle(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            // ignora essa notificação
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            // resumo do grupo (e-mails): guarda a conta pra usar nas mensagens do mesmo grupo
            val g = n.group
            val acct = accountFrom(n.extras)
            if (g != null && acct != null && '@' in acct) accountByGroup[pkg + "|" + g] = acct
            summaryKeys[sbn.key] = pkg
            return
        }
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_CALL || cat == Notification.CATEGORY_TRANSPORT) return

        val email = cat == Notification.CATEGORY_EMAIL || pkg in EMAIL_PKGS
        val reply = if (email) null else findReplyAction(n) // e-mail: sem resposta pela notificação
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val ai = pkg in AI_PKGS // apps de IA (ChatGPT, Claude, Gemini...) postam notificação comum, sem estilo de mensagem
        // "gerando resposta..." (progresso) não é mensagem
        if (ai && (cat == Notification.CATEGORY_PROGRESS || n.extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0) > 0)) return
        val looksLikeMessage = style != null || cat == Notification.CATEGORY_MESSAGE || reply != null || email || ai
        if (!looksLikeMessage) return

        Prefs.markSeen(this, pkg)
        if (pkg in Prefs.disabledApps(this)) {
            MessageStore.removeNotif(sbn.key)
            return
        }

        val extras = n.extras
        // WhatsApp: tenta achar o id (jid) do chat pra abrir direto na conversa ao mandar áudio
        val chatJid = if (pkg.startsWith("com.whatsapp")) waJid(n, style) else null
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val msgs = ArrayList<MessageStore.Msg>()
        val skipCodes = Prefs.skipCodes(this)
        var convTitle = title
        var isGroup = false
        var account: String? = null
        var subject: String? = null
        var emailTo: String? = null

        if (email) {
            // remetente = título; assunto = texto; prévia = texto grande. A conta que recebeu vem no subtexto.
            account = accountFrom(extras) ?: n.group?.let { accountByGroup[pkg + "|" + it] }
            emailTo = emailFromPeople(extras)
            val subj = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
            val body = when {
                big.isEmpty() || big == subj -> ""
                subj.isNotEmpty() && big.startsWith(subj) -> big.removePrefix(subj).trim()
                else -> big
            }
            subject = subj.ifEmpty { null }
            val t = buildString {
                if (subj.isNotEmpty()) append(getString(R.string.email_subject)).append(": ").append(subj)
                if (body.isNotEmpty()) {
                    if (isNotEmpty()) append('\n')
                    append(body)
                }
            }
            if (t.isNotEmpty() && !(skipCodes && looksLikeCode(t)))
                msgs.add(MessageStore.Msg(t, sbn.postTime, title, "x|${sbn.key}|$t"))
        } else if (style != null && style.messages.isNotEmpty()) {
            val me = style.user.name?.toString()?.takeIf { it.isNotBlank() }
            val groupTitle = style.conversationTitle?.toString()?.takeIf { it.isNotBlank() }
            if (groupTitle != null) convTitle = groupTitle
            isGroup = style.isGroupConversation || groupTitle != null
            for (m in style.messages) {
                val t = m.text?.toString()?.trim().orEmpty()
                if (t.isEmpty() || (skipCodes && looksLikeCode(t))) continue
                val who = m.person?.name?.toString().orEmpty()
                if (me != null && who == me) continue // mensagem minha
                // sem horário confiável (0): usa o da notificação e a chave dela na assinatura
                val ts = m.timestamp
                if (ts > 0L) msgs.add(MessageStore.Msg(t, ts, who.ifBlank { title }, "$who|$ts|$t"))
                else msgs.add(MessageStore.Msg(t, sbn.postTime, who.ifBlank { title }, "x|${sbn.key}|$t"))
            }
        } else {
            val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null && lines.isNotEmpty()) {
                lines.forEachIndexed { i, l ->
                    val t = l?.toString()?.trim().orEmpty()
                    if (t.isNotEmpty() && !(skipCodes && looksLikeCode(t)))
                        msgs.add(MessageStore.Msg(t, sbn.postTime + i, title, "x|${sbn.key}|$t"))
                }
            } else {
                val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
                if (t.isNotEmpty() && !(skipCodes && looksLikeCode(t)))
                    msgs.add(MessageStore.Msg(t, sbn.postTime, title, "x|${sbn.key}|$t"))
            }
        }
        if (msgs.isEmpty()) {
            MessageStore.removeNotif(sbn.key)
            return
        }
        if (convTitle.isBlank()) convTitle = appLabel(this, pkg)

        // apps que postam uma notificação por mensagem caem na mesma conversa (mesmo atalho/título)
        // e-mail: o mesmo remetente em contas diferentes fica em conversas separadas
        val convKey = if (email) pkg + "|" + (account ?: "") + "|" + convTitle.lowercase()
        else pkg + "|" + (n.shortcutId?.takeIf { it.isNotBlank() } ?: convTitle.lowercase())

        MessageStore.upsert(
            sbn.key, convKey, pkg, appLabel(this, pkg), convTitle,
            isGroup, msgs, reply, n.contentIntent, n.shortcutId,
            account, email, emailTo, subject, chatJid
        )
    }

    /**
     * Id do chat no WhatsApp (xxx@s.whatsapp.net / xxx@g.us). Procura no atalho da notificação e nas
     * pessoas da mensagem; se só houver um telefone (tel:), monta o id a partir dele.
     */
    @Suppress("DEPRECATION")
    private fun waJid(n: Notification, style: NotificationCompat.MessagingStyle?): String? {
        val cands = ArrayList<String>()
        n.shortcutId?.let { cands.add(it) }
        try {
            style?.messages?.forEach { m ->
                m.person?.key?.let { cands.add(it) }
                m.person?.uri?.let { cands.add(it) }
            }
            n.extras.getParcelableArrayList<android.app.Person>(Notification.EXTRA_PEOPLE_LIST)?.forEach { p ->
                p.key?.let { cands.add(it) }
                p.uri?.let { cands.add(it) }
            }
        } catch (e: Exception) {
            // usa o que já achou
        }
        for (raw in cands) {
            val s = raw.trim()
            if (s.endsWith("@s.whatsapp.net") || s.endsWith("@g.us")) return s
        }
        for (raw in cands) {
            if (raw.startsWith("tel:", ignoreCase = true)) {
                val d = raw.substring(4).filter { it.isDigit() }
                if (d.length in 10..15) return "$d@s.whatsapp.net"
            }
        }
        return null
    }

    /** Conta que recebeu o e-mail: prefere o que parece endereço (tem @) no subtexto/resumo/info. */
    private fun accountFrom(extras: android.os.Bundle): String? {
        fun txt(k: String) = extras.getCharSequence(k)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val sub = txt(Notification.EXTRA_SUB_TEXT)
        val all = listOfNotNull(sub, txt(Notification.EXTRA_SUMMARY_TEXT), txt(Notification.EXTRA_INFO_TEXT))
        return all.firstOrNull { '@' in it } ?: sub
    }

    /** Endereço do remetente, se o app de e-mail mandar nas "pessoas" da notificação. */
    @Suppress("DEPRECATION")
    private fun emailFromPeople(extras: android.os.Bundle): String? {
        try {
            extras.getParcelableArrayList<android.app.Person>(Notification.EXTRA_PEOPLE_LIST)?.forEach { p ->
                val u = p.uri
                if (u != null && u.startsWith("mailto:", ignoreCase = true)) {
                    val a = u.substring(7).substringBefore('?').trim()
                    if (a.isNotEmpty()) return a
                }
                val nm = p.name?.toString()
                if (nm != null && '@' in nm) return nm.trim()
            }
        } catch (e: Exception) {
            // segue pro formato antigo
        }
        try {
            extras.getStringArray(Notification.EXTRA_PEOPLE)?.forEach { u ->
                if (u.startsWith("mailto:", ignoreCase = true)) {
                    val a = u.substring(7).substringBefore('?').trim()
                    if (a.isNotEmpty()) return a
                }
            }
        } catch (e: Exception) {
            // sem endereço
        }
        return null
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }?.let { return it }
        return try {
            Notification.WearableExtender(n).actions
                .firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        @Volatile
        var instance: TalkListener? = null

        /** Apps de IA conhecidos: as notificações deles entram no painel como mensagens. */
        private val AI_PKGS = setOf(
            "com.openai.chatgpt", "com.anthropic.claude", "com.google.android.apps.bard",
            "com.microsoft.copilot", "ai.perplexity.app.android", "ai.x.grok", "com.deepseek.chat",
            "ai.mistral.chat", "ai.character.app", "com.poe.android", "com.moonshot.kimichat"
        )

        /** Apps de e-mail conhecidos (além de quem marca a notificação como categoria "email"). */
        private val EMAIL_PKGS = setOf(
            "com.google.android.gm", "com.google.android.gm.lite", "com.microsoft.office.outlook",
            "com.yahoo.mobile.client.android.mail", "ch.protonmail.android",
            "com.samsung.android.email.provider", "com.fsck.k9", "com.fsck.k9.material",
            "net.thunderbird.android", "com.appple.app.email", "me.bluemail.mail"
        )
    }
}
