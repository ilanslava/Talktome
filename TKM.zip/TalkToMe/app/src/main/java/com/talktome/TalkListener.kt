package com.talktome

import android.app.Notification
import android.content.ComponentName
import android.content.res.Configuration
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

/**
 * Lê as notificações de mensagem de QUALQUER app (WhatsApp, Telegram, Instagram,
 * Messenger, SMS, Signal, Discord...). Uma notificação conta como mensagem se usa o estilo
 * de mensagens, tem a categoria "message" ou tem ação de resposta rápida.
 */
class TalkListener : NotificationListenerService() {

    private var overlay: OverlayController? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        overlay = OverlayController(this).also { it.start() }
        reload()
    }

    override fun onListenerDisconnected() {
        overlay?.stop()
        overlay = null
        instance = null
        requestRebind(ComponentName(this, TalkListener::class.java))
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        overlay?.stop()
        overlay = null
        instance = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlay?.onConfigChanged()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) safeHandle(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) MessageStore.removeNotif(sbn.key)
    }

    fun refreshOverlay() {
        overlay?.refresh()
    }

    /** Relê todas as notificações ativas (ex.: depois de ligar/desligar um app). */
    fun reload() {
        MessageStore.silent = true // não lê em voz alta o que já estava na barra
        MessageStore.clear()
        try {
            activeNotifications?.forEach { safeHandle(it) }
        } catch (e: Exception) {
            // sem acesso ainda; as próximas notificações chegam em onNotificationPosted
        } finally {
            MessageStore.silent = false
        }
        overlay?.refresh()
    }

    /** Notificação de terceiros malformada nunca pode derrubar o serviço. */
    private fun safeHandle(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Exception) {
            // ignora essa notificação
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_CALL || cat == Notification.CATEGORY_TRANSPORT) return

        val reply = findReplyAction(n)
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val looksLikeMessage = style != null || cat == Notification.CATEGORY_MESSAGE || reply != null
        if (!looksLikeMessage) return

        Prefs.markSeen(this, pkg)
        if (pkg in Prefs.disabledApps(this)) {
            MessageStore.removeNotif(sbn.key)
            return
        }

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val msgs = ArrayList<MessageStore.Msg>()
        val skipCodes = Prefs.skipCodes(this)
        var convTitle = title
        var isGroup = false

        if (style != null && style.messages.isNotEmpty()) {
            val me = style.user.name?.toString()?.takeIf { it.isNotBlank() }
            val groupTitle = style.conversationTitle?.toString()?.takeIf { it.isNotBlank() }
            if (groupTitle != null) convTitle = groupTitle
            isGroup = style.isGroupConversation || groupTitle != null
            for (m in style.messages) {
                val t = m.text?.toString()?.trim().orEmpty()
                if (t.isEmpty() || (skipCodes && looksLikeCode(t))) continue
                val who = m.person?.name?.toString().orEmpty()
                if (me != null && who == me) continue // mensagem minha
                // sem horário confiável (0): usa o da notificação e a chave dela na assinatura
                val ts = m.timestamp
                if (ts > 0L) msgs.add(MessageStore.Msg(t, ts, who.ifBlank { title }, "$who|$ts|$t"))
                else msgs.add(MessageStore.Msg(t, sbn.postTime, who.ifBlank { title }, "x|${sbn.key}|$t"))
            }
        } else {
            val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null && lines.isNotEmpty()) {
                lines.forEachIndexed { i, l ->
                    val t = l?.toString()?.trim().orEmpty()
                    if (t.isNotEmpty() && !(skipCodes && looksLikeCode(t)))
                        msgs.add(MessageStore.Msg(t, sbn.postTime + i, title, "x|${sbn.key}|$t"))
                }
            } else {
                val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
                if (t.isNotEmpty() && !(skipCodes && looksLikeCode(t)))
                    msgs.add(MessageStore.Msg(t, sbn.postTime, title, "x|${sbn.key}|$t"))
            }
        }
        if (msgs.isEmpty()) {
            MessageStore.removeNotif(sbn.key)
            return
        }
        if (convTitle.isBlank()) convTitle = appLabel(this, pkg)

        // apps que postam uma notificação por mensagem caem na mesma conversa (mesmo atalho/título)
        val convKey = pkg + "|" + (n.shortcutId?.takeIf { it.isNotBlank() } ?: convTitle.lowercase())

        MessageStore.upsert(
            sbn.key, convKey, pkg, appLabel(this, pkg), convTitle,
            isGroup, msgs, reply, n.contentIntent
        )
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }?.let { return it }
        return try {
            Notification.WearableExtender(n).actions
                .firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        @Volatile
        var instance: TalkListener? = null
    }
}
