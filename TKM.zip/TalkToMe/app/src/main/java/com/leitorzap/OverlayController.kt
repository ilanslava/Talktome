package com.leitorzap

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.Date
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Bolha flutuante + painel com as mensagens novas.
 * Toque na bolha abre o painel; toque numa mensagem lê em voz alta;
 * deslize para a direita = ouvida, para a esquerda = dispensar.
 */
class OverlayController(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val dm: DisplayMetrics get() = ctx.resources.displayMetrics
    private fun px(v: Int) = (v * dm.density).toInt()

    private val cText = Color.parseColor("#EEF0FF")
    private val cMuted = Color.parseColor("#A5A9D6")
    private val cGreen = Color.parseColor("#34D399")
    private val cDark = Color.parseColor("#0B0E2A")

    private var started = false
    private var warnedNoOverlay = false
    private var lastShow = false
    private lateinit var speaker: Speaker
    private var speaking = false

    // bolha
    private lateinit var bubble: FrameLayout
    private lateinit var bubbleIcon: ImageView
    private lateinit var badge: TextView
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var bubbleAttached = false
    private var bubbleSize = 0

    // painel
    private lateinit var panel: LinearLayout
    private lateinit var subtitle: TextView
    private lateinit var stopChip: TextView
    private lateinit var allChip: TextView
    private lateinit var shrinkChip: TextView
    private lateinit var growChip: TextView
    private lateinit var scroll: MaxHeightScrollView
    private lateinit var list: LinearLayout
    private lateinit var actions: LinearLayout
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelAttached = false
    private var closedOutsideAt = 0L
    private var level = 1

    // mensagem selecionada e mensagens reveladas (modo privacidade)
    private var selKey: String? = null
    private var selText: String? = null
    private var selTime = 0L
    private val revealed = HashSet<String>()

    private val storeListener: () -> Unit = { refresh() }

    // ------------------------------------------------------------ ciclo de vida

    fun start() {
        if (started) return
        started = true
        speaker = Speaker(
            ctx,
            onSpeaking = { s ->
                speaking = s
                updateSpeakingUi()
            },
            onFail = { toast("No text-to-speech voice installed. Open Talk to me and use step 3.") }
        )
        buildBubble()
        buildPanel()
        MessageStore.addListener(storeListener)
        refresh()
    }

    fun stop() {
        if (!started) return
        started = false
        MessageStore.removeListener(storeListener)
        main.removeCallbacksAndMessages(null)
        detachPanel()
        detachBubble()
        speaker.shutdown()
    }

    /** Mostra/esconde a bolha e atualiza o painel conforme as mensagens e permissões. */
    fun refresh() {
        if (!started) return
        if (!Settings.canDrawOverlays(ctx)) {
            if (!warnedNoOverlay) {
                warnedNoOverlay = true
                DebugLog.add("overlay permission missing: the bubble cannot show")
            }
            return
        }
        warnedNoOverlay = false
        val unheard = MessageStore.unheardCount()
        val show = Prefs.alwaysShow(ctx) || unheard > 0 || panelAttached
        if (show != lastShow) {
            lastShow = show
            DebugLog.add("bubble " + (if (show) "shown" else "hidden") + " (unheard=$unheard)")
        }
        if (show) attachBubble() else detachBubble()
        updateBadge(unheard)
        if (panelAttached) rebuildPanel()
    }

    /** Leitura automática de mensagens que acabaram de chegar (chamado pelo listener). */
    fun autoRead() {
        if (!started) return
        val batches = MessageStore.takeNewForAutoRead()
        if (batches.isEmpty()) return
        if (Prefs.privateAudio(ctx) && !AudioUtil.headphonesConnected(ctx)) return
        val vipOnly = Prefs.autoVipOnly(ctx)
        val utts = ArrayList<Speaker.Utter>()
        for ((c, fresh) in batches) {
            if (vipOnly && !c.vip && fresh.none { Filters.hasKeyword(ctx, it.text) }) continue
            utts.add(Speaker.Utter("${c.title}, ${c.appName}. "))
            fresh.forEach { utts.add(utterFor(c, it)) }
        }
        if (utts.isEmpty()) return
        speaker.speakSmart(utts, queue = true)
        for ((c, fresh) in batches) {
            if (vipOnly && !c.vip && fresh.none { Filters.hasKeyword(ctx, it.text) }) continue
            fresh.forEach { MessageStore.markHeard(c.key, it) }
        }
    }

    // ------------------------------------------------------------ bolha

    private fun buildBubble() {
        bubbleSize = px(68)
        val icon = px(56)

        bubbleIcon = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_speaker)
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_fab)
            val pad = px(14)
            setPadding(pad, pad, pad, pad)
            elevation = px(6).toFloat()
            contentDescription = "Talk to me"
        }
        badge = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = px(22)
            minHeight = px(22)
            setPadding(px(5), 0, px(5), 0)
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_badge)
            visibility = View.GONE
        }
        bubble = FrameLayout(ctx).apply {
            addView(bubbleIcon, FrameLayout.LayoutParams(icon, icon, Gravity.BOTTOM or Gravity.START))
            addView(
                badge,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.END
                )
            )
        }

        val startX = Prefs.btnX(ctx).takeIf { it >= 0 } ?: (dm.widthPixels - bubbleSize - px(8))
        val startY = Prefs.btnY(ctx).takeIf { it >= 0 } ?: (dm.heightPixels * 0.55).toInt()
        bubbleParams = WindowManager.LayoutParams(
            bubbleSize, bubbleSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
        }

        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            var ox = 0
            var oy = 0
            var downX = 0f
            var downY = 0f
            var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ox = bubbleParams.x
                        oy = bubbleParams.y
                        downX = e.rawX
                        downY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && hypot(dx, dy) > slop) moved = true
                        if (moved) {
                            bubbleParams.x = (ox + dx).toInt()
                                .coerceIn(0, max(0, dm.widthPixels - bubbleSize))
                            bubbleParams.y = (oy + dy).toInt()
                                .coerceIn(0, max(0, dm.heightPixels - bubbleSize))
                            runCatching { wm.updateViewLayout(bubble, bubbleParams) }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) Prefs.setBtnPos(ctx, bubbleParams.x, bubbleParams.y)
                        else togglePanel()
                    }
                }
                return true
            }
        })
    }

    private fun attachBubble() {
        if (bubbleAttached) return
        bubbleParams.x = bubbleParams.x.coerceIn(0, max(0, dm.widthPixels - bubbleSize))
        bubbleParams.y = bubbleParams.y.coerceIn(0, max(0, dm.heightPixels - bubbleSize))
        runCatching {
            wm.addView(bubble, bubbleParams)
            bubbleAttached = true
        }.onFailure { DebugLog.add("bubble addView failed: ${it.javaClass.simpleName} ${it.message}") }
    }

    private fun detachBubble() {
        if (!bubbleAttached) return
        runCatching { wm.removeView(bubble) }
        bubbleAttached = false
    }

    private fun updateBadge(n: Int) {
        badge.visibility = if (n > 0) View.VISIBLE else View.GONE
        badge.text = if (n > 99) "99+" else n.toString()
    }

    private fun updateSpeakingUi() {
        if (!started) return
        bubbleIcon.setImageResource(if (speaking) R.drawable.ic_stop else R.drawable.ic_speaker)
        bubbleIcon.background = ContextCompat.getDrawable(
            ctx, if (speaking) R.drawable.bg_fab_active else R.drawable.bg_fab
        )
        stopChip.visibility = if (speaking) View.VISIBLE else View.GONE
        allChip.visibility = if (speaking) View.GONE else View.VISIBLE
    }

    // ------------------------------------------------------------ painel

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun chip(t: String, bg: Int, color: Int, size: Float = 13f, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(px(12), px(8), px(12), px(8))
            background = ContextCompat.getDrawable(ctx, bg)
            setOnClickListener { onClick() }
        }

    private fun chipLp() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { marginStart = px(6) }

    private fun buildPanel() {
        level = Prefs.panelLevel(ctx).coerceIn(0, LEVELS.size - 1)

        subtitle = tv("", 12.5f, cMuted)
        val titleCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Talk to me", 17f, cText, bold = true))
            addView(subtitle)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        stopChip = chip("■ Stop", R.drawable.bg_chip_indigo, cText) { speaker.stop() }
            .apply { visibility = View.GONE }
        allChip = chip("▶ All", R.drawable.bg_chip_green, cDark) { readAll() }
        val closeChip = chip("✕", R.drawable.bg_chip_indigo, cText) { closePanel() }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleCol)
            addView(stopChip, chipLp())
            addView(allChip, chipLp())
            addView(closeChip, chipLp())
        }

        // segunda linha: mãos livres + tamanho do painel
        shrinkChip = chip("−", R.drawable.bg_chip_indigo, cText, 16f) { setLevel(level - 1) }
        growChip = chip("+", R.drawable.bg_chip_indigo, cText, 16f) { setLevel(level + 1) }
        val handsFree = chip("🎙 Hands-free", R.drawable.bg_chip_indigo, cText, 12.5f) { startHandsFree() }
        val spacer = View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val toolbar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
            addView(handsFree)
            addView(spacer)
            addView(shrinkChip, chipLp())
            addView(growChip, chipLp())
        }

        list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll = MaxHeightScrollView(ctx, levelHeight()).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(4) }
        }

        fun actionLp() = LinearLayout.LayoutParams(0, px(44), 1f).apply {
            marginStart = px(3)
            marginEnd = px(3)
        }
        actions = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(12) }
            addView(chip("🎤 Record", R.drawable.bg_chip_green, cDark, 14f) { launchReply(true) }, actionLp())
            addView(chip("✍ Type", R.drawable.bg_chip_indigo, cText, 14f) { launchReply(false) }, actionLp())
            addView(chip("Open chat", R.drawable.bg_chip_indigo, cText, 14f) { openSelectedChat() }, actionLp())
        }

        panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_panel)
            setPadding(px(16), px(14), px(16), px(16))
            elevation = px(12).toFloat()
            addView(header)
            addView(toolbar)
            addView(scroll)
            addView(actions)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    closedOutsideAt = SystemClock.uptimeMillis()
                    main.post { closePanel() }
                    true
                } else false
            }
        }
    }

    private fun panelParams() = WindowManager.LayoutParams(
        min(dm.widthPixels - px(24), px(520)),
        ViewGroup.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = px(48)
    }

    private fun togglePanel() {
        if (panelAttached) closePanel()
        else if (SystemClock.uptimeMillis() - closedOutsideAt > 350) openPanel()
    }

    private fun openPanel() {
        if (panelAttached) return
        val lp = panelParams()
        panelLp = lp
        applyLevel()
        rebuildPanel()
        runCatching {
            wm.addView(panel, lp)
            panelAttached = true
        }.onFailure { DebugLog.add("panel addView failed: ${it.javaClass.simpleName} ${it.message}") }
    }

    private fun closePanel() {
        detachPanel()
        refresh()
    }

    private fun detachPanel() {
        if (!panelAttached) return
        runCatching { wm.removeView(panel) }
        panelAttached = false
        revealed.clear()
    }

    private fun rebuildPanel() {
        val convs = MessageStore.conversations()
        val unheard = MessageStore.unheardCount()
        subtitle.text = if (convs.isEmpty()) "No new messages"
        else "$unheard new · ${convs.size} chat" + if (convs.size != 1) "s" else ""

        list.removeAllViews()
        if (convs.isEmpty()) {
            list.addView(tv("Nothing new right now ✨", 14f, cMuted).apply {
                setPadding(0, px(14), 0, px(6))
            })
        }
        for (c in convs) {
            list.addView(convHeader(c))
            for (m in c.msgs) list.addView(row(c, m))
        }
        actions.visibility = if (selKey?.let { MessageStore.conv(it) } != null) View.VISIBLE else View.GONE
    }

    private fun convHeader(c: MessageStore.Conv): View {
        val star = if (c.vip) "★ " else ""
        val title = tv("$star${c.title}  ·  ${c.appName}  ·  ${c.msgs.size}", 13f, cGreen, bold = true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(14) }
            addView(title)
            addView(
                chip(if (c.vip) "★" else "☆", R.drawable.bg_chip_indigo, if (c.vip) cGreen else cText, 13f) {
                    toggleVip(c)
                }, chipLp()
            )
            addView(chip("🔇", R.drawable.bg_chip_indigo, cText, 12f) { mute(c) }, chipLp())
            addView(chip("▶", R.drawable.bg_chip_indigo, cText, 12f) { readChat(c) }, chipLp())
        }
    }

    private fun row(c: MessageStore.Conv, m: MessageStore.Msg): View {
        val selected = c.key == selKey && m.text == selText && m.time == selTime
        val hidden = Prefs.hideText(ctx) && rowId(c, m) !in revealed
        val time = DateFormat.getTimeFormat(ctx).format(Date(m.time))
        val head = if (c.isGroup && m.sender.isNotBlank()) "${m.sender} · $time" else time

        val dot = View(ctx).apply {
            background = ContextCompat.getDrawable(ctx, R.drawable.bg_dot)
            visibility = if (m.heard) View.INVISIBLE else View.VISIBLE
            layoutParams = LinearLayout.LayoutParams(px(8), px(8)).apply { marginEnd = px(10) }
        }
        val body = tv(
            if (hidden) "••••••••  tap to reveal and hear" else m.text,
            15f, if (m.heard) cMuted else cText
        ).apply {
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(tv(head, 11.5f, cMuted))
            addView(body)
        }
        val play = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_play)
            layoutParams = LinearLayout.LayoutParams(px(28), px(28)).apply { marginStart = px(8) }
        }
        val rowView = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ContextCompat.getDrawable(
                ctx, if (selected) R.drawable.bg_row_selected else R.drawable.bg_row
            )
            setPadding(px(12), px(10), px(10), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(6) }
            addView(dot)
            addView(col)
            addView(play)
        }
        attachSwipe(
            rowView,
            onTap = { onMessageTap(c, m) },
            onRight = { MessageStore.markHeard(c.key, m) },
            onLeft = { MessageStore.dismiss(c.key, m) }
        )
        return rowView
    }

    /** Toque = ouvir; deslizar para a direita = marcar como ouvida; para a esquerda = dispensar. */
    private fun attachSwipe(row: View, onTap: () -> Unit, onRight: () -> Unit, onLeft: () -> Unit) {
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        row.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var dx = 0f
            var swiping = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        dx = 0f
                        swiping = false
                        v.isPressed = true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!swiping && abs(dx) > slop && abs(dx) > abs(dy)) {
                            swiping = true
                            v.isPressed = false
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                        }
                        if (swiping) {
                            v.translationX = dx
                            v.alpha = 1f - min(abs(dx) / max(1, v.width), 1f) * 0.7f
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        v.isPressed = false
                        if (swiping) {
                            if (abs(dx) > v.width * 0.35f) {
                                val goingRight = dx > 0
                                val out = if (goingRight) v.width.toFloat() else -v.width.toFloat()
                                v.animate().translationX(out).alpha(0f).setDuration(120)
                                    .withEndAction { if (goingRight) onRight() else onLeft() }
                                    .start()
                            } else {
                                v.animate().translationX(0f).alpha(1f).setDuration(120).start()
                            }
                        } else if (abs(e.rawX - downX) < slop && abs(e.rawY - downY) < slop) {
                            onTap()
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        v.translationX = 0f
                        v.alpha = 1f
                    }
                }
                return true
            }
        })
    }

    // ------------------------------------------------------------ ações

    private fun rowId(c: MessageStore.Conv, m: MessageStore.Msg) = c.key + "|" + c.sig(m)

    private fun utterFor(c: MessageStore.Conv, m: MessageStore.Msg) =
        Speaker.Utter(if (c.isGroup && m.sender.isNotBlank()) "${m.sender}: " else "", m.text)

    /** Modo privado: só fala se houver fone/Bluetooth conectado. */
    private fun canSpeak(): Boolean {
        if (Prefs.privateAudio(ctx) && !AudioUtil.headphonesConnected(ctx)) {
            toast("Private mode is on: connect headphones to hear messages.")
            return false
        }
        return true
    }

    private fun onMessageTap(c: MessageStore.Conv, m: MessageStore.Msg) {
        selKey = c.key
        selText = m.text
        selTime = m.time
        revealed.add(rowId(c, m))
        if (canSpeak()) speaker.speakSmart(listOf(utterFor(c, m)))
        MessageStore.markHeard(c.key, m) // atualiza o painel
    }

    private fun readChat(c: MessageStore.Conv) {
        val fresh = c.msgs.filter { !it.heard }
        val toRead = if (fresh.isNotEmpty()) fresh else c.msgs
        if (toRead.isEmpty() || !canSpeak()) return
        val utts = ArrayList<Speaker.Utter>()
        toRead.forEach { utts.add(utterFor(c, it)) }
        speaker.speakSmart(utts)
        MessageStore.markAllHeard(c.key)
    }

    private fun readAll() {
        val utts = ArrayList<Speaker.Utter>()
        for (c in MessageStore.conversationsForReading()) {
            val fresh = c.msgs.filter { !it.heard }
            if (fresh.isEmpty()) continue
            utts.add(Speaker.Utter("${c.title}, ${c.appName}. "))
            fresh.forEach { utts.add(utterFor(c, it)) }
        }
        if (utts.isEmpty()) {
            toast("Nothing new to read")
            return
        }
        if (!canSpeak()) return
        speaker.speakSmart(utts)
        MessageStore.markAllHeard()
    }

    private fun toggleVip(c: MessageStore.Conv) {
        val now = Prefs.toggleVip(ctx, c.title)
        MessageStore.refreshVip { Filters.isVip(ctx, it) }
        toast(if (now) "★ ${c.title} is now a VIP" else "${c.title} is no longer a VIP")
    }

    private fun mute(c: MessageStore.Conv) {
        val name = c.title
        Prefs.toggleMuted(ctx, name)
        MessageStore.removeByTitle(name)
        toast("Muted $name. You can undo it in the app, under Filters.")
    }

    private fun startHandsFree() {
        speaker.stop()
        closePanel()
        try {
            ctx.startActivity(
                Intent(ctx, HandsFreeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            toast("Couldn't open hands-free mode")
        }
    }

    private fun launchReply(voice: Boolean) {
        val key = selKey ?: return
        speaker.stop()
        closePanel()
        val i = Intent(ctx, ReplyActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(ReplyActivity.EXTRA_KEY, key)
            .putExtra(ReplyActivity.EXTRA_VOICE, voice)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            toast("Couldn't open the reply screen")
        }
    }

    private fun openSelectedChat() {
        val key = selKey ?: return
        if (MessageStore.openChat(key)) closePanel()
        else toast("That chat can't be opened from here. Open the app.")
    }

    private fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ tamanho do painel

    private fun levelHeight() = (dm.heightPixels * LEVELS[level]).toInt()

    private fun setLevel(l: Int) {
        val nl = l.coerceIn(0, LEVELS.size - 1)
        if (nl == level) return
        level = nl
        Prefs.setPanelLevel(ctx, nl)
        applyLevel()
    }

    private fun applyLevel() {
        scroll.maxH = levelHeight()
        shrinkChip.alpha = if (level == 0) 0.35f else 1f
        growChip.alpha = if (level == LEVELS.size - 1) 0.35f else 1f
        scroll.requestLayout()
        val lp = panelLp
        if (panelAttached && lp != null) runCatching { wm.updateViewLayout(panel, lp) }
    }

    private companion object {
        /** Altura máxima da lista, em fração da tela. */
        val LEVELS = floatArrayOf(0.20f, 0.35f, 0.50f, 0.68f)
    }
}

private class MaxHeightScrollView(ctx: Context, var maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}
