package com.leitorzap

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

/**
 * Modo mãos livres: lê cada mensagem nova e escuta comandos de voz.
 * Comandos: next / reply / repeat / stop (e em português: próxima / responder / repetir / parar).
 * Em "reply", você fala a resposta, ouve de volta e diz "send" ou "cancel".
 */
class HandsFreeActivity : AppCompatActivity() {

    private enum class State { READING, COMMAND, REPLY, CONFIRM }

    private lateinit var speaker: Speaker
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    private val items = ArrayList<Pair<MessageStore.Conv, MessageStore.Msg>>()
    private var index = 0
    private var state = State.READING
    private var retries = 0
    private var pendingReply = ""
    private var finished = false

    private lateinit var statusView: TextView
    private lateinit var msgView: TextView
    private lateinit var heardView: TextView

    private val askMic =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) begin() else {
                toast("Microphone permission is needed for voice commands.")
                finish()
            }
        }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val cText = Color.parseColor("#EEF0FF")
        val cMuted = Color.parseColor("#A5A9D6")
        val cGreen = Color.parseColor("#34D399")
        val cDark = Color.parseColor("#0B0E2A")

        fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            this.text = t
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

        statusView = text("Starting…", 20f, cGreen, bold = true)
        msgView = text("", 17f, cText).apply {
            background = ContextCompat.getDrawable(this@HandsFreeActivity, R.drawable.bg_row)
            setPadding(px(16), px(14), px(16), px(14))
            gravity = Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(24) }
        }
        heardView = text("", 14f, cMuted).apply { setPadding(0, px(12), 0, 0) }

        fun button(t: String, bg: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
            this.text = t
            textSize = 16f
            setTextColor(color)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = ContextCompat.getDrawable(this@HandsFreeActivity, bg)
            setOnClickListener { onClick() }
        }

        fun lp() = LinearLayout.LayoutParams(0, px(54), 1f).apply {
            marginStart = px(4)
            marginEnd = px(4)
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(28) }
            addView(button("Next", R.drawable.bg_chip_indigo, cText) {
                recognizer?.cancel()
                next()
            }, lp())
            addView(button("Reply", R.drawable.bg_chip_green, cDark) {
                recognizer?.cancel()
                startReply()
            }, lp())
            addView(button("Stop", R.drawable.bg_chip_indigo, cText) { finishWith("Okay.") }, lp())
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(24), px(60), px(24), px(40))
            addView(text("🎙", 56f, cText))
            addView(statusView)
            addView(msgView)
            addView(heardView)
            addView(buttons)
        }
        setContentView(col)

        speaker = Speaker(this, onFail = {
            toast("No text-to-speech voice installed.")
            finish()
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) begin() else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onDestroy() {
        finished = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        speaker.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ fluxo

    private fun begin() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("No speech recognition on this phone.")
            finish()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        for (c in MessageStore.conversationsForReading()) {
            for (m in c.msgs) if (!m.heard) items.add(Pair(c, m))
        }
        if (items.isEmpty()) {
            finishWith("You have no new messages.")
            return
        }
        val intro = if (items.size == 1) "You have one new message." else "You have ${items.size} new messages."
        say("$intro After each one, say next, reply, repeat, or stop.") { readCurrent() }
    }

    private fun say(text: String, then: (() -> Unit)? = null) {
        if (finished) return
        val wrapped: (() -> Unit)? = then?.let { cb ->
            fun() {
                if (!finished) cb()
            }
        }
        speaker.speakSmart(listOf(Speaker.Utter(text)), onAllDone = wrapped)
    }

    private fun readCurrent() {
        if (finished) return
        if (index >= items.size) {
            finishWith("That's all your new messages.")
            return
        }
        state = State.READING
        val (c, m) = items[index]
        statusView.text = "🔊 Speaking…"
        heardView.text = ""
        msgView.text = (if (c.isGroup && m.sender.isNotBlank()) "${m.sender}\n" else "") +
                "${c.title} · ${c.appName}\n\n${m.text}"
        MessageStore.markHeard(c.key, m)

        val utts = ArrayList<Speaker.Utter>()
        if (index == 0 || items[index - 1].first.key != c.key) {
            utts.add(Speaker.Utter("${c.title}, ${c.appName}. "))
        }
        utts.add(Speaker.Utter(if (c.isGroup && m.sender.isNotBlank()) "${m.sender}: " else "", m.text))
        speaker.speakSmart(utts, onAllDone = { if (!finished) listenCommand() })
    }

    private fun listenCommand() {
        if (finished) return
        state = State.COMMAND
        retries = 0
        statusView.text = "🎙 Say: next · reply · repeat · stop"
        startListening()
    }

    private fun next() {
        index++
        readCurrent()
    }

    private fun startReply() {
        state = State.REPLY
        retries = 0
        statusView.text = "🎙 Go ahead, I'm listening"
        say("Go ahead.") { startListening() }
    }

    private fun startListening() {
        if (finished) return
        val i = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            toast("Couldn't start listening.")
            finish()
        }
    }

    private fun finishWith(text: String) {
        if (finished) return
        statusView.text = text
        handler.postDelayed({ finish() }, 6000) // garantia caso a fala falhe
        say(text) { finish() }
    }

    // ------------------------------------------------------------ comandos

    private fun tokens(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }.toSet()

    private fun matches(cands: List<String>, words: Set<String>): Boolean =
        cands.any { c -> tokens(c).any { it in words } }

    private val nextWords = setOf("next", "skip", "próxima", "proxima", "próximo", "proximo", "siguiente", "seguinte")
    private val replyWords = setOf("reply", "respond", "answer", "responder", "responde", "responda", "resposta")
    private val repeatWords = setOf("repeat", "again", "repetir", "repete", "repita", "novamente")
    private val stopWords = setOf("stop", "exit", "quit", "parar", "pare", "sair", "para", "basta", "salir")
    private val sendWords = setOf("send", "yes", "okay", "ok", "enviar", "envia", "enviar", "manda", "mandar", "sim")
    private val cancelWords = setOf("cancel", "no", "cancelar", "cancela", "não", "nao", "stop")

    private fun handleResult(cands: List<String>) {
        if (finished || cands.isEmpty()) return
        retries = 0
        heardView.text = "“${cands.first()}”"
        when (state) {
            State.COMMAND -> when {
                matches(cands, stopWords) -> finishWith("Okay, stopping.")
                matches(cands, nextWords) -> next()
                matches(cands, repeatWords) -> readCurrent()
                matches(cands, replyWords) -> startReply()
                else -> say("Sorry. Say next, reply, repeat, or stop.") { startListening() }
            }
            State.REPLY -> {
                pendingReply = cands.first()
                state = State.CONFIRM
                statusView.text = "🎙 Say: send · cancel"
                say("You said: $pendingReply. Say send, or cancel.") { startListening() }
            }
            State.CONFIRM -> when {
                matches(cands, sendWords) -> sendPending()
                matches(cands, cancelWords) -> {
                    pendingReply = ""
                    say("Cancelled.") { listenCommand() }
                }
                else -> say("Say send, or cancel.") { startListening() }
            }
            State.READING -> Unit
        }
    }

    private fun sendPending() {
        val (c, _) = items[index]
        val ok = MessageStore.isDemo(c.key) || MessageStore.sendReply(this, c.key, pendingReply)
        pendingReply = ""
        if (ok) say("Sent.") { next() }
        else say("I couldn't send it from here. Use Open chat in the app.") { listenCommand() }
    }

    private fun onNoInput(error: Int) {
        if (finished) return
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            toast("Microphone permission is needed for voice commands.")
            finish()
            return
        }
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            recognizer?.cancel()
            handler.postDelayed({ startListening() }, 500)
            return
        }
        retries++
        if (retries > 2) {
            if (state == State.REPLY || state == State.CONFIRM) {
                pendingReply = ""
                say("No reply sent.") { listenCommand() }
            } else {
                finishWith("I didn't hear anything. Stopping hands-free.")
            }
            return
        }
        val prompt = when (state) {
            State.REPLY -> "I'm listening. Go ahead."
            State.CONFIRM -> "Say send, or cancel."
            else -> "Say next, reply, repeat, or stop."
        }
        say(prompt) { startListening() }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            onNoInput(error)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            if (list.isEmpty()) onNoInput(SpeechRecognizer.ERROR_NO_MATCH) else handleResult(list)
        }
    }
}
