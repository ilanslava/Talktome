package com.leitorzap

import android.content.Context

/** Nome amigável do app (Instagram, Telegram...) a partir do pacote. */
fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}
