package com.leitorzap

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/**
 * Usa o TextToSpeech do sistema (a voz que o usuário já configurou).
 * Detecta o idioma de cada mensagem para usar a voz certa e, se ligado, traduz.
 */
class Speaker(
    context: Context,
    private val onSpeaking: (Boolean) -> Unit = {},
    private val onFail: () -> Unit = {}
) {
    /** [prefix] é lido na voz padrão; [body] é a mensagem (idioma detectado / traduzido). */
    class Utter(val prefix: String, val body: String = "")

    private class Job(val utts: List<Utter>, val onAllDone: (() -> Unit)?)

    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var defaultLocale: Locale = Locale.getDefault()
    private var defaultVoice: Voice? = null
    private var currentLang: String? = null
    private val tasks = ArrayList<() -> Unit>()
    private val callbacks = HashMap<String, () -> Unit>()
    @Volatile private var lastId = ""

    private val jobs = ArrayDeque<Job>()
    private var running = false
    private var epoch = 0
    private var flushNext = false

    init {
        tts = TextToSpeech(ctx) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        main.post { onSpeaking(true) }
                    }

                    override fun onDone(id: String?) {
                        finishUtterance(id, true)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        finishUtterance(id, true)
                    }

                    override fun onStop(id: String?, interrupted: Boolean) {
                        finishUtterance(id, false)
                    }
                })
                defaultVoice = t.voice
                defaultLocale = t.voice?.locale ?: Locale.getDefault()
                currentLang = defaultLocale.language
                ready = true
                val pending = ArrayList(tasks)
                tasks.clear()
                pending.forEach { it() }
            } else {
                failed = true
                if (tasks.isNotEmpty()) main.post { onFail() }
            }
        }
    }

    private fun finishUtterance(id: String?, runCallback: Boolean) {
        main.post {
            if (id == null) return@post
            val cb = callbacks.remove(id)
            if (runCallback) cb?.invoke()
            if (id == lastId) onSpeaking(false)
        }
    }

    // ------------------------------------------------------------ API

    /** Fala um texto simples na voz padrão. */
    fun speak(text: String, queue: Boolean = false, onDone: (() -> Unit)? = null) {
        speakSmart(listOf(Utter(text)), queue, onDone)
    }

    /**
     * Fala uma lista de trechos. Com [queue] = false interrompe o que estiver falando;
     * com true entra na fila. [onAllDone] roda quando o último trecho termina.
     */
    fun speakSmart(utts: List<Utter>, queue: Boolean = false, onAllDone: (() -> Unit)? = null) {
        if (!queue) {
            epoch++
            jobs.clear()
            running = false
            callbacks.clear()
            flushNext = true
            tts?.stop()
        }
        jobs.addLast(Job(utts.filter { it.prefix.isNotBlank() || it.body.isNotBlank() }, onAllDone))
        pump()
    }

    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    fun stop() {
        epoch++
        jobs.clear()
        running = false
        callbacks.clear()
        tts?.stop()
        onSpeaking(false)
    }

    fun shutdown() {
        epoch++
        jobs.clear()
        running = false
        callbacks.clear()
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    // ------------------------------------------------------------ fila

    private fun pump() {
        if (running) return
        val job = jobs.removeFirstOrNull() ?: return
        running = true
        runJob(job, 0, epoch)
    }

    private fun runJob(job: Job, i: Int, ep: Int) {
        if (ep != epoch) return
        if (i >= job.utts.size) {
            job.onAllDone?.let { cb -> main.post { cb() } }
            running = false
            pump()
            return
        }
        val u = job.utts[i]
        val last = i == job.utts.lastIndex
        prepare(u) { text, lang ->
            main.post {
                if (ep == epoch) {
                    speakOne(text, lang, if (last) job.onAllDone else null)
                    // quando é o último, o onAllDone é chamado ao fim da fala (não aqui)
                    if (last) {
                        running = false
                        pump()
                    } else {
                        runJob(job, i + 1, ep)
                    }
                }
            }
        }
    }

    /** Detecta idioma / traduz o corpo da mensagem. Chama cb(texto, idioma) na thread principal. */
    private fun prepare(u: Utter, cb: (String, String?) -> Unit) {
        val body = u.body
        val wantLang = Prefs.smartVoice(ctx)
        val wantTranslate = Prefs.translate(ctx)
        if (body.length < 4 || (!wantLang && !wantTranslate)) {
            cb(u.prefix + body, null)
            return
        }
        val target = Locale.getDefault().language

        // se detectar/traduzir demorar (ex.: baixando o idioma), fala o texto original
        var done = false
        val timeout = Runnable {
            if (!done) {
                done = true
                cb(u.prefix + body, null)
            }
        }
        val finish: (String, String?) -> Unit = { text, lang ->
            if (!done) {
                done = true
                main.removeCallbacks(timeout)
                cb(text, lang)
            }
        }
        main.postDelayed(timeout, 4000)

        LangTools.detect(body) { code ->
            if (code == null) {
                finish(u.prefix + body, null)
            } else if (wantTranslate && code != target) {
                LangTools.translate(body, code, target) { tr ->
                    if (tr != null) finish(u.prefix + tr, target) else finish(u.prefix + body, code)
                }
            } else {
                finish(u.prefix + body, code)
            }
        }
    }

    private fun speakOne(text: String, lang: String?, onDone: (() -> Unit)?) {
        if (failed) {
            main.post { onFail() }
            return
        }
        val t = tts
        if (!ready || t == null) {
            tasks.add { speakOne(text, lang, onDone) }
            return
        }
        if (text.isBlank()) {
            onDone?.let { cb -> main.post { cb() } }
            return
        }
        applyLanguage(t, lang)
        t.setSpeechRate(Prefs.rate(ctx))
        val max = (TextToSpeech.getMaxSpeechInputLength() - 100).coerceAtLeast(500)
        val chunks = text.chunked(max)
        val base = "u${System.nanoTime()}"
        val ids = chunks.indices.map { "${base}_$it" }
        lastId = ids.last()
        if (onDone != null) callbacks[ids.last()] = onDone
        val flush = flushNext
        flushNext = false
        chunks.forEachIndexed { i, chunk ->
            t.speak(
                chunk,
                if (i == 0 && flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                ids[i]
            )
        }
    }

    private fun applyLanguage(t: TextToSpeech, lang: String?) {
        val useDetected = lang != null && Prefs.smartVoice(ctx)
        val target: Locale = if (useDetected) Locale.forLanguageTag(lang!!) else defaultLocale
        if (target.language == currentLang) return
        if (!useDetected) {
            val v = defaultVoice
            if (v != null) t.setVoice(v) else t.setLanguage(defaultLocale)
            currentLang = defaultLocale.language
            return
        }
        if (t.isLanguageAvailable(target) >= TextToSpeech.LANG_AVAILABLE) {
            t.setLanguage(target)
            currentLang = target.language
        } else if (currentLang != defaultLocale.language) {
            val v = defaultVoice
            if (v != null) t.setVoice(v) else t.setLanguage(defaultLocale)
            currentLang = defaultLocale.language
        }
    }
}
