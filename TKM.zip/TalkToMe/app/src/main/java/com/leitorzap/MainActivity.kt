package com.leitorzap

import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var appsBox: LinearLayout
    private lateinit var vipBox: LinearLayout
    private lateinit var mutedBox: LinearLayout
    private lateinit var diagText: TextView
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private var speaker: Speaker? = null

    private val cText = Color.parseColor("#EEF0FF")
    private val cMuted = Color.parseColor("#A5A9D6")
    private val cGreen = Color.parseColor("#34D399")
    private val cIndigo = Color.parseColor("#4F46E5")
    private val cDark = Color.parseColor("#0B0E2A")

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, color: Int = cText, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.15f)
        }

    private fun hint(t: String) = label(t, 12.5f, cMuted).apply { setPadding(0, px(6), 0, 0) }

    private fun card(vararg views: android.view.View): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_card)
            setPadding(px(18), px(16), px(18), px(18))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(16) }
            views.forEach { addView(it) }
        }

    private fun section(t: String) = label(t.uppercase(), 12f, cGreen, bold = true).apply {
        letterSpacing = 0.12f
        setPadding(0, 0, 0, px(8))
    }

    private fun bigButton(t: String, bg: Int, textColor: Int, onClick: () -> Unit) =
        Button(this).apply {
            text = t
            transformationMethod = null
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
            background = ContextCompat.getDrawable(this@MainActivity, bg)
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, px(52)
            ).apply { topMargin = px(10) }
            setOnClickListener { onClick() }
        }

    private fun sw(t: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = t
        setTextColor(cText)
        textSize = 14.5f
        isChecked = checked
        thumbTintList = ColorStateList.valueOf(cGreen)
        trackTintList = ColorStateList.valueOf(cIndigo)
        setPadding(0, px(16), 0, 0)
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun editBox(initial: String, multiline: Boolean, hintText: String) = EditText(this).apply {
        setText(initial)
        hint = hintText
        setHintTextColor(cMuted)
        setTextColor(cText)
        textSize = 14.5f
        inputType = if (multiline)
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        else InputType.TYPE_CLASS_TEXT
        if (multiline) {
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
        }
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_input)
        setPadding(px(12), px(10), px(12), px(10))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = px(10) }
    }

    private fun styleSeek(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(cGreen)
        s.thumbTintList = ColorStateList.valueOf(cGreen)
        s.progressBackgroundTintList = ColorStateList.valueOf(cIndigo)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun notifAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun overlayOk() = Settings.canDrawOverlays(this)

    private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)

    private fun pickTime(current: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(this, { _, h, m -> onPicked(h * 60 + m) }, current / 60, current % 60, true).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(36), px(20), px(32))
        }

        col.addView(label("Talk to me", 30f, cText, bold = true))
        col.addView(label("Hear your new messages from WhatsApp, Telegram, Instagram and more. Answer with your voice.", 15f, cMuted).apply {
            setPadding(0, px(6), 0, 0)
        })

        status = label("", 14f, cGreen, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(px(18), px(8), px(18), px(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(18) }
        }
        col.addView(status)

        speaker = Speaker(this, onFail = {
            toast("No voice installed. Use step 3 to install one.")
        })

        // ------------------------------------------------ setup
        col.addView(card(
            section("Setup"),
            bigButton("1  ·  Allow notification access", R.drawable.bg_btn_primary, cDark) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            },
            hint(
                "Turn on \"Talk to me\". If Android blocks it (APK install), go to App info > ⋮ > " +
                        "\"Allow restricted settings\" and try again."
            ),
            bigButton("2  ·  Allow display over other apps", R.drawable.bg_btn_primary, cDark) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            },
            bigButton("3  ·  Choose the phone voice", R.drawable.bg_btn_secondary, cText) {
                try {
                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            },
            bigButton("Test the voice", R.drawable.bg_btn_secondary, cText) {
                speaker?.speak("Hello! This is the voice installed on your phone.")
            },
            bigButton("Show a demo with fake messages", R.drawable.bg_btn_secondary, cText) {
                val l = TalkListener.instance
                when {
                    l == null -> toast("Turn on notification access first (step 1).")
                    !overlayOk() -> toast("Allow display over other apps first (step 2).")
                    else -> {
                        MessageStore.addDemo()
                        l.refreshOverlay()
                    }
                }
            },
            bigButton("🎙 Start hands-free (voice commands)", R.drawable.bg_btn_primary, cDark) {
                startActivity(Intent(this, HandsFreeActivity::class.java))
            },
            hint("Hands-free reads your new messages and listens for: next, reply, repeat, stop.")
        ))

        // ------------------------------------------------ leitura automática
        startBtn = bigButton("From " + fmt(Prefs.autoStartMin(this)), R.drawable.bg_btn_secondary, cText) {
            pickTime(Prefs.autoStartMin(this)) { m ->
                Prefs.setAutoWindow(this, m, Prefs.autoEndMin(this))
                startBtn.text = "From " + fmt(m)
            }
        }
        endBtn = bigButton("Until " + fmt(Prefs.autoEndMin(this)), R.drawable.bg_btn_secondary, cText) {
            pickTime(Prefs.autoEndMin(this)) { m ->
                Prefs.setAutoWindow(this, Prefs.autoStartMin(this), m)
                endBtn.text = "Until " + fmt(m)
            }
        }
        col.addView(card(
            section("Auto-read"),
            label("Read new messages out loud as soon as they arrive.", 13.5f, cMuted),
            sw("Auto-read new messages", Prefs.autoRead(this)) { Prefs.setAutoRead(this, it) },
            sw("Only with headphones, Bluetooth or car audio", Prefs.autoHeadphonesOnly(this)) {
                Prefs.setAutoHeadphonesOnly(this, it)
            },
            sw("Only VIPs and keyword matches", Prefs.autoVipOnly(this)) { Prefs.setAutoVipOnly(this, it) },
            sw("Only during these hours", Prefs.autoScheduleOn(this)) { Prefs.setAutoScheduleOn(this, it) },
            startBtn,
            endBtn,
            hint("It never reads during a phone call, and messages that arrive when the conditions aren't met are not read later.")
        ))

        // ------------------------------------------------ respostas
        val quickEdit = editBox(
            Prefs.quickReplies(this).joinToString("\n"), true, "One quick reply per line"
        )
        col.addView(card(
            section("Replies"),
            sw("Send automatically after dictating (3 s countdown)", Prefs.autoSend(this)) {
                Prefs.setAutoSend(this, it)
            },
            hint("You can cancel during the countdown by tapping it or editing the text."),
            label("Quick replies", 14.5f, cText, bold = true).apply { setPadding(0, px(18), 0, 0) },
            quickEdit,
            bigButton("Save quick replies", R.drawable.bg_btn_secondary, cText) {
                Prefs.setQuickReplies(this, quickEdit.text.toString())
                toast("Saved")
            }
        ))

        // ------------------------------------------------ filtros
        val kwEdit = editBox(Prefs.keywordsText(this), false, "urgent, asap, urgente")
        vipBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mutedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(card(
            section("Filters"),
            sw("Only VIPs and keyword matches", Prefs.vipOnly(this)) {
                Prefs.setVipOnly(this, it)
                TalkListener.instance?.reload()
            },
            hint("In the message panel, tap ☆ next to a chat to make it a VIP, or 🔇 to mute it."),
            label("Priority keywords (comma separated)", 14.5f, cText, bold = true)
                .apply { setPadding(0, px(18), 0, 0) },
            kwEdit,
            bigButton("Save keywords", R.drawable.bg_btn_secondary, cText) {
                Prefs.setKeywords(this, kwEdit.text.toString())
                TalkListener.instance?.reload()
                toast("Saved")
            },
            label("VIPs", 14.5f, cText, bold = true).apply { setPadding(0, px(18), 0, 0) },
            vipBox,
            label("Muted", 14.5f, cText, bold = true).apply { setPadding(0, px(18), 0, 0) },
            mutedBox
        ))

        // ------------------------------------------------ voz e tela
        val rateLabel = label("", 14.5f)
        fun updateRate(r: Float) { rateLabel.text = "Voice speed: %.2fx".format(r) }
        updateRate(Prefs.rate(this))
        val rateSeek = SeekBar(this).apply {
            max = 150
            progress = ((Prefs.rate(this@MainActivity) - 0.5f) * 100).toInt()
            styleSeek(this)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val r = 0.5f + p / 100f
                    Prefs.setRate(this@MainActivity, r)
                    updateRate(r)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(card(
            section("Voice & bubble"),
            rateLabel,
            rateSeek,
            sw("Use the right voice for each message's language", Prefs.smartVoice(this)) {
                Prefs.setSmartVoice(this, it)
            },
            sw("Translate other languages to my language", Prefs.translate(this)) {
                Prefs.setTranslate(this, it)
            },
            hint("Translation downloads each language pack once (needs internet the first time). Language detection works offline."),
            sw("Keep the bubble always on screen", Prefs.alwaysShow(this)) {
                Prefs.setAlwaysShow(this, it)
                TalkListener.instance?.refreshOverlay()
            },
            hint("Off: the bubble only appears when there are new messages.")
        ))

        // ------------------------------------------------ privacidade
        col.addView(card(
            section("Privacy"),
            sw("Hide message text in the panel until I tap it", Prefs.hideText(this)) {
                Prefs.setHideText(this, it)
            },
            sw("Private audio: only speak with headphones connected", Prefs.privateAudio(this)) {
                Prefs.setPrivateAudio(this, it)
            },
            hint("The bubble only ever shows the number of new messages.")
        ))

        // ------------------------------------------------ apps
        appsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(card(
            section("Apps"),
            hint(
                "Works with any app that shows message notifications: WhatsApp, Telegram, Instagram, " +
                        "Messenger, SMS, Signal, Discord, Slack... Turn off the ones you don't want to hear."
            ),
            appsBox
        ))

        // ------------------------------------------------ diagnóstico
        diagText = label("", 11.5f, cMuted).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, px(12), 0, 0)
        }
        col.addView(card(
            section("Diagnostics"),
            hint("If a message doesn't show up, tap Copy report and send it to Claude."),
            bigButton("Refresh", R.drawable.bg_btn_secondary, cText) { refreshDiag() },
            bigButton("Copy report", R.drawable.bg_btn_secondary, cText) { copyReport() },
            bigButton("Restart listener", R.drawable.bg_btn_secondary, cText) {
                NotificationListenerService.requestRebind(ComponentName(this, TalkListener::class.java))
                toast("Asked Android to restart the listener. Wait a few seconds and tap Refresh.")
            },
            diagText
        ))

        // ------------------------------------------------ como funciona
        col.addView(card(
            section("How it works"),
            label(
                "•  A bubble shows how many new messages you have, from all your apps.\n" +
                        "•  Tap it to open them, grouped by chat. Use − and + to resize the panel.\n" +
                        "•  Tap a message to hear it. Swipe right = mark as heard, swipe left = dismiss.\n" +
                        "•  Then tap 🎤 Record or pick a quick reply. After 3 seconds it is sent, unless you cancel.\n" +
                        "•  🎙 Hands-free: say next, reply, repeat or stop, no touching needed.\n" +
                        "•  Replies go through the app's own notification, so the chat doesn't need to open. " +
                        "If an app doesn't allow that, use Open chat.\n" +
                        "•  If an app hides message content in its notifications (privacy setting), there is nothing to read.\n" +
                        "•  Voice notes can't be sent automatically. Use Open chat for those.",
                14f, cMuted
            )
        ))

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    override fun onResume() {
        super.onResume()
        val missing = ArrayList<String>()
        if (!notifAccess()) missing.add("notification access")
        if (!overlayOk()) missing.add("display over apps")
        val ready = missing.isEmpty()
        status.text = if (ready) "●  Ready" else "●  Missing: " + missing.joinToString(", ")
        status.setTextColor(if (ready) cGreen else Color.parseColor("#C7D2FE"))
        status.background = ContextCompat.getDrawable(
            this, if (ready) R.drawable.bg_status_on else R.drawable.bg_status_off
        )
        refreshApps()
        refreshLists()
        refreshDiag()
        // se a permissão de sobreposição acabou de ser dada, mostra a bolha
        TalkListener.instance?.refreshOverlay()
    }

    override fun onDestroy() {
        speaker?.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ listas

    private fun nameRows(box: LinearLayout, names: Set<String>, emptyText: String, onRemove: (String) -> Unit) {
        box.removeAllViews()
        if (names.isEmpty()) {
            box.addView(label(emptyText, 13f, cMuted).apply { setPadding(0, px(8), 0, 0) })
            return
        }
        for (n in names.sorted()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, px(10), 0, 0)
                addView(label(n, 15f).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(this@MainActivity).apply {
                    text = "Remove"
                    textSize = 12.5f
                    setTextColor(cText)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(px(12), px(7), px(12), px(7))
                    background = ContextCompat.getDrawable(this@MainActivity, R.drawable.bg_chip_indigo)
                    setOnClickListener { onRemove(n) }
                })
            }
            box.addView(row)
        }
    }

    private fun refreshLists() {
        nameRows(vipBox, Prefs.vips(this), "No VIPs yet. In the panel, tap ☆ next to a chat.") { n ->
            Prefs.toggleVip(this, n)
            MessageStore.refreshVip { Filters.isVip(this, it) }
            TalkListener.instance?.reload()
            refreshLists()
        }
        nameRows(mutedBox, Prefs.muted(this), "No muted chats. In the panel, tap 🔇 next to a chat.") { n ->
            Prefs.toggleMuted(this, n)
            TalkListener.instance?.reload()
            refreshLists()
        }
    }

    private fun refreshApps() {
        appsBox.removeAllViews()
        val seen = Prefs.seenApps(this).sortedBy { appLabel(this, it).lowercase() }
        if (seen.isEmpty()) {
            appsBox.addView(
                label("None yet. Apps show up here after they send you a message notification.", 13.5f, cMuted)
                    .apply { setPadding(0, px(12), 0, 0) }
            )
            return
        }
        val disabled = Prefs.disabledApps(this)
        for (pkg in seen) {
            appsBox.addView(Switch(this).apply {
                text = appLabel(this@MainActivity, pkg)
                setTextColor(cText)
                textSize = 15f
                isChecked = pkg !in disabled
                thumbTintList = ColorStateList.valueOf(cGreen)
                trackTintList = ColorStateList.valueOf(cIndigo)
                setPadding(0, px(12), 0, 0)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setAppEnabled(this@MainActivity, pkg, on)
                    TalkListener.instance?.reload()
                }
            })
        }
    }

    // ------------------------------------------------------------ diagnóstico

    private fun report(): String {
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.SDK_INT} · ${Build.MANUFACTURER} ${Build.MODEL}\n")
        sb.append("Notification access: ${if (notifAccess()) "ON" else "OFF"}\n")
        sb.append("Display over apps: ${if (overlayOk()) "ON" else "OFF"}\n")
        sb.append("Listener running: ${if (TalkListener.instance != null) "YES" else "NO"}\n")
        sb.append("Headphones connected: ${if (AudioUtil.headphonesConnected(this)) "YES" else "NO"}\n")
        sb.append("Chats in memory: ${MessageStore.conversations().size}, unheard: ${MessageStore.unheardCount()}\n")
        sb.append("Apps seen: ${Prefs.seenApps(this).joinToString()}\n")
        sb.append("Apps turned off: ${Prefs.disabledApps(this).joinToString()}\n\n")
        sb.append(DebugLog.dump().ifBlank { "(no notifications received yet)" })
        return sb.toString()
    }

    private fun refreshDiag() {
        diagText.text = report()
    }

    private fun copyReport() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Talk to me report", report()))
        toast("Report copied. Paste it in the chat with Claude.")
    }
}
