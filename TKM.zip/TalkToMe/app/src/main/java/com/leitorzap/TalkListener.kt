package com.leitorzap

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

/**
 * Lê as notificações de mensagem de QUALQUER app (WhatsApp, Telegram, Instagram,
 * Messenger, SMS, Signal, Discord...). Uma notificação conta como mensagem se usa o estilo
 * de mensagens, tem a categoria "message" ou tem ação de resposta rápida.
 */
class TalkListener : NotificationListenerService() {

    private var overlay: OverlayController? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        DebugLog.add("listener connected")
        overlay = OverlayController(this).also { it.start() }
        reload()
    }

    override fun onListenerDisconnected() {
        DebugLog.add("listener disconnected")
        overlay?.stop()
        overlay = null
        instance = null
        NotificationListenerService.requestRebind(ComponentName(this, TalkListener::class.java))
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        overlay?.stop()
        overlay = null
        instance = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) handle(sbn, true)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) MessageStore.removeNotif(sbn.key)
    }

    fun refreshOverlay() {
        overlay?.refresh()
    }

    /** Relê todas as notificações ativas (ex.: depois de mudar filtros). Não lê em voz alta. */
    fun reload() {
        MessageStore.clear()
        try {
            val active = activeNotifications
            DebugLog.add("reload: ${active?.size ?: 0} active notifications")
            active?.forEach { handle(it, false) }
        } catch (e: Exception) {
            DebugLog.add("reload failed: ${e.javaClass.simpleName}")
        }
        overlay?.refresh()
    }

    private fun handle(sbn: StatusBarNotification, notify: Boolean) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        val cat = n.category
        val summary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        val reply = findReplyAction(n)
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val looksLikeMessage = style != null || cat == Notification.CATEGORY_MESSAGE || reply != null
        if (!looksLikeMessage && !pkg.startsWith("com.whatsapp")) return

        val info = "$pkg cat=$cat style=${style != null} reply=${reply != null} " +
                "summary=$summary ongoing=$ongoing"

        if (cat == Notification.CATEGORY_CALL || cat == Notification.CATEGORY_TRANSPORT) {
            DebugLog.add("$info -> ignored (call/media)")
            return
        }
        if (ongoing) {
            DebugLog.add("$info -> ignored (ongoing)")
            return
        }
        if (summary) {
            DebugLog.add("$info -> ignored (group summary)")
            return
        }
        if (!looksLikeMessage) {
            DebugLog.add("$info -> ignored (not a message)")
            return
        }

        Prefs.markSeen(this, pkg)
        if (pkg in Prefs.disabledApps(this)) {
            MessageStore.removeNotif(sbn.key)
            DebugLog.add("$info -> ignored (app turned off)")
            return
        }

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val msgs = ArrayList<MessageStore.Msg>()
        var convTitle = title
        var isGroup = false

        if (style != null && style.messages.isNotEmpty()) {
            // nome vazio não pode contar como "eu", senão todas as mensagens seriam descartadas
            val me = style.user.name?.toString()?.takeIf { it.isNotBlank() }
            val groupTitle = style.conversationTitle?.toString()?.takeIf { it.isNotBlank() }
            if (groupTitle != null) convTitle = groupTitle
            isGroup = style.isGroupConversation || groupTitle != null
            for (m in style.messages) {
                val t = m.text?.toString()?.trim().orEmpty()
                if (t.isEmpty()) continue
                val who = m.person?.name?.toString().orEmpty()
                if (me != null && who == me) continue // mensagem minha
                msgs.add(MessageStore.Msg(t, m.timestamp, who.ifBlank { title }))
            }
        } else {
            val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null && lines.isNotEmpty()) {
                lines.forEachIndexed { i, l ->
                    val t = l?.toString()?.trim().orEmpty()
                    if (t.isNotEmpty()) msgs.add(MessageStore.Msg(t, sbn.postTime + i, title))
                }
            } else {
                val t = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                    ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
                if (t.isNotEmpty()) msgs.add(MessageStore.Msg(t, sbn.postTime, title))
            }
        }
        if (msgs.isEmpty()) {
            DebugLog.add("$info -> ignored (no text found; style messages=${style?.messages?.size ?: 0})")
            return
        }
        if (convTitle.isBlank()) convTitle = appLabel(this, pkg)

        // filtros por pessoa
        if (Filters.isMuted(this, convTitle)) {
            MessageStore.removeNotif(sbn.key)
            DebugLog.add("$info -> ignored (muted chat)")
            return
        }
        val vip = Filters.isVip(this, convTitle)
        if (Prefs.vipOnly(this) && !vip && msgs.none { Filters.hasKeyword(this, it.text) }) {
            MessageStore.removeNotif(sbn.key)
            DebugLog.add("$info -> ignored (VIP-only filter)")
            return
        }

        // apps que postam uma notificação por mensagem caem na mesma conversa (mesmo atalho/título)
        val convKey = pkg + "|" + (n.shortcutId?.takeIf { it.isNotBlank() } ?: convTitle.lowercase())

        MessageStore.upsert(
            sbn.key, convKey, pkg, appLabel(this, pkg), convTitle,
            isGroup, vip, msgs, reply, n.contentIntent
        )
        DebugLog.add("$info -> OK ${msgs.size} message(s)")

        if (notify) maybeAutoRead() else MessageStore.announceConv(convKey)
    }

    /** Leitura automática: só com as condições escolhidas (fone, horário, fora de ligação). */
    private fun maybeAutoRead() {
        val ok = Prefs.autoRead(this) &&
                AudioUtil.inSchedule(this) &&
                !AudioUtil.inCall(this) &&
                (!Prefs.autoHeadphonesOnly(this) || AudioUtil.headphonesConnected(this))
        if (!ok) {
            MessageStore.announceAll() // não lê depois, quando as condições mudarem
            return
        }
        overlay?.autoRead()
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }?.let { return it }
        return try {
            Notification.WearableExtender(n).actions
                .firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        @Volatile
        var instance: TalkListener? = null
    }
}
