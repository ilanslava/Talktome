package com.leitorzap

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.util.Locale

/**
 * Tela de resposta: digitar, ditar (Record) ou tocar numa resposta rápida.
 * Depois de ditar (ou escolher uma resposta rápida) há uma contagem de 3 s para enviar,
 * que dá pra cancelar tocando nela ou editando o texto.
 */
class ReplyActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_KEY = "key"
        const val EXTRA_VOICE = "voice"
        private const val COUNTDOWN_SECONDS = 3
    }

    private lateinit var input: EditText
    private lateinit var countdownView: TextView
    private var key = ""

    private val handler = Handler(Looper.getMainLooper())
    private var counting = false
    private var remaining = 0
    private var settingText = false

    private val tick = object : Runnable {
        override fun run() {
            if (!counting) return
            remaining--
            if (remaining <= 0) {
                stopCountdown()
                send()
            } else {
                showCountdown()
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val dictation =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    val cur = input.text.toString().trim()
                    setInput(if (cur.isEmpty()) t else "$cur $t")
                    startCountdown()
                }
            }
        }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(t: String, bg: Int, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 15f
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = ContextCompat.getDrawable(this@ReplyActivity, bg)
        setOnClickListener { onClick() }
    }

    private fun setInput(t: String) {
        settingText = true
        input.setText(t)
        input.setSelection(input.text.length)
        settingText = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = intent.getStringExtra(EXTRA_KEY).orEmpty()
        val conv = MessageStore.conv(key)
        if (conv == null) {
            Toast.makeText(this, "That chat is no longer available.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val cText = Color.parseColor("#EEF0FF")
        val cMuted = Color.parseColor("#A5A9D6")
        val cGreen = Color.parseColor("#34D399")
        val cDark = Color.parseColor("#0B0E2A")

        val last = conv.msgs.lastOrNull()
        val quote = tv(
            if (last == null) "" else if (conv.isGroup && last.sender.isNotBlank())
                "${last.sender}: ${last.text}" else last.text,
            13.5f, cMuted
        ).apply {
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_row)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        // respostas rápidas
        val quick = Prefs.quickReplies(this)
        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (q in quick) {
            quickRow.addView(
                tv(q, 13.5f, cText).apply {
                    setPadding(px(14), px(9), px(14), px(9))
                    background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_chip_indigo)
                    setOnClickListener {
                        setInput(q)
                        startCountdown()
                    }
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = px(8) }
            )
        }
        val quickScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(quickRow)
            visibility = if (quick.isEmpty()) View.GONE else View.VISIBLE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
        }

        input = EditText(this).apply {
            hint = "Type, tap Record, or pick a quick reply…"
            setHintTextColor(cMuted)
            setTextColor(cText)
            textSize = 16f
            minLines = 2
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_input)
            setPadding(px(12), px(10), px(12), px(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(10) }
            doAfterTextChanged { if (!settingText && counting) stopCountdown() }
        }

        countdownView = tv("", 14f, cGreen, bold = true).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            setPadding(0, px(10), 0, 0)
            setOnClickListener { stopCountdown() }
        }

        fun lp() = LinearLayout.LayoutParams(0, px(48), 1f).apply {
            marginStart = px(3)
            marginEnd = px(3)
        }
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(12) }
            addView(btn("🎤 Record", R.drawable.bg_chip_indigo, cText) {
                stopCountdown()
                startDictation()
            }, lp())
            addView(btn("Send ➤", R.drawable.bg_chip_green, cDark) {
                stopCountdown()
                send()
            }, lp())
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(8) }
            addView(btn("Open chat", R.drawable.bg_chip_indigo, cText) { openChat() }, lp())
            addView(btn("Cancel", R.drawable.bg_chip_indigo, cText) { finish() }, lp())
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ContextCompat.getDrawable(this@ReplyActivity, R.drawable.bg_panel)
            setPadding(px(16), px(16), px(16), px(16))
            isClickable = true // não fecha ao tocar dentro do cartão
            addView(tv("Reply to ${conv.title}  ·  ${conv.appName}", 17f, cText, bold = true))
            addView(quote)
            addView(quickScroll)
            addView(input)
            addView(countdownView)
            addView(row1)
            addView(row2)
        }

        val root = FrameLayout(this).apply {
            setOnClickListener { finish() }
            addView(
                card,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply {
                    setMargins(px(12), px(12), px(12), px(12))
                }
            )
        }
        setContentView(root)

        if (intent.getBooleanExtra(EXTRA_VOICE, false)) {
            window.decorView.post { startDictation() }
        } else {
            input.requestFocus()
            window.setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                        WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    // ---- contagem para envio automático ----

    private fun startCountdown() {
        if (!Prefs.autoSend(this) || input.text.isNullOrBlank()) return
        counting = true
        remaining = COUNTDOWN_SECONDS
        showCountdown()
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1000)
    }

    private fun showCountdown() {
        countdownView.visibility = View.VISIBLE
        countdownView.text = "Sending in ${remaining}s…  tap here to cancel"
    }

    private fun stopCountdown() {
        counting = false
        handler.removeCallbacks(tick)
        countdownView.visibility = View.GONE
    }

    // ---- ditado e envio ----

    private fun startDictation() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your reply")
        try {
            dictation.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No speech recognition on this phone. Type your reply instead.", Toast.LENGTH_LONG).show()
        }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) {
            Toast.makeText(this, "Write or record something first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (MessageStore.isDemo(key)) {
            Toast.makeText(this, "Demo: would send \"$t\"", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (MessageStore.sendReply(this, key, t)) {
            Toast.makeText(this, "Sent ✓", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(
                this, "Couldn't send from here. Tap \"Open chat\" to reply in the app.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openChat() {
        if (MessageStore.openChat(key)) finish()
        else Toast.makeText(this, "That chat can't be opened from here. Open the app.", Toast.LENGTH_LONG).show()
    }
}
