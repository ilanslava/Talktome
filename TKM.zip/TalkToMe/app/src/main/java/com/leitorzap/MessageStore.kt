package com.leitorzap

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Guarda as mensagens novas (vindas das notificações de qualquer app de mensagem)
 * e envia respostas. Uso só na thread principal.
 */
object MessageStore {

    class Msg(val text: String, val time: Long, val sender: String, var heard: Boolean = false)

    class Conv(val key: String) {
        var pkg: String = ""
        var appName: String = ""
        var title: String = ""
        var isGroup: Boolean = false
        var vip: Boolean = false
        var msgs: List<Msg> = emptyList()

        /** Mensagens por notificação (alguns apps postam uma notificação por mensagem). */
        val parts = LinkedHashMap<String, List<Msg>>()
        val replies = LinkedHashMap<String, Notification.Action>()
        val opens = LinkedHashMap<String, PendingIntent>()

        val heardSigs = HashSet<String>()
        val dismissedSigs = HashSet<String>()
        val announced = HashSet<String>()

        val replyAction: Notification.Action? get() = replies.values.lastOrNull()
        val openIntent: PendingIntent? get() = opens.values.lastOrNull()
        val lastTime: Long get() = msgs.maxOfOrNull { it.time } ?: 0L

        fun sig(m: Msg) = "${m.time}|${m.text}"

        fun rebuild() {
            val all = parts.values.flatten()
                .distinctBy { sig(it) }
                .filter { sig(it) !in dismissedSigs }
                .sortedBy { it.time }
                .takeLast(40)
            for (m in all) m.heard = sig(m) in heardSigs
            msgs = all
        }

        fun markHeard(m: Msg) {
            heardSigs.add(sig(m))
        }

        fun dismiss(m: Msg) {
            dismissedSigs.add(sig(m))
            heardSigs.add(sig(m))
        }
    }

    private class Saved(val heard: Set<String>, val dismissed: Set<String>, val announced: Set<String>)

    private val convs = LinkedHashMap<String, Conv>()
    private val byNotif = HashMap<String, String>() // chave da notificação -> chave da conversa
    private val saved = HashMap<String, Saved>()    // estado preservado entre recargas
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun changed() { listeners.forEach { it() } }

    /** VIPs primeiro, depois as mais recentes. Conversas sem mensagens visíveis ficam de fora. */
    fun conversations(): List<Conv> = convs.values
        .filter { it.msgs.isNotEmpty() }
        .sortedWith(compareByDescending<Conv> { it.vip }.thenByDescending { it.lastTime })

    /** Ordem para ler em voz alta: VIPs primeiro, depois as conversas mais antigas. */
    fun conversationsForReading(): List<Conv> = convs.values
        .filter { it.msgs.isNotEmpty() }
        .sortedWith(compareByDescending<Conv> { it.vip }.thenBy { it.lastTime })

    fun conv(key: String): Conv? = convs[key]
    fun unheardCount(): Int = convs.values.sumOf { c -> c.msgs.count { !it.heard } }
    fun isDemo(key: String) = key.startsWith("demo:")

    private fun newConv(key: String): Conv {
        val c = Conv(key)
        saved[key]?.let {
            c.heardSigs.addAll(it.heard)
            c.dismissedSigs.addAll(it.dismissed)
            c.announced.addAll(it.announced)
        }
        return c
    }

    fun upsert(
        notifKey: String, convKey: String, pkg: String, appName: String, title: String,
        isGroup: Boolean, vip: Boolean, newMsgs: List<Msg>,
        reply: Notification.Action?, open: PendingIntent?
    ) {
        val c = convs.getOrPut(convKey) { newConv(convKey) }
        c.pkg = pkg
        c.appName = appName
        c.title = title
        c.isGroup = isGroup
        c.vip = vip
        c.parts[notifKey] = newMsgs
        if (reply != null) c.replies[notifKey] = reply else c.replies.remove(notifKey)
        if (open != null) c.opens[notifKey] = open else c.opens.remove(notifKey)
        byNotif[notifKey] = convKey
        c.rebuild()
        changed()
    }

    /** Uma notificação foi removida (lida no app, dispensada ou respondida). */
    fun removeNotif(notifKey: String) {
        val ck = byNotif.remove(notifKey) ?: return
        val c = convs[ck] ?: return
        c.parts.remove(notifKey)
        c.replies.remove(notifKey)
        c.opens.remove(notifKey)
        if (c.parts.isEmpty()) convs.remove(ck) else c.rebuild()
        changed()
    }

    /** Limpa tudo, mas lembra o que já foi ouvido/dispensado/anunciado. */
    fun clear() {
        if (convs.isEmpty() && byNotif.isEmpty()) return
        for (c in convs.values) {
            saved[c.key] = Saved(HashSet(c.heardSigs), HashSet(c.dismissedSigs), HashSet(c.announced))
        }
        convs.clear()
        byNotif.clear()
        changed()
    }

    fun refreshVip(isVip: (String) -> Boolean) {
        for (c in convs.values) c.vip = isVip(c.title)
        changed()
    }

    /** Esconde as conversas de uma pessoa silenciada. */
    fun removeByTitle(name: String) {
        val n = name.trim().lowercase()
        val keys = convs.values.filter { it.title.trim().lowercase() == n }.map { it.key }
        if (keys.isEmpty()) return
        for (k in keys) convs.remove(k)
        byNotif.entries.removeAll { it.value in keys }
        changed()
    }

    fun removeByPackage(pkg: String) {
        val keys = convs.values.filter { it.pkg == pkg }.map { it.key }
        if (keys.isEmpty()) return
        for (k in keys) convs.remove(k)
        byNotif.entries.removeAll { it.value in keys }
        changed()
    }

    fun markHeard(key: String, m: Msg) {
        val c = convs[key]
        if (c != null) {
            c.markHeard(m)
            c.rebuild()
        }
        changed()
    }

    fun dismiss(key: String, m: Msg) {
        val c = convs[key]
        if (c != null) {
            c.dismiss(m)
            c.rebuild()
        }
        changed()
    }

    fun markAllHeard(key: String? = null) {
        for (c in convs.values) {
            if (key == null || c.key == key) {
                c.msgs.forEach { c.markHeard(it) }
                c.rebuild()
            }
        }
        changed()
    }

    // ---- leitura automática: só anuncia cada mensagem uma vez ----

    fun announceAll() {
        for (c in convs.values) c.msgs.forEach { c.announced.add(c.sig(it)) }
    }

    fun announceConv(key: String) {
        val c = convs[key] ?: return
        c.msgs.forEach { c.announced.add(c.sig(it)) }
    }

    /** Mensagens ainda não ouvidas nem anunciadas, da conversa mais antiga para a mais nova. */
    fun takeNewForAutoRead(): List<Pair<Conv, List<Msg>>> {
        val out = ArrayList<Pair<Conv, List<Msg>>>()
        for (c in convs.values.sortedBy { it.lastTime }) {
            val fresh = c.msgs.filter { !it.heard && c.sig(it) !in c.announced }
            if (fresh.isEmpty()) continue
            fresh.forEach { c.announced.add(c.sig(it)) }
            out.add(Pair(c, fresh))
        }
        return out
    }

    // ---- respostas ----

    /** Responde pela própria notificação do app (RemoteInput). false se não for possível. */
    fun sendReply(ctx: Context, key: String, text: String): Boolean {
        val conv = convs[key] ?: return false
        val action = conv.replyAction ?: return false
        val inputs = action.remoteInputs
        if (inputs == null || inputs.isEmpty()) return false
        val pi = action.actionIntent ?: return false
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try {
            pi.send(ctx, 0, intent)
            markAllHeard(key)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }

    fun openChat(key: String): Boolean {
        val pi = convs[key]?.openIntent ?: return false
        return try {
            pi.send()
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }

    /** Mensagens de exemplo (de apps diferentes) para testar o visual. */
    fun addDemo() {
        val now = System.currentTimeMillis()
        fun m(t: String, ago: Int, who: String) = Msg(t, now - ago * 60_000L, who)
        upsert("demo:maria", "demo:maria", "demo", "WhatsApp", "Maria", false, true, listOf(
            m("Hey! Are you coming tonight?", 6, "Maria"),
            m("I saved you a seat 😄", 5, "Maria"),
            m("Call me when you see this", 1, "Maria")
        ), null, null)
        upsert("demo:family", "demo:family", "demo", "Telegram", "Family group", true, false, listOf(
            m("Who's bringing the cake?", 20, "João"),
            m("Eu posso levar o bolo!", 18, "Ana"),
            m("Perfect 👍", 17, "João")
        ), null, null)
        upsert("demo:insta", "demo:insta", "demo", "Instagram", "lia.design", false, false, listOf(
            m("Loved your last post! Can we talk about a project?", 9, "lia.design")
        ), null, null)
    }
}
