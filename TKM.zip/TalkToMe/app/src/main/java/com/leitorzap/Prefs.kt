package com.leitorzap

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("leitor", Context.MODE_PRIVATE)
    private fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    private fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    private fun strSet(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet()) ?: emptySet()

    /** Liga/desliga um nome (minúsculo) num conjunto salvo. Retorna true se ficou ligado. */
    private fun toggle(c: Context, k: String, name: String): Boolean {
        val n = name.trim().lowercase()
        val copy = HashSet(strSet(c, k))
        val now = if (copy.contains(n)) {
            copy.remove(n)
            false
        } else {
            copy.add(n)
            true
        }
        sp(c).edit().putStringSet(k, copy).apply()
        return now
    }

    // ---- voz ----
    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.0f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()

    /** Detecta o idioma de cada mensagem e usa a voz desse idioma, se existir. */
    fun smartVoice(c: Context) = bool(c, "smart_voice", true)
    fun setSmartVoice(c: Context, v: Boolean) = setBool(c, "smart_voice", v)

    /** Traduz mensagens em outros idiomas para o idioma do celular. */
    fun translate(c: Context) = bool(c, "translate", false)
    fun setTranslate(c: Context, v: Boolean) = setBool(c, "translate", v)

    // ---- bolha e painel ----
    fun alwaysShow(c: Context) = bool(c, "always", false)
    fun setAlwaysShow(c: Context, v: Boolean) = setBool(c, "always", v)

    fun panelLevel(c: Context): Int = sp(c).getInt("plevel", 1)
    fun setPanelLevel(c: Context, v: Int) = sp(c).edit().putInt("plevel", v).apply()

    fun btnX(c: Context): Int = sp(c).getInt("bx", -1)
    fun btnY(c: Context): Int = sp(c).getInt("by", -1)
    fun setBtnPos(c: Context, x: Int, y: Int) =
        sp(c).edit().putInt("bx", x).putInt("by", y).apply()

    // ---- leitura automática ----
    fun autoRead(c: Context) = bool(c, "auto", false)
    fun setAutoRead(c: Context, v: Boolean) = setBool(c, "auto", v)
    fun autoHeadphonesOnly(c: Context) = bool(c, "auto_hp", true)
    fun setAutoHeadphonesOnly(c: Context, v: Boolean) = setBool(c, "auto_hp", v)
    fun autoVipOnly(c: Context) = bool(c, "auto_vip", false)
    fun setAutoVipOnly(c: Context, v: Boolean) = setBool(c, "auto_vip", v)
    fun autoScheduleOn(c: Context) = bool(c, "auto_sched", false)
    fun setAutoScheduleOn(c: Context, v: Boolean) = setBool(c, "auto_sched", v)
    fun autoStartMin(c: Context): Int = sp(c).getInt("auto_start", 8 * 60)
    fun autoEndMin(c: Context): Int = sp(c).getInt("auto_end", 22 * 60)
    fun setAutoWindow(c: Context, start: Int, end: Int) =
        sp(c).edit().putInt("auto_start", start).putInt("auto_end", end).apply()

    // ---- respostas ----
    fun autoSend(c: Context) = bool(c, "autosend", true)
    fun setAutoSend(c: Context, v: Boolean) = setBool(c, "autosend", v)

    private val DEFAULT_QUICK = listOf(
        "On my way 🚗", "I'll call you back", "Thanks!", "OK 👍", "Can't talk now, I'll reply later"
    )

    fun quickReplies(c: Context): List<String> =
        sp(c).getString("quick", null)?.split('\n')?.map { it.trim() }?.filter { it.isNotEmpty() }
            ?: DEFAULT_QUICK

    fun setQuickReplies(c: Context, text: String) = sp(c).edit().putString("quick", text).apply()

    // ---- filtros ----
    fun vipOnly(c: Context) = bool(c, "vip_only", false)
    fun setVipOnly(c: Context, v: Boolean) = setBool(c, "vip_only", v)

    fun keywordsText(c: Context): String = sp(c).getString("keywords", "").orEmpty()
    fun setKeywords(c: Context, text: String) = sp(c).edit().putString("keywords", text).apply()
    fun keywords(c: Context): List<String> =
        keywordsText(c).split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun vips(c: Context): Set<String> = strSet(c, "vips")
    fun toggleVip(c: Context, name: String) = toggle(c, "vips", name)
    fun muted(c: Context): Set<String> = strSet(c, "muted")
    fun toggleMuted(c: Context, name: String) = toggle(c, "muted", name)

    // ---- privacidade ----
    fun hideText(c: Context) = bool(c, "hide_text", false)
    fun setHideText(c: Context, v: Boolean) = setBool(c, "hide_text", v)
    fun privateAudio(c: Context) = bool(c, "private_audio", false)
    fun setPrivateAudio(c: Context, v: Boolean) = setBool(c, "private_audio", v)

    // ---- apps ----
    /** Apps que já mandaram notificação de mensagem. */
    fun seenApps(c: Context): Set<String> = strSet(c, "seen")

    fun markSeen(c: Context, pkg: String) {
        val s = seenApps(c)
        if (pkg in s) return
        val copy = HashSet(s)
        copy.add(pkg)
        sp(c).edit().putStringSet("seen", copy).apply()
    }

    /** Apps que o usuário desligou. Todo app novo começa ligado. */
    fun disabledApps(c: Context): Set<String> = strSet(c, "disabled")

    fun setAppEnabled(c: Context, pkg: String, enabled: Boolean) {
        val copy = HashSet(disabledApps(c))
        if (enabled) copy.remove(pkg) else copy.add(pkg)
        sp(c).edit().putStringSet("disabled", copy).apply()
    }
}
