package com.leitorzap

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Registro curto do que o app recebeu/decidiu (sem o texto das mensagens), para diagnóstico. */
object DebugLog {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun add(s: String) {
        synchronized(lines) {
            lines.addLast("${fmt.format(Date())} $s")
            while (lines.size > 60) lines.removeFirst()
        }
    }

    fun dump(): String = synchronized(lines) { lines.joinToString("\n") }
}
