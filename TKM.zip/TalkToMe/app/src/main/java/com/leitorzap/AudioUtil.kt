package com.leitorzap

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import java.util.Calendar

object AudioUtil {

    /** Fone com fio, USB, Bluetooth (inclui o som do carro) ou aparelho auditivo conectado. */
    fun headphonesConnected(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { d ->
            val t = d.type
            t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    t == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    t == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    t == AudioDeviceInfo.TYPE_HEARING_AID ||
                    (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
    }

    fun inCall(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val m = am.mode
        return m == AudioManager.MODE_IN_CALL ||
                m == AudioManager.MODE_IN_COMMUNICATION ||
                m == AudioManager.MODE_RINGTONE
    }

    /** true se não há horário configurado ou se agora está dentro dele. */
    fun inSchedule(ctx: Context): Boolean {
        if (!Prefs.autoScheduleOn(ctx)) return true
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val start = Prefs.autoStartMin(ctx)
        val end = Prefs.autoEndMin(ctx)
        return if (start <= end) now in start until end else (now >= start || now < end)
    }
}
