package com.leitorzap

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** Detecção de idioma (offline) e tradução (baixa o pacote do idioma na primeira vez). */
object LangTools {
    private val translators = HashMap<String, Translator>()
    private val identifier by lazy { LanguageIdentification.getClient() }

    /** Retorna o código do idioma (ex.: "en") ou null se não deu pra detectar. */
    fun detect(text: String, cb: (String?) -> Unit) {
        try {
            identifier.identifyLanguage(text)
                .addOnSuccessListener { code -> cb(if (code == "und") null else code) }
                .addOnFailureListener { cb(null) }
        } catch (e: Exception) {
            cb(null)
        }
    }

    /** Retorna o texto traduzido ou null se não foi possível (sem internet na 1ª vez, idioma sem suporte...). */
    fun translate(text: String, from: String, to: String, cb: (String?) -> Unit) {
        try {
            val src = TranslateLanguage.fromLanguageTag(from)
            val dst = TranslateLanguage.fromLanguageTag(to)
            if (src == null || dst == null || src == dst) {
                cb(null)
                return
            }
            val tr = translators.getOrPut("$src>$dst") {
                Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(src)
                        .setTargetLanguage(dst)
                        .build()
                )
            }
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    tr.translate(text)
                        .addOnSuccessListener { out -> cb(out) }
                        .addOnFailureListener { cb(null) }
                }
                .addOnFailureListener { cb(null) }
        } catch (e: Exception) {
            cb(null)
        }
    }
}
