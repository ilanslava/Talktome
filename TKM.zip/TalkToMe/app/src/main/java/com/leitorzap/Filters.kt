package com.leitorzap

import android.content.Context

object Filters {
    private fun norm(name: String) = name.trim().lowercase()

    fun isVip(ctx: Context, name: String) = norm(name) in Prefs.vips(ctx)
    fun isMuted(ctx: Context, name: String) = norm(name) in Prefs.muted(ctx)

    fun hasKeyword(ctx: Context, text: String): Boolean {
        val words = Prefs.keywords(ctx)
        if (words.isEmpty()) return false
        val t = text.lowercase()
        return words.any { t.contains(it) }
    }
}
