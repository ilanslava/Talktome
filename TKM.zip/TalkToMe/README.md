# Talk to me

App Android que **lê em voz alta as suas mensagens novas** (WhatsApp, Telegram, Instagram, Messenger, SMS, Signal, Discord, Slack...) e deixa você **responder falando**.

Pacote: `com.talktome` · Android 8.0+ (API 26) · idiomas: inglês e português (pt-BR)

## O que ele faz

- Orb flutuante discreto em formato de boca, nas cores do app (indigo, azul, violeta): mostra o número de mensagens novas numa plaquinha, o ícone do app com mensagem nova no canto, solta ondas suaves quando chega mensagem e abre e fecha a boca enquanto fala. Com 5 ou mais mensagens novas ele cresce um pouco, e mais um pouco a cada nova (até um limite).
- Toque na bolha: painel com as mensagens agrupadas por conversa. Toque numa mensagem para ouvir.
- Responder: 🎤 Gravar (você fala, confere o texto e envia), ✍ Digitar ou **respostas rápidas**. O envio usa a própria notificação do app, sem abrir a conversa.
- **Som de mensagem nova:** toque curto e suave a cada mensagem (liga/desliga nas configurações do app). Fica quieto no Não perturbe, no silencioso e em chamadas; com a leitura automática ligada, o toque vem antes da voz.
- **Leitura automática (mãos livres):** cada mensagem nova é lida assim que chega, em fila.
- **Ignorar códigos de verificação:** SMS de banco/2FA nunca são lidos em voz alta.
- **Emoji não são lidos** (nem carinhas como :) ou <3). Mensagem só de emoji é pulada. Links viram "link".
- **Voz no idioma de cada mensagem:** inglês com voz em inglês, espanhol com espanhol etc. (detecção offline; precisa da voz instalada no passo 3; dá para desligar).
- Baixa o volume da música/vídeo enquanto fala (foco de áudio) e devolve depois.
- A bolha gruda na borda da tela quando você solta, e dá pra ligar/desligar app por app.
- Se o Android encerrar o serviço, abrir o app o religa sozinho.
- Tudo roda no aparelho. Só a transcrição do botão Gravar é feita pelo serviço de voz do celular.

## Ícone

O ícone (`1000048723.png`) está em todos os lugares:

| Onde | Arquivo |
|---|---|
| Ícone do app / gaveta / configurações (Android 8+) | `mipmap-anydpi-v26/ic_launcher.xml` (adaptativo) |
| Ícone redondo | `mipmap-*/ic_launcher_round.png` + `mipmap-anydpi-v26/ic_launcher_round.xml` |
| Android 13+ ícone temático | `drawable-nodpi/ic_launcher_monochrome.png` |
| Android 7 e anteriores | `mipmap-*/ic_launcher.png` |
| Tela inicial, bolha flutuante, painel e tela de resposta | `drawable-nodpi/app_icon.png` |
| Loja / divulgação (512x512) | `store/icon-512.png` |

## Compilar

**GitHub Actions:** suba o projeto no GitHub. A aba *Actions* gera o APK (`TalkToMe-debug`).

**Android Studio:** *File > Open* na pasta do projeto e *Build > Build APK(s)*. Se pedir, deixe o Studio criar o Gradle wrapper (versão 8.7).

## Primeiro uso

1. Abra o app e siga os passos 1 a 4 (acesso às notificações, sobrepor outros apps, voz, bateria).
2. Se o Android bloquear o passo 1 (instalação por APK): *Informações do app > ⋮ > Permitir configurações restritas*.
3. Toque em *Mostrar demonstração* para ver tudo funcionando sem esperar uma mensagem de verdade.

## Nota de voz (🎙)

Na tela de resposta há o botão **🎙 Nota de voz**: toque para gravar, toque de novo para parar. O app grava o áudio (Ogg/Opus no Android 10+, igual ao das notas de voz do WhatsApp; M4A em versões antigas) e entrega ao app da conversa pelo compartilhar do Android. No WhatsApp ele tenta abrir direto na conversa certa (usa o id do atalho da notificação); se não der, aparece a lista de contatos. Você só confirma o envio.

- Pede a permissão de microfone na primeira vez.
- Em outros apps (Messenger, Telegram...) o áudio chega pelo compartilhar do próprio app.
- Se o áudio chegar como arquivo comum em vez de nota de voz, a extensão (`.ogg`) é o primeiro ponto a ajustar.

## Assinatura

Todo build (debug e release) é assinado com `app/talktome.keystore`, então atualizações instalam por cima sem desinstalar. Para publicar na Play Store, troque por uma chave própria guardada nos Secrets do GitHub.

## Versão 1.4

- **Ocultar a bolinha:** botão no fim do painel. Ela some e só volta quando chega mensagem nova (ou ao ligar "sempre na tela").
- **Ícone do app na bolinha:** o app (ou os 2 apps mais recentes) com mensagem nova aparece em um mini ícone no canto da bolinha.
- **E-mail:** o painel mostra a conta que recebeu, e o texto é separado em "Assunto" e corpo (lido assim em voz alta). E-mail não tem resposta pela notificação, então responder abre um rascunho no app de e-mail com o texto pronto.
- **Gravar áudio:** o botão principal do painel agora é 🎙 Nota de voz (grava o áudio e entrega ao app da conversa). O ditado (voz → texto, pelo Google) ficou como 🎤 Ditar dentro da tela de resposta.
- **Enviar texto:** se o envio direto pela notificação falhar, o app abre a conversa com o texto já escrito.

## Versão 1.5

- **Painel mais limpo:** cada conversa mostra só as 3 mensagens mais recentes (o resto fica atrás de "▾ N anteriores").
- **Deslizar para tirar:** deslize uma mensagem (ou o título de uma conversa) para o lado e ela sai do painel. Só some do painel; nada é apagado no WhatsApp ou outro app.
- **Limpar tudo:** botão no fim do painel que tira todas as mensagens do painel de uma vez.

## Versão 1.6

- **Orb novo:** esfera escura com anel de aurora e uma boca estilizada no centro (a boca abre e fecha enquanto o app fala). Menor que antes e sem verde: só as cores do app.
- **Parar na própria mensagem:** enquanto uma mensagem fala, o ▶ dela vira ■. Tocar nela de novo para. O mesmo vale para "▶ Conversa" (vira "■ Conversa").
- **Limpar demonstração:** quando há mensagens de demonstração no painel, aparece o botão "Limpar demonstração e começar do zero".
- **E-mail:** a conta que recebeu agora também é buscada no resumo do grupo de notificações do Gmail, se a mensagem em si não trouxer.
- **Sem emojis coloridos** nos botões e textos do app (as mensagens e as respostas rápidas não mudam). A leitura em voz já ignorava emojis.

## Versão 1.7

- **O que eu perdi?** Com 2 ou mais mensagens novas, aparece o botão "O que eu perdi?" no painel. Ele fala um resumo: quantas mensagens há em cada app e de quem, e o que parece urgente (por palavras como "urgente", "importante", "me liga"). É um resumo por contagem e palavras-chave, sem IA: não reescreve o conteúdo das mensagens. Para ouvir uma conversa, use o ▶ dela.

## Versão 1.8

- **Notificações de IA:** ChatGPT, Claude, Gemini, Copilot, Perplexity, Grok, DeepSeek, Mistral, Character.AI, Poe e Kimi agora entram no painel como mensagens (notificações de "gerando resposta" são ignoradas). Cada app aparece na lista de apps das configurações, onde dá para ligar ou desligar.

## Versão 1.9

- **Modo carro:** ligado na mão (configurações) ou sozinho, com o modo carro do Android / Android Auto ou quando o Bluetooth do carro conecta. No carro: leitura automática sempre ligada e, depois de ler uma mensagem de conversa, o app pergunta "Responder fulano?". Diga sim, fale a resposta, ouça a confirmação e diga sim para enviar (envia pela resposta da notificação; e-mail e apps de IA não entram). Usa o microfone e o reconhecimento de voz do celular.
- **Orb no modo carro:** o orb fica sempre na tela, com brilho azul-céu pulsando e um carrinho no canto. A leitura no carro vale mesmo com "Não perturbe".
- **Som no painel:** o alto-falante no fim do painel liga/desliga o som de mensagem nova.
- **Favoritas:** estrela (☆) na conversa: ela sobe para o topo do painel, é lida primeiro e tem um toque diferente.
- **Silenciar:** botão de alto-falante na conversa: as mensagens ficam no painel, mas sem toque, sem leitura e sem acender a bolinha.

## Versão 1.9.1

- **Áudio direto na conversa:** ao parar a gravação, o WhatsApp abre já na conversa da pessoa, com o áudio pronto para enviar (sem escolher o contato). O app procura o id do chat no atalho da notificação, nas pessoas da mensagem e, se só houver telefone, monta o id a partir dele. Se não achar, abre a lista de contatos e avisa com o id que a notificação trouxe (útil para diagnóstico).

## Versão 1.9.2

- **Resposta de e-mail:** o texto agora vai dentro do próprio link do rascunho (`mailto:...?subject=...&body=...`), então o Gmail abre com assunto e mensagem preenchidos (e destinatário, se a notificação trouxer o endereço). Sem o endereço, o app copia sua resposta e abre o e-mail: toque em "Responder" e cole. O Android não deixa um app enviar e-mail escondido pelo Gmail; para enviar sem abrir nada seria preciso Gmail API (login Google) ou SMTP com senha de app.

## Versão 1.9.3

- **Limpar tudo:** o botão agora limpa todas as mensagens do painel (antes só as já ouvidas) e para a leitura se estiver falando. Só some do painel; nada é apagado no WhatsApp, Gmail ou outros apps.

## Código

| Arquivo | Função |
|---|---|
| `TalkListener.kt` | Lê as notificações e identifica mensagens |
| `MessageStore.kt` | Conversas, estado "ouvido", envio de resposta |
| `OverlayController.kt` | Bolha e painel flutuantes |
| `BubbleView.kt` | Desenho da bolinha: número, ondas e tamanho |
| `Chime.kt` | Toque de mensagem nova (gerado no código) |
| `Speaker.kt` | Voz (TextToSpeech), fila e foco de áudio |
| `ReplyActivity.kt` | Tela de resposta (voz, texto, respostas rápidas) |
| `MainActivity.kt` | Configuração e ajustes |
| `Util.kt` | Limpeza do texto falado, códigos de verificação |
| `VoiceShare.kt` | Entrega a nota de voz ao app da conversa |
