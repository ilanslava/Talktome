# Talk to me

Hear your new messages (WhatsApp, Telegram, Instagram, Messenger, SMS, Signal, Discord...) and answer with your voice.

- Bolha flutuante com contador (sempre visível ou só com mensagem nova); painel redimensionável (− / +).
- Painel com mensagens agrupadas por conversa e por app; toque = ouvir; deslizar direita = ouvida, esquerda = dispensar.
- Responder: Record (ditado) ou Type, com respostas rápidas e envio automático com contagem de 3 s (cancelável).
- Leitura automática (só com fone/Bluetooth/carro, horário, fora de ligação, só VIPs).
- Filtros: VIPs (★), silenciar (🔇), palavras-chave, e lista de apps para ligar/desligar.
- Voz certa por idioma (detecção offline) e tradução opcional (ML Kit).
- Privacidade: esconder texto até tocar; áudio privado (só com fone).
- Mãos livres: comandos de voz "next / reply / repeat / stop" (e em português: próxima / responder / repetir / parar).
- Respostas enviadas pela própria notificação do app (RemoteInput). Se o app não permitir, use "Open chat".

## Permissões
1. Acesso às notificações. 2. Exibir sobre outros apps. 3. Microfone (só no modo mãos livres). 4. Lista de apps (nomes).

## Compilar
- Android Studio: File > Open nesta pasta > Build > Build APK(s). Precisa de internet (dependências ML Kit).
- Ou GitHub: suba a pasta; o Actions gera o APK em "Artifacts".
