# Talk to me

App Android que **lê em voz alta as suas mensagens novas** (WhatsApp, Telegram, Instagram, Messenger, SMS, Signal, Discord, Slack...) e deixa você **responder falando**.

Pacote: `com.talktome` · Android 8.0+ (API 26) · idiomas: inglês e português (pt-BR)

## O que ele faz

- Bolinha flutuante discreta, nas cores do app, com o contador de mensagens novas (de todos os apps juntos). Quando chega mensagem ela "respira" soltando ondas suaves; com 5 ou mais mensagens novas ela cresce, e um pouco mais a cada mensagem que chega (até um limite). Sem mensagens, fica pequena (e só aparece se a opção "sempre na tela" estiver ligada).
- Toque na bolha: painel com as mensagens agrupadas por conversa. Toque numa mensagem para ouvir.
- Responder: 🎤 Gravar (você fala, confere o texto e envia), ✍ Digitar ou **respostas rápidas**. O envio usa a própria notificação do app, sem abrir a conversa.
- **Leitura automática (mãos livres):** cada mensagem nova é lida assim que chega, em fila.
- **Ignorar códigos de verificação:** SMS de banco/2FA nunca são lidos em voz alta.
- **Emoji não são lidos** (nem carinhas como :) ou <3). Mensagem só de emoji é pulada. Links viram "link".
- **Voz no idioma de cada mensagem:** inglês com voz em inglês, espanhol com espanhol etc. (detecção offline; precisa da voz instalada no passo 3; dá para desligar).
- Baixa o volume da música/vídeo enquanto fala (foco de áudio) e devolve depois.
- A bolha gruda na borda da tela quando você solta, e dá pra ligar/desligar app por app.
- Se o Android encerrar o serviço, abrir o app o religa sozinho.
- Tudo roda no aparelho. Só a transcrição do botão Gravar é feita pelo serviço de voz do celular.

## Ícone

O ícone (`1000048723.png`) está em todos os lugares:

| Onde | Arquivo |
|---|---|
| Ícone do app / gaveta / configurações (Android 8+) | `mipmap-anydpi-v26/ic_launcher.xml` (adaptativo) |
| Ícone redondo | `mipmap-*/ic_launcher_round.png` + `mipmap-anydpi-v26/ic_launcher_round.xml` |
| Android 13+ ícone temático | `drawable-nodpi/ic_launcher_monochrome.png` |
| Android 7 e anteriores | `mipmap-*/ic_launcher.png` |
| Tela inicial, bolha flutuante, painel e tela de resposta | `drawable-nodpi/app_icon.png` |
| Loja / divulgação (512x512) | `store/icon-512.png` |

## Compilar

**GitHub Actions:** suba o projeto no GitHub. A aba *Actions* gera o APK (`TalkToMe-debug`).

**Android Studio:** *File > Open* na pasta do projeto e *Build > Build APK(s)*. Se pedir, deixe o Studio criar o Gradle wrapper (versão 8.7).

## Primeiro uso

1. Abra o app e siga os passos 1 a 4 (acesso às notificações, sobrepor outros apps, voz, bateria).
2. Se o Android bloquear o passo 1 (instalação por APK): *Informações do app > ⋮ > Permitir configurações restritas*.
3. Toque em *Mostrar demonstração* para ver tudo funcionando sem esperar uma mensagem de verdade.

## Nota de voz (🎙)

Na tela de resposta há o botão **🎙 Nota de voz**: toque para gravar, toque de novo para parar. O app grava o áudio (Ogg/Opus no Android 10+, igual ao das notas de voz do WhatsApp; M4A em versões antigas) e entrega ao app da conversa pelo compartilhar do Android. No WhatsApp ele tenta abrir direto na conversa certa (usa o id do atalho da notificação); se não der, aparece a lista de contatos. Você só confirma o envio.

- Pede a permissão de microfone na primeira vez.
- Em outros apps (Messenger, Telegram...) o áudio chega pelo compartilhar do próprio app.
- Se o áudio chegar como arquivo comum em vez de nota de voz, a extensão (`.ogg`) é o primeiro ponto a ajustar.

## Assinatura

Todo build (debug e release) é assinado com `app/talktome.keystore`, então atualizações instalam por cima sem desinstalar. Para publicar na Play Store, troque por uma chave própria guardada nos Secrets do GitHub.

## Código

| Arquivo | Função |
|---|---|
| `TalkListener.kt` | Lê as notificações e identifica mensagens |
| `MessageStore.kt` | Conversas, estado "ouvido", envio de resposta |
| `OverlayController.kt` | Bolha e painel flutuantes |
| `BubbleView.kt` | Desenho da bolinha: número, ondas e tamanho |
| `Speaker.kt` | Voz (TextToSpeech), fila e foco de áudio |
| `ReplyActivity.kt` | Tela de resposta (voz, texto, respostas rápidas) |
| `MainActivity.kt` | Configuração e ajustes |
| `Util.kt` | Limpeza do texto falado, códigos de verificação |
| `VoiceShare.kt` | Entrega a nota de voz ao app da conversa |
